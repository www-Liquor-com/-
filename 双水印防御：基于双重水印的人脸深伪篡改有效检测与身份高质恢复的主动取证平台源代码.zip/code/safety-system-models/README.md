# Safety System Models - 本地GPU模型服务

基于AI的面部篡改检测与取证系统 - 本地GPU模型推理服务

## 🎯 项目概述

本项目是Safety System的AI模型推理服务，运行在本地GPU机器上，为云端Web应用提供深度学习模型推理能力。

## 🏗️ 服务架构

```
┌──────────────────┐    HTTP API    ┌─────────────────┐
│   云端Web服务    │ ──────────────► │  本地GPU服务器   │
│                 │                │                │
│  ┌─────────────┐ │                │ ┌─────────────┐ │
│  │  前端应用   │ │                │ │ 水印嵌入    │ │
│  └─────────────┘ │                │ │ 模型        │ │
│  ┌─────────────┐ │                │ └─────────────┘ │
│  │  后端API    │ │                │ ┌─────────────┐ │
│  └─────────────┘ │                │ │ 深度伪造    │ │
└──────────────────┘                │ │ 检测模型    │ │
                                    │ └─────────────┘ │
                                    │ ┌─────────────┐ │
                                    │ │ 身份恢复    │ │
                                    │ │ 模型        │ │
                                    │ └─────────────┘ │
                                    └─────────────────┘
```

## 📦 项目结构

```
safety-system-models/
├── model/                    # AI模型文件
│   ├── arcface_model/        # 人脸识别模型
│   ├── IdFMark/             # 身份水印模型
│   ├── IR/                  # 身份恢复模型
│   ├── TL/                  # 篡改定位模型
│   ├── noise_faceshifter/   # FaceShifter噪声模型
│   ├── noise_infoswap/      # InfoSwap噪声模型
│   └── noise_simswap/       # SimSwap噪声模型
├── ISC_Net/                 # 核心算法实现
│   ├── deepfake.py          # 深度伪造算法
│   ├── test_on_image_embed_tl.py  # 水印嵌入
│   ├── test_on_image_extract_tl.py # 水印提取
│   └── ...
├── utils/                   # 工具函数
│   └── evaluate_img.py      # 图像质量评估
├── model_server.py          # Flask API服务器
├── start_model_server.py    # 启动脚本
├── requirements.txt         # Python依赖
├── .env                     # 环境配置
└── frp/                     # 内网穿透配置
    └── frpc.ini
```

## 🚀 快速启动

### 1. 环境要求

**硬件要求:**
- NVIDIA GPU (推荐GTX 1080Ti或更高)
- 8GB+ GPU显存
- 16GB+ 系统内存
- 50GB+ 磁盘空间

**软件要求:**
- Python 3.8+
- CUDA 11.0+
- cuDNN 8.0+

### 2. 安装依赖

```bash
# 创建Python虚拟环境
python -m venv venv

# 激活虚拟环境
# Windows:
venv\Scripts\activate
# Linux/Mac:
source venv/bin/activate

# 安装依赖
pip install -r requirements.txt
```

### 3. 配置环境

```bash
# 复制环境配置文件
cp .env.example .env

# 编辑配置文件
nano .env
```

### 4. 启动服务

```bash
# 使用启动脚本（推荐）
python start_model_server.py

# 或直接启动
python model_server.py

# 指定端口启动
python start_model_server.py --port 5001

# 启用调试模式
python start_model_server.py --debug
```

### 5. 验证服务

```bash
# 检查服务状态
curl http://localhost:5001/health

# 测试API接口
curl -X POST -F "image=@test_image.jpg" http://localhost:5001/api/watermark/embed
```

## 🔧 配置说明

### 环境变量配置

编辑 `.env` 文件：

```env
# 服务配置
HOST=0.0.0.0
PORT=5001
DEBUG=False

# GPU配置
CUDA_VISIBLE_DEVICES=0
TORCH_HOME=./torch_cache

# 模型路径配置
MODEL_BASE_PATH=./model
ARCFACE_MODEL_PATH=./model/arcface_model
IDFMARK_MODEL_PATH=./model/IdFMark
IR_MODEL_PATH=./model/IR
TL_MODEL_PATH=./model/TL

# 性能配置
MAX_BATCH_SIZE=4
MODEL_TIMEOUT=30
MEMORY_LIMIT=8GB
```

### 模型文件配置

确保以下模型文件存在：

```
model/
├── arcface_model/
│   ├── backbone.pth
│   └── ...
├── IdFMark/
│   ├── model_weights.pth
│   └── ...
├── IR/
│   ├── ir_model.pth
│   └── ...
└── TL/
    ├── tl_model.pth
    └── ...
```

## 🌐 API接口文档

### 健康检查

```http
GET /health
```

**响应:**
```json
{
  "status": "healthy",
  "gpu_available": true,
  "models_loaded": true,
  "timestamp": "2024-01-01T12:00:00Z"
}
```

### 水印嵌入

```http
POST /api/watermark/embed
Content-Type: multipart/form-data

image: <image_file>
```

**响应:**
```json
{
  "success": true,
  "watermarked_image": "<base64_encoded_image>",
  "metrics": {
    "psnr": 45.2,
    "ssim": 0.98,
    "lpips": 0.02
  },
  "embedding_info": {
    "watermark_strength": 0.1,
    "embedding_time": 1.23
  }
}
```

### 水印检测

```http
POST /api/watermark/detect
Content-Type: multipart/form-data

image: <image_file>
```

**响应:**
```json
{
  "success": true,
  "has_watermark": true,
  "confidence": 0.95,
  "tamper_localization": "<base64_encoded_image>",
  "identity_recovery": "<base64_encoded_image>",
  "detection_info": {
    "detection_time": 2.45,
    "tamper_ratio": 0.15
  }
}
```

### 深度伪造生成

```http
POST /api/deepfake/{model_type}
Content-Type: multipart/form-data

image: <image_file>
```

支持的模型类型:
- `simswap` - SimSwap模型
- `infoswap` - InfoSwap模型  
- `faceshifter` - FaceShifter模型
- `stablediffusion` - Stable Diffusion Inpainting

### 图像质量评估

```http
POST /api/evaluate/quality
Content-Type: multipart/form-data

original: <image_file>
processed: <image_file>
```

## 🔗 内网穿透配置

### 使用FRP

1. **配置FRP客户端**

编辑 `frp/frpc.ini`:

```ini
[common]
server_addr = your-frp-server.com
server_port = 7000
token = your-frp-token

[model_api]
type = http
local_ip = 127.0.0.1
local_port = 5001
custom_domains = model-api.your-domain.com
```

2. **启动FRP客户端**

```bash
# 下载FRP客户端
wget https://github.com/fatedier/frp/releases/download/v0.52.3/frp_0.52.3_linux_amd64.tar.gz
tar -xzf frp_0.52.3_linux_amd64.tar.gz

# 启动客户端
./frpc -c frp/frpc.ini
```

### 使用Ngrok

```bash
# 安装ngrok
# 下载地址: https://ngrok.com/download

# 启动隧道
ngrok http 5001

# 获取公网地址
# 示例: https://abc123.ngrok.io
```

## 📊 性能监控

### 系统监控

```bash
# GPU使用情况
nvidia-smi

# 内存使用情况
free -h

# 磁盘使用情况
df -h

# 进程监控
htop
```

### 服务监控

```bash
# 查看服务日志
tail -f logs/model_server.log

# 监控API请求
curl http://localhost:5001/metrics
```

## 🔧 故障排除

### 常见问题

1. **CUDA内存不足**
   ```bash
   # 减少批处理大小
   export MAX_BATCH_SIZE=1
   
   # 清理GPU缓存
   python -c "import torch; torch.cuda.empty_cache()"
   ```

2. **模型加载失败**
   ```bash
   # 检查模型文件
   python start_model_server.py --check-only
   
   # 重新下载模型
   python download_models.py
   ```

3. **网络连接问题**
   ```bash
   # 检查端口占用
   netstat -tulpn | grep 5001
   
   # 检查防火墙
   sudo ufw status
   ```

### 性能优化

1. **GPU优化**
   ```python
   # 启用混合精度
   export ENABLE_MIXED_PRECISION=true
   
   # 优化CUDA设置
   export CUDA_LAUNCH_BLOCKING=0
   ```

2. **内存优化**
   ```python
   # 启用内存映射
   export TORCH_USE_CUDA_DSA=1
   
   # 减少缓存大小
   export TORCH_CACHE_SIZE=1GB
   ```

## 🔒 安全配置

### API安全

1. **启用API密钥验证**
   ```env
   API_KEY=your-secret-api-key
   ENABLE_AUTH=true
   ```

2. **限制访问IP**
   ```env
   ALLOWED_IPS=192.168.1.100,10.0.0.1
   ```

3. **启用HTTPS**
   ```env
   SSL_CERT_PATH=/path/to/cert.pem
   SSL_KEY_PATH=/path/to/key.pem
   ```

### 防火墙配置

```bash
# 只允许特定IP访问
sudo ufw allow from 192.168.1.100 to any port 5001

# 或允许特定网段
sudo ufw allow from 192.168.1.0/24 to any port 5001
```

## 📋 维护指南

### 定期维护

1. **清理临时文件**
   ```bash
   # 清理缓存
   rm -rf temp/* cache/*
   
   # 清理日志
   find logs/ -name "*.log" -mtime +7 -delete
   ```

2. **更新模型**
   ```bash
   # 备份当前模型
   cp -r model model_backup_$(date +%Y%m%d)
   
   # 下载新模型
   python update_models.py
   ```

3. **性能测试**
   ```bash
   # 运行基准测试
   python benchmark.py
   
   # 生成性能报告
   python generate_report.py
   ```

### 备份策略

```bash
# 备份模型文件
tar -czf model_backup_$(date +%Y%m%d).tar.gz model/

# 备份配置文件
cp .env .env.backup.$(date +%Y%m%d)

# 自动备份脚本
crontab -e
# 添加: 0 2 * * 0 /path/to/backup_script.sh
```

## 📞 技术支持

### 日志分析

```bash
# 查看错误日志
grep "ERROR" logs/model_server.log

# 查看性能日志
grep "PERFORMANCE" logs/model_server.log

# 实时监控
tail -f logs/model_server.log | grep -E "(ERROR|WARNING)"
```

### 调试模式

```bash
# 启用详细日志
python start_model_server.py --debug --log-level DEBUG

# 启用性能分析
python start_model_server.py --profile

# 内存泄漏检测
python -m memory_profiler start_model_server.py
```

---

**重要提醒**: 
1. 确保GPU驱动和CUDA版本兼容
2. 定期监控GPU温度和使用率
3. 保持模型文件的完整性
4. 及时更新安全补丁