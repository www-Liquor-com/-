"""
本地GPU模型服务 - 独立的AI模型推理API
运行在本地GPU机器上，为云端服务提供AI模型推理能力
"""

from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import os
import cv2
import hashlib
import tempfile
import shutil
from datetime import datetime
from flasgger import Swagger, swag_from
import traceback
from typing import Any

# 导入模型处理函数
from ISC_Net.deepfake import deepfake_simswap, deepfake_faceshifter, deepfake_infoswap, deepfake_sdinpaint
from ISC_Net.test_on_image_embed_tl import embed_wm
from ISC_Net.embed_idfmark_whole import embed_idfmark
from ISC_Net.test_on_image_extract_tl import extract_wm
from ISC_Net.extract_idfmark_whole import extract_idfmark
from ISC_Net.id_recovery import recover_id
from utils.evaluate_img import ImageEvaluator

app = Flask(__name__)
CORS(app)  # 允许跨域请求

swagger = Swagger(app)

# 配置
MODEL_SERVER_PORT = 5001
TEMP_DIR = "temp_files"
os.makedirs(TEMP_DIR, exist_ok=True)
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024

def log_request(endpoint, status="SUCCESS", error=None):
    """记录请求日志"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    if error:
        print(f"[{timestamp}] {endpoint} - ERROR: {error}")
    else:
        print(f"[{timestamp}] {endpoint} - {status}")

def save_uploaded_file(file_data, prefix="temp"):
    """保存上传的文件到临时目录"""
    file_hash = hashlib.md5(file_data).hexdigest()
    filename = f"{prefix}_{file_hash}.png"
    filepath = os.path.join(TEMP_DIR, filename)
    
    with open(filepath, 'wb') as f:
        f.write(file_data)
    
    return filepath

def normalize_path(p: Any) -> str:
    """将模型返回的路径统一规范为字符串路径"""
    if isinstance(p, list) and len(p) > 0:
        p = p[0]
    if not isinstance(p, str):
        raise Exception("Model returned invalid path type")
    return p

@app.route('/health', methods=['GET'])
@swag_from({
    "summary": "健康检查",
    "description": "用于检测模型服务是否正常运行",
    "responses": {
        "200": {
            "description": "服务正常",
            "schema": {
                "type": "object",
                "properties": {
                    "status": {"type": "string", "example": "healthy"},
                    "service": {"type": "string", "example": "AI Model Server"},
                    "timestamp": {"type": "string", "example": "2025-10-01T10:00:00"}
                }
            }
        }
    }
})
def health_check():
    """健康检查接口"""
    return jsonify({
        "status": "healthy",
        "service": "AI Model Server",
        "timestamp": datetime.now().isoformat()
    })

# ==================== 深度伪造模型接口 ====================

@app.route('/api/deepfake/simswap', methods=['POST'])
@swag_from({
    "summary": "SimSwap深度伪造",
    "description": "上传图像进行 SimSwap 伪造，字段名 image（multipart/form-data）",
    "consumes": ["multipart/form-data"],
    "produces": ["image/png"],
    "parameters": [
        {"name": "image", "in": "formData", "type": "file", "required": True, "description": "输入图像（字段名：image）"}
    ],
    "responses": {
        "200": {"description": "返回伪造后的 PNG 图片"},
        "400": {"description": "缺少文件"},
        "500": {"description": "服务内部错误"}
    }
})
def api_deepfake_simswap():
    """SimSwap深度伪造接口"""
    try:
        if 'image' not in request.files:
            return jsonify({"error": "No image file provided"}), 400
        
        file = request.files['image']
        file_data = file.read()
        
        # 保存输入文件
        input_path = save_uploaded_file(file_data, "simswap_input")
        
        # 创建工作目录
        work_dir = os.path.join(TEMP_DIR, f"simswap_{hashlib.md5(file_data).hexdigest()}")
        os.makedirs(work_dir, exist_ok=True)
        
        # 调用模型
        image_input = [cv2.imread(input_path)]
        output_path = deepfake_simswap(image_input, save_folder=work_dir)
        output_path = normalize_path(output_path)
        
        if not output_path or not os.path.exists(output_path):
            raise Exception("Model inference failed")
        
        log_request("SimSwap")
        return send_file(output_path, mimetype='image/png')
        
    except Exception as e:
        log_request("SimSwap", "ERROR", str(e))
        return jsonify({"error": str(e)}), 500

@app.route('/api/v1/deepfake/faceshifter', methods=['POST'])
@swag_from({
    "summary": "FaceShifter深度伪造",
    "description": "上传图像进行 FaceShifter 伪造，字段名 image（multipart/form-data）",
    "consumes": ["multipart/form-data"],
    "produces": ["image/png"],
    "parameters": [
        {"name": "image", "in": "formData", "type": "file", "required": True, "description": "输入图像（字段名：image）"}
    ],
    "responses": {
        "200": {"description": "返回伪造后的 PNG 图片"},
        "400": {"description": "缺少文件"},
        "500": {"description": "服务内部错误"}
    }
})
def api_deepfake_faceshifter():
    """FaceShifter深度伪造接口"""
    try:
        if 'image' not in request.files:
            return jsonify({"error": "No image file provided"}), 400
        
        file = request.files['image']
        file_data = file.read()
        
        # 保存输入文件
        input_path = save_uploaded_file(file_data, "faceshifter_input")
        
        # 创建工作目录
        work_dir = os.path.join(TEMP_DIR, f"faceshifter_{hashlib.md5(file_data).hexdigest()}")
        os.makedirs(work_dir, exist_ok=True)
        
        # 调用模型
        image_input = [cv2.imread(input_path)]
        output_path = deepfake_faceshifter(image_input, save_folder=work_dir)
        output_path = normalize_path(output_path)
        
        if not output_path or not os.path.exists(output_path):
            raise Exception("Model inference failed")
        
        log_request("FaceShifter")
        return send_file(output_path, mimetype='image/png')
        
    except Exception as e:
        log_request("FaceShifter", "ERROR", str(e))
        return jsonify({"error": str(e)}), 500

@app.route('/api/v1/deepfake/infoswap', methods=['POST'])
@swag_from({
    "summary": "InfoSwap深度伪造",
    "description": "上传图像进行 InfoSwap 伪造，字段名 image（multipart/form-data）",
    "consumes": ["multipart/form-data"],
    "produces": ["image/png"],
    "parameters": [
        {"name": "image", "in": "formData", "type": "file", "required": True, "description": "输入图像（字段名：image）"}
    ],
    "responses": {
        "200": {"description": "返回伪造后的 PNG 图片"},
        "400": {"description": "缺少文件"},
        "500": {"description": "服务内部错误"}
    }
})
def api_deepfake_infoswap():
    """InfoSwap深度伪造接口"""
    try:
        if 'image' not in request.files:
            return jsonify({"error": "No image file provided"}), 400
        
        file = request.files['image']
        file_data = file.read()
        
        # 保存输入文件
        input_path = save_uploaded_file(file_data, "infoswap_input")
        
        # 创建工作目录
        work_dir = os.path.join(TEMP_DIR, f"infoswap_{hashlib.md5(file_data).hexdigest()}")
        os.makedirs(work_dir, exist_ok=True)
        
        # 调用模型
        image_input = [cv2.imread(input_path)]
        output_path = deepfake_infoswap(image_input, save_folder=work_dir)
        output_path = normalize_path(output_path)
        
        if not output_path or not os.path.exists(output_path):
            raise Exception("Model inference failed")
        
        log_request("InfoSwap")
        return send_file(output_path, mimetype='image/png')
        
    except Exception as e:
        log_request("InfoSwap", "ERROR", str(e))
        return jsonify({"error": str(e)}), 500

@app.route('/api/v1/deepfake/stablediffusion', methods=['POST'])
@swag_from({
    "summary": "Stable Diffusion 修复",
    "description": "上传图像与掩码进行 inpainting，字段名 image 与 mask（multipart/form-data）",
    "consumes": ["multipart/form-data"],
    "produces": ["image/png"],
    "parameters": [
        {"name": "image", "in": "formData", "type": "file", "required": True, "description": "输入图像（字段名：image）"},
        {"name": "mask", "in": "formData", "type": "file", "required": True, "description": "掩码图像（字段名：mask，灰度）"}
    ],
    "responses": {
        "200": {"description": "返回修复后的 PNG 图片"},
        "400": {"description": "缺少文件"},
        "500": {"description": "服务内部错误"}
    }
})
def api_deepfake_stablediffusion():
    """Stable Diffusion Inpainting接口"""
    try:
        if 'image' not in request.files or 'mask' not in request.files:
            return jsonify({"error": "Both image and mask files required"}), 400
        
        image_file = request.files['image']
        mask_file = request.files['mask']
        
        image_data = image_file.read()
        mask_data = mask_file.read()
        
        # 保存输入文件
        image_path = save_uploaded_file(image_data, "sd_input")
        mask_path = save_uploaded_file(mask_data, "sd_mask")
        
        # 创建工作目录
        work_dir = os.path.join(TEMP_DIR, f"sd_{hashlib.md5(image_data).hexdigest()}")
        os.makedirs(work_dir, exist_ok=True)
        
        # 调用模型
        img_cv2 = cv2.imread(image_path)
        mask_cv2 = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
        output_path = deepfake_sdinpaint([img_cv2], [mask_cv2], save_folder=work_dir)
        output_path = normalize_path(output_path)
        
        if not output_path or not os.path.exists(output_path):
            raise Exception("Model inference failed")
        
        log_request("StableDiffusion")
        return send_file(output_path, mimetype='image/png')
        
    except Exception as e:
        log_request("StableDiffusion", "ERROR", str(e))
        return jsonify({"error": str(e)}), 500

# ==================== 水印模型接口 ====================

@app.route('/api/watermark/embed', methods=['POST'])
@swag_from({
    "summary": "水印嵌入",
    "description": "上传图像进行水印嵌入。字段名必须为 image（multipart/form-data）",
    "consumes": ["multipart/form-data"],
    "produces": ["application/json"],
    "parameters": [
        {
            "name": "image",
            "in": "formData",
            "type": "file",
            "required": True,
            "description": "待嵌入水印的图像文件（字段名：image）"
        },
        {
            "name": "mode",
            "in": "formData",
            "type": "integer",
            "required": False,
            "default": 1,
            "description": "嵌入模式：1-篡改定位，2-身份恢复，3-双重水印"
        }
    ],
    "responses": {
        "200": {
            "description": "嵌入成功（返回是否可用标志与质量指标）",
            "schema": {
                "type": "object",
                "properties": {
                    "success": {"type": "boolean", "example": True},
                    "result_available": {"type": "boolean", "example": True},
                    "metrics": {"type": "object"}
                }
            }
        },
        "400": {"description": "缺少文件或参数错误"},
        "500": {"description": "服务内部错误"}
    }
})
def api_watermark_embed():
    """水印嵌入接口"""
    try:
        print(request.form.to_dict())
        if 'image' not in request.files:
            return jsonify({"error": "No image file provided"}), 400
        
        file = request.files['image']
        mode = int(request.form.get('mode', 1))  # 默认模式1
        
        file_data = file.read()
        input_path = save_uploaded_file(file_data, "embed_input")
        
        # 创建工作目录
        work_dir = os.path.join(TEMP_DIR, f"embed_{hashlib.md5(file_data).hexdigest()}")
        os.makedirs(work_dir, exist_ok=True)
        
        # 读取图像
        image_input = [cv2.imread(input_path)]
        
        # 根据模式选择水印嵌入方法
        if mode == 1:
            # 篡改定位水印
            result_path = embed_wm(image_input, image_input_h=None, message_input=None, save_folder=work_dir)
        elif mode == 2:
            # 身份恢复水印
            result_path = embed_idfmark(image_input, save_folder=work_dir)
        elif mode == 3:
            # 双重水印
            result_path1 = embed_wm(image_input, image_input_h=None, message_input=None, save_folder=work_dir)
            img1 = [cv2.imread(result_path1)]
            result_path = embed_idfmark(img1, save_folder=work_dir)
        else:
            return jsonify({"error": "Unsupported mode"}), 400
        
        if not result_path or not os.path.exists(result_path):
            raise Exception("Watermark embedding failed")
        
        # 计算图像质量指标
        try:
            evaluator = ImageEvaluator()
            metrics = evaluator.evaluate_images(
                img1_path=input_path, 
                img2_path=result_path, 
                quality_compare=True, 
                id_compare=False
            )
            quality_metrics = metrics.get('quality_metrics', {}) if metrics.get('success') else {}
        except Exception as e:
            quality_metrics = {"error": str(e)}
        
        log_request(f"WatermarkEmbed_Mode{mode}")
        
        # 读取结果图片并编码为 base64 data URI
        with open(result_path, "rb") as f:
            img_bytes = f.read()
        import base64
        b64 = base64.b64encode(img_bytes).decode("utf-8")
        data_uri = f"data:image/png;base64,{b64}"
        
        # 返回结果图片和质量指标（JSON）
        return jsonify({
            "success": True,
            "metrics": quality_metrics,
            "result_available": True,
            "watermarked_image": data_uri
        })
        
    except Exception as e:
        log_request("WatermarkEmbed", "ERROR", str(e))
        return jsonify({"error": str(e)}), 500

@app.route('/api/watermark/extract-tl', methods=['POST'])
@swag_from({
    "summary": "篡改定位水印提取",
    "description": "上传图像进行 TL 水印提取，字段名 image（multipart/form-data）",
    "consumes": ["multipart/form-data"],
    "produces": ["image/png"],
    "parameters": [
        {"name": "image", "in": "formData", "type": "file", "required": True, "description": "输入图像（字段名：image）"}
    ],
    "responses": {
        "200": {"description": "返回定位掩码 PNG 图片"},
        "400": {"description": "缺少文件"},
        "500": {"description": "服务内部错误"}
    }
})
def api_watermark_extract_tl():
    """篡改定位水印提取接口"""
    try:
        if 'image' not in request.files:
            return jsonify({"error": "No image file provided"}), 400
        
        file = request.files['image']
        file_data = file.read()
        
        input_path = save_uploaded_file(file_data, "extract_tl_input")
        
        # 创建工作目录
        work_dir = os.path.join(TEMP_DIR, f"extract_tl_{hashlib.md5(file_data).hexdigest()}")
        os.makedirs(work_dir, exist_ok=True)
        
        # 调用模型
        image_input = [cv2.imread(input_path)]
        mask_path = extract_wm(image_input, save_folder=work_dir)
        mask_path = normalize_path(mask_path)
        
        if not mask_path or not os.path.exists(mask_path):
            raise Exception("Tamper localization failed")
        
        log_request("ExtractTL")
        # 读取掩码并返回 JSON + base64
        with open(mask_path, "rb") as f:
            img_bytes = f.read()
        import base64
        b64 = base64.b64encode(img_bytes).decode("utf-8")
        data_uri = f"data:image/png;base64,{b64}"
        return jsonify({
            "success": True,
            "tamper_localization": data_uri
        })
        
    except Exception as e:
        log_request("ExtractTL", "ERROR", str(e))
        return jsonify({"error": str(e)}), 500

@app.route('/api/watermark/extract-ir', methods=['POST'])
@swag_from({
    "summary": "身份恢复水印提取",
    "description": "上传图像进行 IR 水印提取与身份恢复，字段名 image（multipart/form-data）",
    "consumes": ["multipart/form-data"],
    "produces": ["image/png"],
    "parameters": [
        {"name": "image", "in": "formData", "type": "file", "required": True, "description": "输入图像（字段名：image）"}
    ],
    "responses": {
        "200": {"description": "返回身份恢复后的 PNG 图片"},
        "400": {"description": "缺少文件"},
        "500": {"description": "服务内部错误"}
    }
})
def api_watermark_extract_ir():
    """身份恢复水印提取接口"""
    try:
        if 'image' not in request.files:
            return jsonify({"error": "No image file provided"}), 400
        
        file = request.files['image']
        file_data = file.read()
        
        input_path = save_uploaded_file(file_data, "extract_ir_input")
        
        # 创建工作目录
        work_dir = os.path.join(TEMP_DIR, f"extract_ir_{hashlib.md5(file_data).hexdigest()}")
        os.makedirs(work_dir, exist_ok=True)
        
        # 调用模型
        image_input = [cv2.imread(input_path)]
        
        # 提取身份信息
        decoded_features_list = extract_idfmark(image_input)
        
        # 身份恢复
        recovered_id_path = recover_id(image_input, decoded_features_list, save_folder=work_dir)
        recovered_id_path = normalize_path(recovered_id_path)
        
        if not recovered_id_path or not os.path.exists(recovered_id_path):
            raise Exception("Identity recovery failed")
        
        log_request("ExtractIR")
        # 读取恢复图并返回 JSON + base64
        with open(recovered_id_path, "rb") as f:
            img_bytes = f.read()
        import base64
        b64 = base64.b64encode(img_bytes).decode("utf-8")
        data_uri = f"data:image/png;base64,{b64}"
        return jsonify({
            "success": True,
            "identity_recovery": data_uri
        })
        
    except Exception as e:
        log_request("ExtractIR", "ERROR", str(e))
        return jsonify({"error": str(e)}), 500

# ==================== 图像评估接口 ====================

@app.route('/api/evaluate', methods=['POST'])
@swag_from({
    "summary": "图像质量评估",
    "description": "上传两张图像进行质量与身份评估，字段名 file1、file2；quality_compare、id_compare 为可选表单字段",
    "consumes": ["multipart/form-data"],
    "produces": ["application/json"],
    "parameters": [
        {"name": "file1", "in": "formData", "type": "file", "required": True, "description": "原图（字段名：file1）"},
        {"name": "file2", "in": "formData", "type": "file", "required": True, "description": "对比图（字段名：file2）"},
        {"name": "quality_compare", "in": "formData", "type": "integer", "required": False, "default": 1, "description": "是否评估质量（1/0）"},
        {"name": "id_compare", "in": "formData", "type": "integer", "required": False, "default": 1, "description": "是否评估身份（1/0）"}
    ],
    "responses": {
        "200": {"description": "返回评估结果 JSON"},
        "400": {"description": "缺少文件"},
        "500": {"description": "服务内部错误"}
    }
})
def api_evaluate_images():
    """图像质量评估接口"""
    try:
        if 'file1' not in request.files or 'file2' not in request.files:
            return jsonify({"error": "Two image files required"}), 400
        
        file1 = request.files['file1']
        file2 = request.files['file2']
        quality_compare = bool(int(request.form.get('quality_compare', 1)))
        id_compare = bool(int(request.form.get('id_compare', 1)))
        
        # 保存文件
        file1_path = save_uploaded_file(file1.read(), "eval1")
        file2_path = save_uploaded_file(file2.read(), "eval2")
        
        # 评估
        evaluator = ImageEvaluator()
        results = evaluator.evaluate_images(
            img1_path=file1_path,
            img2_path=file2_path,
            quality_compare=quality_compare,
            id_compare=id_compare
        )
        
        log_request("Evaluate")
        return jsonify(results)
        
    except Exception as e:
        log_request("Evaluate", "ERROR", str(e))
        return jsonify({"error": str(e)}), 500

@app.errorhandler(404)
def not_found(error):
    return jsonify({"error": "Endpoint not found"}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({"error": "Internal server error"}), 500

if __name__ == '__main__':
    print(f"🚀 AI Model Server starting on port {MODEL_SERVER_PORT}")
    print(f"📁 Temporary files directory: {TEMP_DIR}")
    print(f"🔗 Health check: http://localhost:{MODEL_SERVER_PORT}/health")
    print("=" * 50)
    
    app.run(
        host='0.0.0.0',
        port=MODEL_SERVER_PORT,
        debug=False,
        threaded=True
    )