#!/usr/bin/env python3
"""
本地GPU模型服务启动脚本
运行在本地GPU机器上，提供AI模型推理服务
"""

import os
import sys
import logging
import argparse
from pathlib import Path

# 添加项目根目录到Python路径
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

def setup_logging():
    """设置日志配置"""
    log_dir = project_root / "logs"
    log_dir.mkdir(exist_ok=True)
    
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_dir / "model_server.log"),
            logging.StreamHandler(sys.stdout)
        ]
    )
    return logging.getLogger(__name__)

def check_dependencies():
    """检查必要的依赖"""
    logger = logging.getLogger(__name__)
    
    try:
        import torch
        logger.info(f"PyTorch版本: {torch.__version__}")
        logger.info(f"CUDA可用: {torch.cuda.is_available()}")
        if torch.cuda.is_available():
            logger.info(f"GPU数量: {torch.cuda.device_count()}")
            logger.info(f"当前GPU: {torch.cuda.get_device_name()}")
    except ImportError:
        logger.error("PyTorch未安装，请先安装PyTorch")
        return False
    
    try:
        import cv2
        logger.info(f"OpenCV版本: {cv2.__version__}")
    except ImportError:
        logger.error("OpenCV未安装，请先安装opencv-python")
        return False
    
    try:
        from flask import Flask
        logger.info("Flask已安装")
    except ImportError:
        logger.error("Flask未安装，请先安装Flask")
        return False
    
    return True

def check_model_files():
    """检查模型文件是否存在"""
    logger = logging.getLogger(__name__)
    
    model_paths = [
        "ISC_Net/arcface_model",
        "ISC_Net/IdFMark",
        "ISC_Net/IR",
        "ISC_Net/TL"
    ]
    
    missing_models = []
    for model_path in model_paths:
        full_path = project_root / model_path
        if not full_path.exists():
            missing_models.append(model_path)
            logger.warning(f"模型目录不存在: {model_path}")
        else:
            logger.info(f"✓ 模型目录存在: {model_path}")
    
    if missing_models:
        logger.error(f"缺少模型文件: {missing_models}")
        logger.error("请确保所有模型文件都已正确复制到model目录")
        return False
    
    return True

def start_server(host="0.0.0.0", port=5001, debug=False):
    """启动模型服务器"""
    logger = logging.getLogger(__name__)
    
    try:
        # 导入模型服务器
        from model_server import app
        
        logger.info("="*50)
        logger.info("🚀 启动 Safety System 模型服务")
        logger.info("="*50)
        logger.info(f"📍 服务地址: http://{host}:{port}")
        logger.info(f"🔧 调试模式: {debug}")
        logger.info(f"📁 工作目录: {project_root}")
        logger.info("="*50)
        
        # 启动Flask应用
        app.run(
            host=host,
            port=port,
            debug=debug,
            threaded=True
        )
        
    except ImportError as e:
        logger.error(f"导入模型服务器失败: {e}")
        logger.error("请检查model_server.py文件是否存在且语法正确")
        return False
    except Exception as e:
        logger.error(f"启动服务器失败: {e}")
        return False

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="启动Safety System模型服务")
    parser.add_argument("--host", default="0.0.0.0", help="服务器主机地址")
    parser.add_argument("--port", type=int, default=5001, help="服务器端口")
    parser.add_argument("--debug", action="store_true", help="启用调试模式")
    parser.add_argument("--check-only", action="store_true", help="仅检查环境，不启动服务")
    
    args = parser.parse_args()
    
    # 设置日志
    logger = setup_logging()
    
    logger.info("开始启动模型服务...")
    
    # 检查依赖
    if not check_dependencies():
        logger.error("依赖检查失败，请安装必要的依赖包")
        sys.exit(1)
    
    # 检查模型文件
    if not check_model_files():
        logger.error("模型文件检查失败，请确保模型文件完整")
        sys.exit(1)
    
    if args.check_only:
        logger.info("✅ 环境检查完成，所有依赖和模型文件都正常")
        return
    
    # 启动服务器
    try:
        start_server(args.host, args.port, args.debug)
    except KeyboardInterrupt:
        logger.info("收到中断信号，正在关闭服务器...")
    except Exception as e:
        logger.error(f"服务器运行出错: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()