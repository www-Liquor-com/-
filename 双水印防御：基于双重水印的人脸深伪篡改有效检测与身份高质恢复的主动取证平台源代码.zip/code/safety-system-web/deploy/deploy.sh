#!/bin/bash
# 云端项目部署脚本

set -e

echo "开始部署 Safety System Web 到云服务器..."

# 项目配置
PROJECT_NAME="safety-system-web"
PROJECT_DIR="/opt/safety-system-web"
NGINX_CONF="/etc/nginx/sites-available/safety-system"
SYSTEMD_SERVICE="/etc/systemd/system/safety-system-web.service"

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查是否为root用户
if [ "$EUID" -ne 0 ]; then
    print_error "请使用root权限运行此脚本"
    exit 1
fi

# 1. 更新系统包
print_status "更新系统包..."
apt update && apt upgrade -y

# 2. 安装必要的软件
print_status "安装必要软件..."
apt install -y nginx python3 python3-pip python3-venv git curl nodejs npm

# 3. 创建项目目录
print_status "创建项目目录..."
mkdir -p $PROJECT_DIR
cd $PROJECT_DIR

# 4. 创建Python虚拟环境
print_status "创建Python虚拟环境..."
python3 -m venv venv
source venv/bin/activate

# 5. 安装Python依赖
print_status "安装Python依赖..."
pip install --upgrade pip
pip install -r backend/requirements.txt

# 6. 构建前端
print_status "构建前端应用..."
cd frontend
npm install
npm run build
cd ..

# 7. 配置Nginx
print_status "配置Nginx..."
cp deploy/nginx.conf $NGINX_CONF

# 更新Nginx配置中的路径
sed -i "s|/path/to/safety-system-web|$PROJECT_DIR|g" $NGINX_CONF
sed -i "s|/var/www/safety-system|$PROJECT_DIR/frontend/dist|g" $NGINX_CONF

# 启用站点
ln -sf $NGINX_CONF /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# 测试Nginx配置
nginx -t

# 8. 创建systemd服务
print_status "创建systemd服务..."
cat > $SYSTEMD_SERVICE << EOF
[Unit]
Description=Safety System Web API
After=network.target

[Service]
Type=exec
User=www-data
Group=www-data
WorkingDirectory=$PROJECT_DIR/backend
Environment=PATH=$PROJECT_DIR/venv/bin
ExecStart=$PROJECT_DIR/venv/bin/uvicorn main:app --host 0.0.0.0 --port 8000
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

# 9. 设置权限
print_status "设置文件权限..."
chown -R www-data:www-data $PROJECT_DIR
chmod -R 755 $PROJECT_DIR

# 10. 启动服务
print_status "启动服务..."
systemctl daemon-reload
systemctl enable safety-system-web
systemctl start safety-system-web
systemctl restart nginx

# 11. 检查服务状态
print_status "检查服务状态..."
sleep 3

if systemctl is-active --quiet safety-system-web; then
    print_status "✅ Safety System Web API 服务运行正常"
else
    print_error "❌ Safety System Web API 服务启动失败"
    systemctl status safety-system-web
fi

if systemctl is-active --quiet nginx; then
    print_status "✅ Nginx 服务运行正常"
else
    print_error "❌ Nginx 服务启动失败"
    systemctl status nginx
fi

# 12. 显示部署信息
print_status "部署完成！"
echo ""
echo "🌐 访问地址: http://$(curl -s ifconfig.me)"
echo "📁 项目目录: $PROJECT_DIR"
echo "📋 查看API日志: journalctl -u safety-system-web -f"
echo "📋 查看Nginx日志: tail -f /var/log/nginx/access.log"
echo ""
echo "⚠️  请记得："
echo "   1. 修改 backend/.env 中的 MODEL_SERVER_URL 为你的本地服务器地址"
echo "   2. 配置防火墙开放 80 端口"
echo "   3. 如需HTTPS，请配置SSL证书"
echo ""
print_status "部署脚本执行完成！"