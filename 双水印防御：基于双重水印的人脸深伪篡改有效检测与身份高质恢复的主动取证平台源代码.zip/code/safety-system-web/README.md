# Safety System Web - 云端部署项目

基于AI的面部篡改检测与取证系统 - 云端Web应用

## 🏗️ 项目架构

```
┌─────────────────┐    HTTP请求    ┌──────────────────┐
│   腾讯云服务器   │ ──────────────► │   本地GPU服务器   │
│                │                │                 │
│  ┌─────────────┐│                │ ┌─────────────── │
│  │   前端Vue   ││                │ │  AI模型推理   │ │
│  │   应用      ││                │ │  服务         │ │
│  └─────────────┘│                │ └─────────────── │
│  ┌─────────────┐│                │                 │
│  │  后端API    ││                │                 │
│  │  服务       ││                │                 │
│  └─────────────┘│                │                 │
└─────────────────┘                └──────────────────┘
```

## 📦 项目结构

```
safety-system-web/
├── frontend/                 # Vue.js前端应用
│   ├── src/
│   ├── public/
│   └── package.json
├── backend/                  # FastAPI后端服务
│   ├── app/
│   │   ├── api/             # API路由
│   │   ├── core/            # 核心配置
│   │   ├── models/          # 数据模型
│   │   └── utils/           # 工具函数
│   ├── main.py              # 应用入口
│   ├── requirements.txt     # Python依赖
│   └── .env                 # 环境配置
└── deploy/                  # 部署配置
    ├── nginx.conf           # Nginx配置
    └── deploy.sh            # 部署脚本
```

## 🚀 快速部署

### 1. 准备工作

确保你的腾讯云服务器满足以下要求：
- Ubuntu 20.04+ 或 CentOS 7+
- 4GB+ 内存
- 20GB+ 磁盘空间
- 已开放80端口

### 2. 上传项目文件

```bash
# 将项目文件上传到服务器
scp -r safety-system-web root@your-server-ip:/opt/
```

### 3. 运行部署脚本

```bash
# 登录服务器
ssh root@your-server-ip

# 进入项目目录
cd /opt/safety-system-web

# 给部署脚本执行权限
chmod +x deploy/deploy.sh

# 运行部署脚本
./deploy/deploy.sh
```

### 4. 配置模型服务器地址

```bash
# 编辑环境配置文件
nano backend/.env

# 修改MODEL_SERVER_URL为你的本地服务器地址
MODEL_SERVER_URL=http://your-home-ip:5001
```

### 5. 重启服务

```bash
systemctl restart safety-system-web
```

## ⚙️ 手动部署步骤

如果自动部署脚本失败，可以按以下步骤手动部署：

### 1. 安装依赖

```bash
# 更新系统
apt update && apt upgrade -y

# 安装必要软件
apt install -y nginx python3 python3-pip python3-venv nodejs npm
```

### 2. 配置Python环境

```bash
# 创建虚拟环境
cd /opt/safety-system-web
python3 -m venv venv
source venv/bin/activate

# 安装Python依赖
pip install -r backend/requirements.txt
```

### 3. 构建前端

```bash
cd frontend
npm install
npm run build
cd ..
```

### 4. 配置Nginx

```bash
# 复制配置文件
cp deploy/nginx.conf /etc/nginx/sites-available/safety-system

# 修改配置文件中的路径
sed -i 's|/path/to/safety-system-web|/opt/safety-system-web|g' /etc/nginx/sites-available/safety-system
sed -i 's|/var/www/safety-system|/opt/safety-system-web/frontend/dist|g' /etc/nginx/sites-available/safety-system

# 启用站点
ln -s /etc/nginx/sites-available/safety-system /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# 测试配置
nginx -t

# 重启Nginx
systemctl restart nginx
```

### 5. 配置系统服务

```bash
# 创建systemd服务文件
cat > /etc/systemd/system/safety-system-web.service << EOF
[Unit]
Description=Safety System Web API
After=network.target

[Service]
Type=exec
User=www-data
Group=www-data
WorkingDirectory=/opt/safety-system-web/backend
Environment=PATH=/opt/safety-system-web/venv/bin
ExecStart=/opt/safety-system-web/venv/bin/uvicorn main:app --host 0.0.0.0 --port 8000
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

# 设置权限
chown -R www-data:www-data /opt/safety-system-web

# 启动服务
systemctl daemon-reload
systemctl enable safety-system-web
systemctl start safety-system-web
```

## 🔧 配置说明

### 环境变量配置

编辑 `backend/.env` 文件：

```env
# 模型服务器地址 - 重要！
MODEL_SERVER_URL=http://your-home-ip:5001

# JWT密钥 - 生产环境必须修改
SECRET_KEY=your-super-secret-key

# 数据库配置
DATABASE_URL=sqlite:///./safety_system.db

# 其他配置...
```

### Nginx配置

主要配置项在 `deploy/nginx.conf`：
- 静态文件服务
- API代理转发
- 文件上传大小限制
- 安全头设置

## 📋 服务管理

### 查看服务状态

```bash
# 查看API服务状态
systemctl status safety-system-web

# 查看Nginx状态
systemctl status nginx

# 查看API日志
journalctl -u safety-system-web -f

# 查看Nginx日志
tail -f /var/log/nginx/access.log
tail -f /var/log/nginx/error.log
```

### 重启服务

```bash
# 重启API服务
systemctl restart safety-system-web

# 重启Nginx
systemctl restart nginx

# 重新加载Nginx配置
nginx -s reload
```

## 🔍 故障排除

### 常见问题

1. **API服务启动失败**
   ```bash
   # 检查Python依赖
   source venv/bin/activate
   pip install -r backend/requirements.txt
   
   # 检查配置文件
   cat backend/.env
   ```

2. **前端页面无法访问**
   ```bash
   # 检查Nginx配置
   nginx -t
   
   # 检查文件权限
   ls -la frontend/dist/
   ```

3. **模型服务连接失败**
   ```bash
   # 测试模型服务连接
   curl http://your-home-ip:5001/health
   
   # 检查防火墙设置
   ufw status
   ```

### 日志分析

```bash
# API服务日志
journalctl -u safety-system-web --since "1 hour ago"

# Nginx错误日志
tail -100 /var/log/nginx/error.log

# 系统日志
dmesg | tail -20
```

## 🔒 安全建议

1. **修改默认密钥**
   - 更改 `.env` 中的 `SECRET_KEY`
   - 使用强密码策略

2. **配置防火墙**
   ```bash
   ufw enable
   ufw allow 22    # SSH
   ufw allow 80    # HTTP
   ufw allow 443   # HTTPS (如果使用)
   ```

3. **启用HTTPS**
   - 申请SSL证书
   - 配置Nginx HTTPS

4. **定期更新**
   ```bash
   apt update && apt upgrade -y
   ```

## 📞 技术支持

如果遇到部署问题，请检查：
1. 服务器系统要求
2. 网络连接状态
3. 模型服务器配置
4. 日志文件内容

---

**注意**: 确保本地GPU模型服务正常运行，否则云端应用无法正常工作。