from fastapi import APIRouter, Depends, File, UploadFile, HTTPException
from fastapi.responses import JSONResponse
import os
import hashlib
import requests
import json
import time
from app.models.user import User
from app.utils.jwt import get_current_user
from app.core.config import settings

router = APIRouter()

def call_model_service(endpoint, files=None, data=None, timeout=60):
    """调用本地模型服务的通用函数"""
    try:
        url = f"{settings.MODEL_SERVER_URL}{endpoint}"
        response = requests.post(url, files=files, data=data, timeout=timeout)
        
        if response.status_code == 200:
            return response
        else:
            raise HTTPException(status_code=500, detail=f"模型服务错误: {response.text}")
            
    except requests.exceptions.Timeout:
        raise HTTPException(status_code=504, detail="模型服务响应超时")
    except requests.exceptions.ConnectionError:
        raise HTTPException(status_code=503, detail="无法连接到模型服务")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"调用模型服务失败: {str(e)}")

@router.post("/quality")
async def evaluate_image_quality(
    original: UploadFile = File(...),
    processed: UploadFile = File(...),
    current_user: User = Depends(get_current_user)
):
    """
    评估两张图像之间的质量指标（PSNR, SSIM, LPIPS等）。
    """
    try:
        # 准备文件数据
        original_content = await original.read()
        processed_content = await processed.read()
        
        files = {
            'original': (original.filename, original_content, original.content_type),
            'processed': (processed.filename, processed_content, processed.content_type)
        }
        
        # 调用本地模型服务进行质量评估
        response = call_model_service('/api/evaluate/quality', files=files)
        
        # 解析响应
        result = response.json()
        
        return JSONResponse({
            "success": True,
            "message": "图像质量评估完成",
            "metrics": result.get('metrics', {}),
            "analysis": result.get('analysis', {})
        })
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"图像质量评估失败: {e}")

@router.post("/similarity")
async def evaluate_face_similarity(
    image1: UploadFile = File(...),
    image2: UploadFile = File(...),
    current_user: User = Depends(get_current_user)
):
    """
    评估两张图像中人脸的相似度。
    """
    try:
        # 准备文件数据
        image1_content = await image1.read()
        image2_content = await image2.read()
        
        files = {
            'image1': (image1.filename, image1_content, image1.content_type),
            'image2': (image2.filename, image2_content, image2.content_type)
        }
        
        # 调用本地模型服务进行相似度评估
        response = call_model_service('/api/evaluate/similarity', files=files)
        
        # 解析响应
        result = response.json()
        
        return JSONResponse({
            "success": True,
            "message": "人脸相似度评估完成",
            "similarity": result.get('similarity', 0.0),
            "confidence": result.get('confidence', 0.0),
            "analysis": result.get('analysis', {})
        })
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"人脸相似度评估失败: {e}")

@router.post("/authenticity")
async def evaluate_image_authenticity(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user)
):
    """
    评估图像的真实性，检测是否为深度伪造。
    """
    try:
        # 准备文件数据
        file_content = await file.read()
        files = {'image': (file.filename, file_content, file.content_type)}
        
        # 调用本地模型服务进行真实性检测
        response = call_model_service('/api/evaluate/authenticity', files=files)
        
        # 解析响应
        result = response.json()
        
        return JSONResponse({
            "success": True,
            "message": "图像真实性评估完成",
            "authenticity_score": result.get('authenticity_score', 0.0),
            "is_fake": result.get('is_fake', False),
            "confidence": result.get('confidence', 0.0),
            "analysis": result.get('analysis', {})
        })
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"图像真实性评估失败: {e}")