from fastapi import APIRouter, Depends, File, UploadFile, HTTPException
from fastapi.responses import FileResponse
import os
import hashlib
import requests
import tempfile
from app.models.user import User
from app.utils.jwt import get_current_user
from app.core.config import settings

router = APIRouter()

def call_model_service(endpoint, files=None, data=None, timeout=60):
    """调用本地模型服务的通用函数"""
    try:
        url = f"{settings.MODEL_SERVER_URL}{endpoint}"
        response = requests.post(url, files=files, data=data, timeout=timeout)
        
        if response.status_code == 200:
            return response
        else:
            raise HTTPException(status_code=500, detail=f"模型服务错误: {response.text}")
            
    except requests.exceptions.Timeout:
        raise HTTPException(status_code=504, detail="模型服务响应超时")
    except requests.exceptions.ConnectionError:
        raise HTTPException(status_code=503, detail="无法连接到模型服务")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"调用模型服务失败: {str(e)}")

@router.post("/simswap")
async def simswap_deepfake(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user)
):
    """
    使用 SimSwap 对上传的图像进行深度伪造。
    """
    try:
        # 准备文件数据
        file_content = await file.read()
        files = {'image': (file.filename, file_content, file.content_type)}
        
        # 调用本地模型服务
        response = call_model_service('/api/deepfake/simswap', files=files)
        
        # 保存结果到用户工作目录
        uid = current_user.uid
        workfolder = os.path.join('media', f'{uid}_workfolder')
        os.makedirs(workfolder, exist_ok=True)
        
        file_hash = hashlib.md5(file_content).hexdigest()
        output_path = os.path.join(workfolder, f"{int(time.time() * 1000)}_{file_hash[:8]}_simswap_image.png")
        
        with open(output_path, 'wb') as f:
            f.write(response.content)
        
        return FileResponse(output_path, media_type="image/png", filename="deepfake_result.png")
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"深度伪造处理失败: {e}")

@router.post("/infoswap")
async def infoswap_deepfake(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user)
):
    """
    使用 InfoSwap 对上传的图像进行深度伪造。
    """
    try:
        # 准备文件数据
        file_content = await file.read()
        files = {'image': (file.filename, file_content, file.content_type)}
        
        # 调用本地模型服务
        response = call_model_service('/api/deepfake/infoswap', files=files)
        
        # 保存结果到用户工作目录
        uid = current_user.uid
        workfolder = os.path.join('media', f'{uid}_workfolder')
        os.makedirs(workfolder, exist_ok=True)
        
        file_hash = hashlib.md5(file_content).hexdigest()
        output_path = os.path.join(workfolder, f"{int(time.time() * 1000)}_{file_hash[:8]}_infoswap_image.png")
        
        with open(output_path, 'wb') as f:
            f.write(response.content)
        
        return FileResponse(output_path, media_type="image/png", filename="deepfake_result.png")
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"深度伪造处理失败: {e}")

@router.post("/faceshifter")
async def faceshifter_deepfake(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user)
):
    """
    使用 FaceShifter 对上传的图像进行深度伪造。
    """
    try:
        # 准备文件数据
        file_content = await file.read()
        files = {'image': (file.filename, file_content, file.content_type)}
        
        # 调用本地模型服务
        response = call_model_service('/api/deepfake/faceshifter', files=files)
        
        # 保存结果到用户工作目录
        uid = current_user.uid
        workfolder = os.path.join('media', f'{uid}_workfolder')
        os.makedirs(workfolder, exist_ok=True)
        
        file_hash = hashlib.md5(file_content).hexdigest()
        output_path = os.path.join(workfolder, f"{int(time.time() * 1000)}_{file_hash[:8]}_faceshifter_image.png")
        
        with open(output_path, 'wb') as f:
            f.write(response.content)
        
        return FileResponse(output_path, media_type="image/png", filename="deepfake_result.png")
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"深度伪造处理失败: {e}")

@router.post("/stablediffusion")
async def stablediffusion_deepfake(
    file: UploadFile = File(...),
    mask: UploadFile = File(...),
    current_user: User = Depends(get_current_user)
):
    """
    使用 Stable Diffusion Inpainting 对上传的图像进行深度伪造。
    前端需上传原始图像和掩码图像（单通道0/255）。
    """
    try:
        # 准备文件数据
        image_content = await file.read()
        mask_content = await mask.read()
        
        files = {
            'image': (file.filename, image_content, file.content_type),
            'mask': (mask.filename, mask_content, mask.content_type)
        }
        
        # 调用本地模型服务
        response = call_model_service('/api/deepfake/stablediffusion', files=files)
        
        # 保存结果到用户工作目录
        uid = current_user.uid
        workfolder = os.path.join('media', f'{uid}_workfolder')
        os.makedirs(workfolder, exist_ok=True)
        
        file_hash = hashlib.md5(image_content).hexdigest()
        output_path = os.path.join(workfolder, f"{int(time.time() * 1000)}_{file_hash[:8]}_mask_image.png")
        
        with open(output_path, 'wb') as f:
            f.write(response.content)
        
        return FileResponse(output_path, media_type="image/png", filename="deepfake_result.png")
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"深度伪造处理失败: {e}")

# 添加时间导入
import time