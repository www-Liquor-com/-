from fastapi import APIRouter, Depends, File, UploadFile, HTTPException
from fastapi.responses import JSONResponse
import os
import hashlib
import requests
import json
import time
from app.models.user import User
from app.utils.jwt import get_current_user
from app.core.config import settings

router = APIRouter()

def call_model_service(endpoint, files=None, data=None, timeout=60):
    """调用本地模型服务的通用函数"""
    try:
        url = f"{settings.MODEL_SERVER_URL}{endpoint}"
        response = requests.post(url, files=files, data=data, timeout=timeout)
        
        if response.status_code == 200:
            return response
        else:
            raise HTTPException(status_code=500, detail=f"模型服务错误: {response.text}")
            
    except requests.exceptions.Timeout:
        raise HTTPException(status_code=504, detail="模型服务响应超时")
    except requests.exceptions.ConnectionError:
        raise HTTPException(status_code=503, detail="无法连接到模型服务")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"调用模型服务失败: {str(e)}")

@router.post("/embed")
async def embed_watermark(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user)
):
    """
    对上传的图像进行水印嵌入。
    """
    try:
        # 准备文件数据
        file_content = await file.read()
        files = {'image': (file.filename, file_content, file.content_type)}
        
        # 调用本地模型服务进行水印嵌入
        response = call_model_service('/api/v1/watermark/embed', files=files)
        
        # 解析响应
        result = response.json()
        
        # 保存水印图像到用户工作目录
        uid = current_user.uid
        workfolder = os.path.join('media', f'{uid}_workfolder')
        os.makedirs(workfolder, exist_ok=True)
        
        file_hash = hashlib.md5(file_content).hexdigest()
        timestamp = int(time.time() * 1000)
        
        # 保存水印图像
        watermarked_filename = f"{timestamp}_{file_hash[:8]}_watermarked.png"
        watermarked_path = os.path.join(workfolder, watermarked_filename)
        
        # 从base64解码并保存图像
        import base64
        wm_val = result.get('watermarked_image')
        if not wm_val or not isinstance(wm_val, str):
            raise HTTPException(status_code=500, detail="模型未返回 watermarked_image")
        # 兼容 data URI 与纯 base64
        wm_b64 = wm_val.split(',', 1)[1] if wm_val.startswith('data:') else wm_val
        watermarked_data = base64.b64decode(wm_b64)
        with open(watermarked_path, 'wb') as f:
            f.write(watermarked_data)
        
        # 构建返回的URL
        watermarked_url = f"/media/{uid}_workfolder/{watermarked_filename}"
        
        return JSONResponse({
            "success": True,
            "message": "水印嵌入成功",
            "watermarked_image": watermarked_url,
            "metrics": result.get('metrics', {}),
            "embedding_info": result.get('embedding_info', {})
        })
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"水印嵌入失败: {e}")

@router.post("/detect")
async def detect_watermark(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user)
):
    """
    对上传的图像进行水印检测和篡改定位。
    """
    try:
        # 准备文件数据
        file_content = await file.read()
        files = {'image': (file.filename, file_content, file.content_type)}
        
        # 调用本地模型服务进行水印检测
        response = call_model_service('/api/watermark/extract-tl', files=files)
        
        # 解析响应
        result = response.json()
        
        # 保存检测结果图像到用户工作目录
        uid = current_user.uid
        workfolder = os.path.join('media', f'{uid}_workfolder')
        os.makedirs(workfolder, exist_ok=True)
        
        file_hash = hashlib.md5(file_content).hexdigest()
        timestamp = int(time.time() * 1000)
        
        # 保存篡改定位图像
        if 'tamper_localization' in result:
            tamper_filename = f"{timestamp}_{file_hash[:8]}_tamper_localization.png"
            tamper_path = os.path.join(workfolder, tamper_filename)
            
            import base64
            tl_val = result['tamper_localization']
            tl_b64 = tl_val.split(',', 1)[1] if isinstance(tl_val, str) and tl_val.startswith('data:') else tl_val
            tamper_data = base64.b64decode(tl_b64)
            with open(tamper_path, 'wb') as f:
                f.write(tamper_data)
            
            result['tamper_localization'] = f"/media/{uid}_workfolder/{tamper_filename}"
        
        # 保存身份恢复图像
        if 'identity_recovery' in result:
            identity_filename = f"{timestamp}_{file_hash[:8]}_identity_recovery.png"
            identity_path = os.path.join(workfolder, identity_filename)
            
            import base64
            ir_val = result['identity_recovery']
            ir_b64 = ir_val.split(',', 1)[1] if isinstance(ir_val, str) and ir_val.startswith('data:') else ir_val
            identity_data = base64.b64decode(ir_b64)
            with open(identity_path, 'wb') as f:
                f.write(identity_data)
            
            result['identity_recovery'] = f"/media/{uid}_workfolder/{identity_filename}"
        
        return JSONResponse({
            "success": True,
            "message": "水印检测完成",
            **result
        })
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"水印检测失败: {e}")

@router.post("/extract")
async def extract_watermark(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user)
):
    """
    从上传的图像中提取水印信息。
    """
    try:
        # 准备文件数据
        file_content = await file.read()
        files = {'image': (file.filename, file_content, file.content_type)}
        
        # 调用本地模型服务进行水印提取
        response = call_model_service('/api/watermark/extract-ir', files=files)
        
        # 解析响应
        result = response.json()
        
        return JSONResponse({
            "success": True,
            "message": "水印提取完成",
            **result
        })
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"水印提取失败: {e}")