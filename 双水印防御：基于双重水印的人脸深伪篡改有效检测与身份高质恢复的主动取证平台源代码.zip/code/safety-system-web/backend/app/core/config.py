import os
from pydantic import BaseSettings

class Settings(BaseSettings):
    # 应用基础配置
    APP_NAME: str = "Safety System Web API"
    VERSION: str = "1.0.0"
    DEBUG: bool = True
    
    # 服务器配置
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    
    # 数据库配置
    DATABASE_URL: str = "sqlite:///./safety_system.db"
    
    # JWT配置
    SECRET_KEY: str = "your-secret-key-here-change-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    
    # 文件上传配置
    UPLOAD_DIR: str = "media"
    MAX_FILE_SIZE: int = 50 * 1024 * 1024  # 50MB
    ALLOWED_EXTENSIONS: set = {".jpg", ".jpeg", ".png", ".bmp", ".tiff"}
    
    # 模型服务器配置 - 本地GPU服务器地址
    MODEL_SERVER_URL: str = os.getenv("MODEL_SERVER_URL", "http://localhost:5001")
    MODEL_SERVER_TIMEOUT: int = 60  # 模型推理超时时间（秒）
    
    # CORS配置
    CORS_ORIGINS: list = [
        "http://localhost:3000",
        "http://localhost:8080",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:8080",
        # 添加你的云服务器域名
        "https://your-domain.com",
        "http://your-domain.com"
    ]
    
    # 静态文件配置
    STATIC_DIR: str = "static"
    MEDIA_DIR: str = "media"
    
    # 日志配置
    LOG_LEVEL: str = "INFO"
    LOG_FILE: str = "logs/app.log"
    
    # 安全配置
    ALLOWED_HOSTS: list = ["*"]  # 生产环境中应该限制具体域名
    
    class Config:
        env_file = ".env"
        case_sensitive = True

# 创建全局配置实例
settings = Settings()

# 确保必要的目录存在
os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
os.makedirs(settings.STATIC_DIR, exist_ok=True)
os.makedirs(settings.MEDIA_DIR, exist_ok=True)
os.makedirs("logs", exist_ok=True)