const BASE_URL = 'http://localhost:8000/api/v1/auth'

export async function login({ email, password }) {
  const res = await fetch(`${BASE_URL}/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  })
  const data = await res.json()
  return { status: res.status, data }
}

export async function register({ email, username, password, password2 }) {
  const res = await fetch(`${BASE_URL}/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, username, password, password2 })
  })
  const data = await res.json()
  return { status: res.status, data }
} 