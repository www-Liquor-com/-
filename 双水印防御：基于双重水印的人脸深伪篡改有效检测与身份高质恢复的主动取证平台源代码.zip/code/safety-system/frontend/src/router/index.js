import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import LoginView from '../views/LoginView.vue'
import RegisterView from '../views/RegisterView.vue'
import DashboardView from '../views/DashboardView.vue'
import AppLayout from '../AppLayout.vue'
import EmbedView from '../views/EmbedView.vue'
import DeepfakeView from '../views/DeepfakeView.vue'
import TamperLocationView from '../views/TamperLocationView.vue'
import IdentityRecoveryView from '../views/IdentityRecoveryView.vue'
import RecordsView from '../views/RecordsView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView,
    },
    {
      path: '/login',
      name: 'login',
      component: LoginView,
    },
    {
      path: '/register',
      name: 'register',
      component: RegisterView,
    },
    {
      path: '/dashboard',
      name: 'dashboard',
      component: AppLayout,
      children: [
        {
          path: '',
          name: 'dashboard-home',
          component: DashboardView
        },
        {
          path: 'embed',
          name: 'embed',
          component: EmbedView
        },
        {
          path: 'forge',
          name: 'forge',
          component: DeepfakeView
        },
        {
          path: 'tamper',
          name: 'tamper',
          component: TamperLocationView
        },
        {
          path: 'recover',
          name: 'recover',
          component: IdentityRecoveryView
        },
        {
          path: 'records',
          name: 'records',
          component: RecordsView
        },
        // 预留其他功能子路由
      ]
    },
  ],
})

export default router
