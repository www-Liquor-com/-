<script setup>
import { RouterView } from 'vue-router'
</script>

<template>
  <RouterView />
</template>

<style scoped>
/* 保留空样式，后续可根据需要添加全局样式 */
</style>
