<template>
  <div class="layout-bg">
    <!-- 动态背景效果 -->
    <div class="cyber-particles"></div>
    <div class="cyber-hexgrid"></div>

    <!-- 顶部状态栏 -->
    <div class="status-bar">
      <div class="system-status">
        <div class="status-item">
          <div class="status-dot-enhanced status-active"></div>
          <span>系统在线</span>
        </div>
        <div class="status-item">
          <div class="status-dot-enhanced status-active"></div>
          <span>AI引擎运行中</span>
        </div>
        <div class="status-item">
          <div class="status-dot-enhanced status-warning"></div>
          <span>安全模式</span>
        </div>
      </div>
      <div class="system-time">
        <i class="ri-time-line"></i>
        <span>{{ currentTime }}</span>
      </div>
    </div>

    <!-- 导航菜单 -->
    <div class="menu-bar">
      <div class="menu-center">
        <nav class="cyber-nav-enhanced">
          <div class="nav-item"
               :class="{ active: $route.name === 'dashboard' }"
               @click="$router.push('/dashboard')">
            <i class="ri-dashboard-3-line"></i>
            <span>控制板</span>
            <div class="nav-glow"></div>
          </div>
          <div class="nav-item"
               :class="{ active: $route.name === 'embed' }"
               @click="$router.push('/dashboard/embed')">
            <i class="ri-shield-star-line"></i>
            <span>水印嵌入</span>
            <div class="nav-glow"></div>
          </div>
          <div class="nav-item"
               :class="{ active: $route.name === 'forge' }"
               @click="$router.push('/dashboard/forge')">
            <i class="ri-sword-line"></i>
            <span>伪造模拟</span>
            <div class="nav-glow"></div>
          </div>
          <div class="nav-item"
               :class="{ active: $route.name === 'tamper' }"
               @click="$router.push('/dashboard/tamper')">
            <i class="ri-focus-3-line"></i>
            <span>篡改定位</span>
            <div class="nav-glow"></div>
          </div>
          <div class="nav-item"
               :class="{ active: $route.name === 'recover' }"
               @click="$router.push('/dashboard/recover')">
            <i class="ri-user-search-line"></i>
            <span>身份恢复</span>
            <div class="nav-glow"></div>
          </div>
          <div class="nav-item"
               :class="{ active: $route.name === 'records' }"
               @click="$router.push('/dashboard/records')">
            <i class="ri-file-shield-2-line"></i>
            <span>水印记录</span>
            <div class="nav-glow"></div>
          </div>
        </nav>
      </div>
      <button class="logout-btn-enhanced" @click="logout">
        <i class="ri-logout-circle-r-line"></i>
        <span>安全退出</span>
        <div class="btn-scan-line"></div>
      </button>
    </div>
    <!-- 主内容区域 -->
    <main class="layout-main">
      <div class="content-wrapper">
        <router-view />
      </div>

      <!-- 底部装饰线 -->
      <div class="footer-decoration">
        <div class="decoration-line"></div>
        <div class="decoration-text">FORENSIC SECURITY SYSTEM v2.0</div>
        <div class="decoration-line"></div>
      </div>
    </main>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()
const currentTime = ref('')

function updateTime() {
  const now = new Date()
  currentTime.value = now.toLocaleTimeString('zh-CN', {
    hour12: false,
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  })
}

function logout() {
  localStorage.removeItem('token')
  router.push('/login')
}

let timeInterval = null

onMounted(() => {
  updateTime()
  timeInterval = setInterval(updateTime, 1000)
})

onUnmounted(() => {
  if (timeInterval) {
    clearInterval(timeInterval)
  }
})
</script>

<style scoped>
@import '@/assets/enhanced-cyber-theme.css';

.layout-bg {
  min-height: 100vh;
  background:
    radial-gradient(ellipse at top, #232946 0%, #121629 50%, #0a0e1a 100%),
    linear-gradient(45deg, rgba(0, 234, 255, 0.02) 0%, transparent 50%, rgba(0, 80, 255, 0.02) 100%);
  color: var(--cyber-text-primary);
  font-family: 'Orbitron', 'Share Tech Mono', 'Consolas', monospace;
  position: relative;
  overflow-x: hidden;
}

/* 动态背景效果 */
.cyber-particles {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 0;
  background:
    radial-gradient(2px 2px at 20px 30px, rgba(0, 234, 255, 0.4), transparent),
    radial-gradient(2px 2px at 40px 70px, rgba(0, 80, 255, 0.3), transparent),
    radial-gradient(1px 1px at 90px 40px, rgba(255, 0, 110, 0.3), transparent),
    radial-gradient(1px 1px at 130px 80px, rgba(0, 234, 255, 0.2), transparent),
    radial-gradient(2px 2px at 160px 30px, rgba(0, 80, 255, 0.4), transparent);
  background-repeat: repeat;
  background-size: 200px 100px;
  animation: dataFlow 25s linear infinite;
}

.cyber-hexgrid {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 0;
  background-image:
    radial-gradient(circle at 25% 25%, rgba(0, 234, 255, 0.08) 2px, transparent 2px),
    radial-gradient(circle at 75% 75%, rgba(0, 80, 255, 0.06) 2px, transparent 2px);
  background-size: 80px 80px;
  background-position: 0 0, 40px 40px;
}

/* 顶部状态栏 */
.status-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 2rem;
  background: rgba(18, 22, 41, 0.95);
  border-bottom: 1px solid rgba(0, 234, 255, 0.2);
  backdrop-filter: blur(15px);
  position: relative;
  z-index: 10;
}

.system-status {
  display: flex;
  gap: 2rem;
}

.status-item {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 1px;
  color: var(--cyber-text-secondary);
  font-weight: 600;
}

.status-dot-enhanced {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  position: relative;
}

.status-dot-enhanced.status-active {
  background: var(--cyber-success);
  box-shadow: 0 0 10px var(--cyber-success);
  animation: breathe 2s ease-in-out infinite;
}

.status-dot-enhanced.status-warning {
  background: var(--cyber-warning);
  box-shadow: 0 0 10px var(--cyber-warning);
  animation: breathe 2s ease-in-out infinite;
}

.system-time {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  color: var(--cyber-text-accent);
  font-weight: 700;
  font-family: 'Orbitron', monospace;
}

/* 导航菜单增强版 */
.menu-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1.5rem 2rem;
  position: relative;
  z-index: 10;
}

.menu-center {
  flex: 1;
  display: flex;
  justify-content: center;
}

.cyber-nav-enhanced {
  display: flex;
  gap: 0.5rem;
  padding: 1rem;
  background: rgba(18, 22, 41, 0.95);
  border-radius: 20px;
  border: 2px solid rgba(0, 234, 255, 0.3);
  box-shadow:
    0 15px 40px rgba(0, 0, 0, 0.4),
    0 0 30px rgba(0, 234, 255, 0.2),
    inset 0 1px 0 rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(20px);
  position: relative;
  overflow: hidden;
}

.cyber-nav-enhanced::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 2px;
  background: var(--cyber-gradient-primary);
}

.nav-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  padding: 1rem 1.5rem;
  border-radius: 15px;
  cursor: pointer;
  transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  position: relative;
  overflow: hidden;
  background: rgba(30, 40, 80, 0.6);
  border: 1px solid transparent;
  color: var(--cyber-text-secondary);
  font-weight: 600;
  min-width: 100px;
}

.nav-item i {
  font-size: 1.5rem;
  transition: all 0.3s ease;
}

.nav-item span {
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 1px;
  transition: all 0.3s ease;
}

.nav-glow {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: var(--cyber-gradient-primary);
  opacity: 0;
  transition: opacity 0.3s ease;
  border-radius: 15px;
  z-index: -1;
}

.nav-item:hover,
.nav-item.active {
  color: white;
  border-color: var(--cyber-primary);
  transform: translateY(-3px) scale(1.05);
  box-shadow:
    0 10px 25px rgba(0, 234, 255, 0.3),
    0 0 20px rgba(0, 234, 255, 0.2);
}

.nav-item:hover .nav-glow,
.nav-item.active .nav-glow {
  opacity: 1;
}

.nav-item:hover i,
.nav-item.active i {
  text-shadow: 0 0 15px currentColor;
  transform: scale(1.1);
}

/* 退出按钮增强版 */
.logout-btn-enhanced {
  top: 24px;
  right: 24px;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 20px;
  background: linear-gradient(135deg, var(--cyber-danger) 0%, #ff6b6b 100%);
  border: none;
  border-radius: 15px;
  color: white;
  font-family: 'Orbitron', monospace;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
  cursor: pointer;
  transition: all 0.4s ease;
  position: absolute;
  overflow: hidden;
  box-shadow:
    0 8px 25px rgba(255, 77, 79, 0.3),
    inset 0 1px 0 rgba(255, 255, 255, 0.2);
}

.logout-btn-enhanced:hover {
  transform: translateY(-2px) scale(1.05);
  box-shadow:
    0 12px 30px rgba(255, 77, 79, 0.4),
    0 0 25px rgba(255, 77, 79, 0.3);
}

.btn-scan-line {
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
  transition: left 0.6s ease;
}

.logout-btn-enhanced:hover .btn-scan-line {
  left: 100%;
}

/* 主内容区域 */
.layout-main {
  max-width: 1400px;
  margin: 2rem auto 0 auto;
  padding: 0 2rem 2rem 2rem;
  position: relative;
  z-index: 5;
}

.content-wrapper {
  background: var(--cyber-gradient-card);
  border-radius: 25px;
  padding: 2.5rem;
  border: 2px solid rgba(0, 234, 255, 0.3);
  box-shadow:
    0 20px 60px rgba(0, 0, 0, 0.4),
    0 0 40px rgba(0, 234, 255, 0.2),
    inset 0 1px 0 rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(20px);
  min-height: 65vh;
  position: relative;
  overflow: hidden;
}

.content-wrapper::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 3px;
  background: var(--cyber-gradient-primary);
}

.content-wrapper::after {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background:
    linear-gradient(45deg, transparent 49%, rgba(0, 234, 255, 0.02) 50%, transparent 51%),
    linear-gradient(-45deg, transparent 49%, rgba(0, 80, 255, 0.01) 50%, transparent 51%);
  background-size: 30px 30px;
  pointer-events: none;
  opacity: 0.5;
}

/* 底部装饰 */
.footer-decoration {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 2rem;
  margin-top: 3rem;
  padding: 2rem 0;
}

.decoration-line {
  flex: 1;
  height: 2px;
  background: var(--cyber-gradient-primary);
  border-radius: 1px;
  opacity: 0.6;
}

.decoration-text {
  font-size: 12px;
  color: var(--cyber-text-muted);
  text-transform: uppercase;
  letter-spacing: 2px;
  font-weight: 600;
  font-family: 'Orbitron', monospace;
}

/* 响应式设计 */
@media (max-width: 1200px) {
  .layout-main {
    max-width: 100%;
    margin: 1.5rem auto 0 auto;
    padding: 0 1.5rem 1.5rem 1.5rem;
  }

  .content-wrapper {
    padding: 2rem;
  }
}

@media (max-width: 768px) {
  .status-bar {
    padding: 0.8rem 1rem;
    flex-direction: column;
    gap: 1rem;
  }

  .system-status {
    gap: 1rem;
  }

  .menu-bar {
    padding: 1rem;
    flex-direction: column;
    gap: 1.5rem;
  }

  .cyber-nav-enhanced {
    flex-wrap: wrap;
    gap: 0.5rem;
    padding: 0.8rem;
  }

  .nav-item {
    min-width: 80px;
    padding: 0.8rem 1rem;
  }

  .nav-item i {
    font-size: 1.2rem;
  }

  .nav-item span {
    font-size: 10px;
  }

  .content-wrapper {
    padding: 1.5rem;
    border-radius: 20px;
  }

  .footer-decoration {
    margin-top: 2rem;
    padding: 1.5rem 0;
  }

  .decoration-text {
    font-size: 10px;
  }
}

@media (max-width: 480px) {
  .cyber-nav-enhanced {
    grid-template-columns: repeat(3, 1fr);
  }

  .nav-item {
    min-width: 70px;
    padding: 0.6rem 0.8rem;
  }

  .content-wrapper {
    padding: 1rem;
  }
}

/* 动画关键帧 */
@keyframes dataFlow {
  0% { background-position: 0% 50%; }
  100% { background-position: 100% 50%; }
}

@keyframes breathe {
  0%, 100% {
    opacity: 0.8;
    transform: scale(1);
  }
  50% {
    opacity: 1;
    transform: scale(1.2);
  }
}
</style>
