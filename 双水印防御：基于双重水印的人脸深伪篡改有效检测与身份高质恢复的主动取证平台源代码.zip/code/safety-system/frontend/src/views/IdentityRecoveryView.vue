<template>
  <div class="ir-bg">
    <!-- 页面标题区域 -->
    <div class="page-header">
      <div class="header-decoration">
        <div class="deco-line"></div>
        <div class="header-icon">
          <i class="ri-user-search-line"></i>
        </div>
        <div class="deco-line"></div>
      </div>
      <h1 class="page-title">
        <span class="title-main">IDENTITY RECOVERY</span>
        <span class="title-sub">身份恢复系统</span>
      </h1>
      <div class="security-badge">RECOVERY MODE</div>
    </div>

    <!-- 主要操作区域 -->
    <div class="main-workspace">
      <!-- 上传区域 -->
      <div class="upload-workspace cyber-glass-card">
        <div class="workspace-header">
          <h3 class="workspace-title">
            <i class="ri-upload-cloud-2-line"></i>
            图像上传区域
          </h3>
          <div class="status-indicator">
            <div class="status-dot" :class="{ active: file }"></div>
            <span>{{ file ? '已上传' : '待上传' }}</span>
          </div>
        </div>

        <div class="upload-container">
          <div class="image-preview-enhanced">
            <div v-if="originUrl" class="preview-wrapper">
              <img :src="originUrl" alt="原始图片" class="preview-image" />
              <div class="image-overlay">
                <div class="image-info">
                  <i class="ri-image-line"></i>
                  <span>待恢复图像</span>
                </div>
              </div>
            </div>
            <div v-else class="upload-placeholder">
              <div class="placeholder-icon">
                <i class="ri-image-add-line"></i>
              </div>
              <div class="placeholder-text">
                <h4>拖拽图片到此处或点击上传</h4>
                <p>支持 JPG、PNG 格式，建议尺寸 512x512</p>
              </div>
              <div class="scan-animation"></div>
            </div>
          </div>

          <div class="upload-controls">
            <el-upload
              class="upload-btn-enhanced"
              :show-file-list="false"
              :before-upload="beforeUpload"
              :on-change="onFileChange"
              :auto-upload="false"
            >
              <button class="cyber-btn-enhanced">
                <i class="ri-upload-2-line"></i>
                <span>选择图片</span>
              </button>
            </el-upload>
          </div>
        </div>
      </div>

      <!-- 恢复区域 -->
      <div class="recovery-workspace cyber-glass-card">
        <div class="workspace-header">
          <h3 class="workspace-title">
            <i class="ri-user-search-line"></i>
            身份恢复
          </h3>
        </div>

        <div class="recovery-content">
          <div class="recovery-info">
            <div class="info-item">
              <div class="info-icon">
                <i class="ri-user-search-line"></i>
              </div>
              <div class="info-text">
                <h4>身份重建</h4>
                <p>从篡改图像恢复真实身份</p>
              </div>
            </div>

            <div class="info-item">
              <div class="info-icon">
                <i class="ri-brain-line"></i>
              </div>
              <div class="info-text">
                <h4>特征恢复</h4>
                <p>重建原始人脸特征数据</p>
              </div>
            </div>
          </div>

          <div class="action-section">
            <button
              class="recovery-btn-enhanced"
              :class="{ loading: loading, disabled: !file }"
              :disabled="!file || loading"
              @click="onExtract"
            >
              <div class="btn-content">
                <i class="ri-user-search-line" v-if="!loading"></i>
                <i class="ri-loader-4-line rotating" v-else></i>
                <span>{{ loading ? '正在恢复...' : '开始身份恢复' }}</span>
              </div>
              <div class="btn-progress" v-if="loading"></div>
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- 结果展示区域 -->
    <div v-if="resultUrl" class="result-workspace">
      <div class="result-header">
        <h2 class="result-title">
          <i class="ri-check-double-line"></i>
          恢复结果
        </h2>
        <div class="result-status success">
          <i class="ri-shield-check-fill"></i>
          <span>身份恢复完成</span>
        </div>
      </div>

      <!-- 图像对比 -->
      <div class="image-comparison cyber-glass-card">
        <div class="comparison-container">
          <div class="image-panel">
            <div class="panel-header">
              <h4>篡改图像</h4>
              <div class="panel-badge tampered">TAMPERED</div>
            </div>
            <div class="image-container">
              <img :src="originUrl" alt="原始图片" class="comparison-image" />
              <div class="image-scan-line"></div>
            </div>
          </div>

          <div class="comparison-arrow">
            <div class="arrow-container">
              <i class="ri-arrow-right-line"></i>
              <div class="arrow-glow"></div>
            </div>
          </div>

          <div class="image-panel">
            <div class="panel-header">
              <h4>恢复图像</h4>
              <div class="panel-badge recovered">RECOVERED</div>
            </div>
            <div class="image-container">
              <img :src="resultUrl" alt="恢复图片" class="comparison-image" />
              <div class="image-scan-line"></div>
            </div>
          </div>
        </div>
      </div>

      <!-- 质量评估面板 -->
      <div class="evaluation-panel cyber-glass-card">
        <div class="evaluation-header">
          <h3>
            <i class="ri-bar-chart-line"></i>
            质量评估
          </h3>
        </div>

        <div class="evaluation-content">
          <div class="evaluation-upload">
            <button
              class="evaluate-btn-enhanced"
              :class="{ loading: evaluateLoading }"
              :disabled="evaluateLoading"
              @click="triggerEvaluateInput"
            >
              <div class="btn-content">
                <i class="ri-upload-line" v-if="!evaluateLoading"></i>
                <i class="ri-loader-4-line rotating" v-else></i>
                <span>{{ evaluateLoading ? '评估中...' : '上传原始图像评估质量' }}</span>
              </div>
            </button>
            <input
              ref="evaluateInput"
              type="file"
              accept="image/*"
              style="display:none"
              @change="onEvaluateFileChange"
            />
          </div>

          <div v-if="identityScore !== null" class="score-display">
            <div class="score-item">
              <div class="score-icon">
                <i class="ri-user-heart-line"></i>
              </div>
              <div class="score-content">
                <div class="score-label">身份相似度</div>
                <div class="score-value">{{ identityScore }}</div>
                <div class="score-desc">恢复质量指标</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- 安全提醒 -->
      <div class="security-notice cyber-glass-card">
        <div class="notice-icon">
          <i class="ri-shield-check-line"></i>
        </div>
        <div class="notice-content">
          <h4>安全提醒</h4>
          <p>身份恢复图像仅用于学术研究与安全取证，请勿用于非法用途。</p>
        </div>
      </div>

      <!-- 操作按钮 -->
      <div class="result-actions">
        <button class="download-btn-enhanced" @click="downloadResult">
          <i class="ri-download-2-line"></i>
          <span>下载恢复图像</span>
          <div class="btn-glow"></div>
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { ElMessage } from 'element-plus'
import { extractIdentityRecovery, evaluateImage } from '../api/watermark'

const file = ref(null)
const originUrl = ref('')
const resultUrl = ref('')
const loading = ref(false)
const identityScore = ref(null)
const evaluateLoading = ref(false)
const evaluateInput = ref(null)

function beforeUpload(rawFile) {
  return true
}

function onFileChange(uploadFile) {
  file.value = uploadFile.raw
  originUrl.value = URL.createObjectURL(uploadFile.raw)
  resultUrl.value = ''
  identityScore.value = null
}

async function onExtract() {
  if (!file.value) {
    ElMessage.error('请先上传图片')
    return
  }
  loading.value = true
  try {
    const res = await extractIdentityRecovery({ file: file.value })
    if (res.status === 200) {
      const blob = await res.blob()
      resultUrl.value = URL.createObjectURL(blob)
      ElMessage.success('身份恢复成功')
    } else {
      ElMessage.error('身份恢复失败')
    }
  } catch (e) {
    ElMessage.error('网络错误，请稍后重试')
  } finally {
    loading.value = false
  }
}

function downloadResult() {
  if (!resultUrl.value) return
  const a = document.createElement('a')
  a.href = resultUrl.value
  a.download = 'recovered_id.png'
  a.click()
}

async function onEvaluateFileChange(e) {
  const file1 = e.target.files[0]
  if (!file1) return
  if (!resultUrl.value) {
    ElMessage.error('请先恢复身份图像')
    return
  }
  evaluateLoading.value = true
  try {
    // 获取恢复图像的blob
    const recoveredImg = await fetch(resultUrl.value).then(r => r.blob())
    const res = await evaluateImage({ file1, file2: recoveredImg, quality_compare: 0, id_compare: 1 })
    if (res.status === 200 && res.data && res.data.identity_metrics) {
      identityScore.value = res.data.identity_metrics.Face_Similarity
      ElMessage.success('评估成功')
    } else {
      identityScore.value = null
      ElMessage.error('评估失败')
    }
  } catch (e) {
    identityScore.value = null
    ElMessage.error('网络错误，请稍后重试')
  } finally {
    evaluateLoading.value = false
    // 清空input值，便于下次选择同一文件也能触发change
    e.target.value = ''
  }
}

function triggerEvaluateInput() {
  if (evaluateInput.value) evaluateInput.value.click()
}
</script>

<style scoped>
@import '@/assets/enhanced-cyber-theme.css';

.ir-bg {
  min-height: 80vh;
  padding: 0;
  background: transparent;
  display: flex;
  flex-direction: column;
  gap: 3rem;
}

/* 页面标题区域 */
.page-header {
  text-align: center;
  padding: 2rem 0;
  position: relative;
}

.header-decoration {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 2rem;
  margin-bottom: 2rem;
}

.deco-line {
  flex: 1;
  max-width: 150px;
  height: 2px;
  background: var(--cyber-gradient-primary);
  border-radius: 1px;
}

.header-icon {
  font-size: 3rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  animation: breathe 3s ease-in-out infinite;
}

.page-title {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 1.5rem;
}

.title-main {
  font-size: 2.8rem;
  font-weight: 900;
  text-transform: uppercase;
  letter-spacing: 3px;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  font-family: 'Orbitron', monospace;
}

.title-sub {
  font-size: 1.2rem;
  color: var(--cyber-text-secondary);
  letter-spacing: 2px;
  font-weight: 600;
}

.security-badge {
  background: var(--cyber-gradient-accent);
  color: white;
  padding: 8px 20px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 2px;
  box-shadow: 0 0 20px rgba(255, 0, 110, 0.4);
  animation: breathe 4s ease-in-out infinite;
}

/* 主工作区域 */
.main-workspace {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 3rem;
  margin-bottom: 3rem;
}

.cyber-glass-card {
  background: var(--cyber-gradient-glass);
  backdrop-filter: blur(20px);
  border: 2px solid rgba(0, 234, 255, 0.3);
  border-radius: 25px;
  padding: 2.5rem;
  box-shadow:
    0 20px 60px rgba(0, 0, 0, 0.4),
    0 0 40px rgba(0, 234, 255, 0.2);
  position: relative;
  overflow: hidden;
}

.cyber-glass-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 3px;
  background: var(--cyber-gradient-primary);
}

.workspace-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid rgba(0, 234, 255, 0.2);
}

.workspace-title {
  display: flex;
  align-items: center;
  gap: 1rem;
  font-size: 1.3rem;
  color: var(--cyber-text-primary);
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.workspace-title i {
  font-size: 1.5rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
}

.status-indicator {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.9rem;
  color: var(--cyber-text-secondary);
  text-transform: uppercase;
  letter-spacing: 1px;
  font-weight: 600;
}

.status-dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: var(--cyber-text-muted);
  transition: all 0.3s ease;
}

.status-dot.active {
  background: var(--cyber-success);
  box-shadow: 0 0 15px var(--cyber-success);
  animation: breathe 2s ease-in-out infinite;
}

/* 上传区域 */
.upload-container {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

.image-preview-enhanced {
  width: 100%;
  height: 300px;
  border-radius: 20px;
  border: 2px dashed rgba(0, 234, 255, 0.3);
  position: relative;
  overflow: hidden;
  transition: all 0.4s ease;
}

.image-preview-enhanced:hover {
  border-color: var(--cyber-primary);
  box-shadow: 0 0 30px rgba(0, 234, 255, 0.3);
}

.preview-wrapper {
  width: 100%;
  height: 100%;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
}

.preview-image {
  max-width: 100%;
  max-height: 100%;
  object-fit: contain;
  border-radius: 15px;
}

.image-overlay {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  background: linear-gradient(transparent, rgba(0, 0, 0, 0.8));
  padding: 1rem;
  display: flex;
  justify-content: center;
}

.image-info {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  color: var(--cyber-primary);
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.upload-placeholder {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  position: relative;
}

.placeholder-icon {
  font-size: 4rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  margin-bottom: 1.5rem;
  animation: floatUp 3s ease-in-out infinite;
}

.placeholder-text h4 {
  font-size: 1.2rem;
  color: var(--cyber-text-primary);
  margin-bottom: 0.5rem;
  font-weight: 600;
}

.placeholder-text p {
  color: var(--cyber-text-secondary);
  font-size: 0.9rem;
}

.scan-animation {
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(0, 234, 255, 0.1), transparent);
  animation: scanLine 3s ease-in-out infinite;
}

.upload-controls {
  display: flex;
  justify-content: center;
}

.cyber-btn-enhanced {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 15px 30px;
  background: var(--cyber-gradient-primary);
  border: none;
  border-radius: 15px;
  color: white;
  font-family: 'Orbitron', monospace;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
  cursor: pointer;
  transition: all 0.4s ease;
  box-shadow: 0 8px 25px rgba(0, 234, 255, 0.3);
}

.cyber-btn-enhanced:hover {
  transform: translateY(-3px) scale(1.05);
  box-shadow: 0 15px 35px rgba(0, 234, 255, 0.4);
}

/* 恢复区域 */
.recovery-content {
  display: flex;
  flex-direction: column;
  gap: 2.5rem;
}

.recovery-info {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

.info-item {
  display: flex;
  align-items: center;
  gap: 1.5rem;
  padding: 1.5rem;
  background: rgba(30, 40, 80, 0.6);
  border: 1px solid rgba(0, 234, 255, 0.3);
  border-radius: 15px;
  transition: all 0.4s ease;
}

.info-item:hover {
  border-color: var(--cyber-primary);
  transform: translateX(5px);
  box-shadow: 0 5px 15px rgba(0, 234, 255, 0.2);
}

.info-icon {
  font-size: 2rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  min-width: 50px;
  display: flex;
  justify-content: center;
}

.info-text h4 {
  font-size: 1.1rem;
  color: var(--cyber-text-primary);
  margin-bottom: 0.3rem;
  font-weight: 700;
}

.info-text p {
  color: var(--cyber-text-secondary);
  font-size: 0.9rem;
  margin: 0;
}

.action-section {
  display: flex;
  justify-content: center;
}

.recovery-btn-enhanced {
  width: 100%;
  padding: 18px;
  background: var(--cyber-gradient-primary);
  border: none;
  border-radius: 15px;
  color: white;
  font-family: 'Orbitron', monospace;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 2px;
  cursor: pointer;
  transition: all 0.4s ease;
  position: relative;
  overflow: hidden;
  box-shadow: 0 10px 30px rgba(0, 234, 255, 0.3);
}

.recovery-btn-enhanced:hover:not(.disabled) {
  transform: translateY(-3px);
  box-shadow: 0 15px 40px rgba(0, 234, 255, 0.4);
}

.recovery-btn-enhanced.disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.btn-content {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1rem;
  position: relative;
  z-index: 2;
}

.btn-progress {
  position: absolute;
  bottom: 0;
  left: 0;
  height: 3px;
  background: var(--cyber-gradient-accent);
  animation: progressBar 2s ease-in-out infinite;
}

.rotating {
  animation: rotate 1s linear infinite;
}

/* 结果展示区域 */
.result-workspace {
  display: flex;
  flex-direction: column;
  gap: 2.5rem;
}

.result-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.5rem 0;
}

.result-title {
  display: flex;
  align-items: center;
  gap: 1rem;
  font-size: 2rem;
  color: var(--cyber-primary);
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 2px;
  text-shadow: var(--cyber-glow-primary);
}

.result-status {
  display: flex;
  align-items: center;
  gap: 0.8rem;
  padding: 10px 20px;
  border-radius: 20px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.result-status.success {
  background: rgba(0, 255, 136, 0.1);
  color: var(--cyber-success);
  border: 1px solid var(--cyber-success);
  box-shadow: 0 0 15px rgba(0, 255, 136, 0.3);
}

/* 图像对比 */
.image-comparison {
  margin-bottom: 2rem;
}

.comparison-container {
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  gap: 3rem;
  align-items: center;
}

.image-panel {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.panel-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.panel-header h4 {
  font-size: 1.2rem;
  color: var(--cyber-text-primary);
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
  margin: 0;
}

.panel-badge {
  padding: 4px 12px;
  border-radius: 15px;
  font-size: 10px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.panel-badge.tampered {
  background: rgba(255, 69, 0, 0.2);
  color: rgba(255, 69, 0, 0.9);
  border: 1px solid rgba(255, 69, 0, 0.5);
}

.panel-badge.recovered {
  background: rgba(0, 255, 136, 0.2);
  color: var(--cyber-success);
  border: 1px solid var(--cyber-success);
}

.image-container {
  position: relative;
  border-radius: 20px;
  overflow: hidden;
  border: 2px solid rgba(0, 234, 255, 0.3);
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
}

.comparison-image {
  width: 100%;
  height: 300px;
  object-fit: contain;
  background: var(--cyber-bg-primary);
}

.image-scan-line {
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(0, 234, 255, 0.2), transparent);
  animation: scanLine 4s ease-in-out infinite;
}

.comparison-arrow {
  display: flex;
  justify-content: center;
  align-items: center;
}

.arrow-container {
  position: relative;
  font-size: 3rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  animation: floatUp 2s ease-in-out infinite;
}

.arrow-glow {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 60px;
  height: 60px;
  background: radial-gradient(circle, rgba(0, 234, 255, 0.2) 0%, transparent 70%);
  border-radius: 50%;
  animation: breathe 3s ease-in-out infinite;
}

/* 质量评估面板 */
.evaluation-panel {
  margin-bottom: 2rem;
}

.evaluation-header {
  margin-bottom: 2rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid rgba(0, 234, 255, 0.2);
}

.evaluation-header h3 {
  display: flex;
  align-items: center;
  gap: 1rem;
  font-size: 1.3rem;
  color: var(--cyber-text-primary);
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
  margin: 0;
}

.evaluation-header i {
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
}

.evaluation-content {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

.evaluation-upload {
  display: flex;
  justify-content: center;
}

.evaluate-btn-enhanced {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 15px 30px;
  background: var(--cyber-gradient-accent);
  border: none;
  border-radius: 15px;
  color: white;
  font-family: 'Orbitron', monospace;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
  cursor: pointer;
  transition: all 0.4s ease;
  box-shadow: 0 8px 25px rgba(255, 0, 110, 0.3);
}

.evaluate-btn-enhanced:hover:not(.loading) {
  transform: translateY(-3px) scale(1.05);
  box-shadow: 0 15px 35px rgba(255, 0, 110, 0.4);
}

.evaluate-btn-enhanced.loading {
  opacity: 0.8;
  cursor: not-allowed;
}

.score-display {
  display: flex;
  justify-content: center;
}

.score-item {
  display: flex;
  align-items: center;
  gap: 2rem;
  padding: 2rem;
  background: rgba(30, 40, 80, 0.6);
  border: 2px solid rgba(0, 234, 255, 0.3);
  border-radius: 20px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
  transition: all 0.4s ease;
}

.score-item:hover {
  border-color: var(--cyber-primary);
  box-shadow: 0 15px 40px rgba(0, 234, 255, 0.2);
}

.score-icon {
  font-size: 3rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
}

.score-content {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.score-label {
  font-size: 1rem;
  color: var(--cyber-text-secondary);
  text-transform: uppercase;
  letter-spacing: 1px;
  font-weight: 600;
}

.score-value {
  font-size: 2.5rem;
  color: var(--cyber-primary);
  font-weight: 900;
  text-shadow: var(--cyber-glow-primary);
  font-family: 'Orbitron', monospace;
}

.score-desc {
  font-size: 0.9rem;
  color: var(--cyber-text-muted);
  font-style: italic;
}

/* 安全提醒 */
.security-notice {
  display: flex;
  align-items: center;
  gap: 2rem;
  padding: 2rem;
  background: rgba(255, 165, 0, 0.1);
  border: 2px solid rgba(255, 165, 0, 0.3);
  border-radius: 20px;
  margin-bottom: 2rem;
}

.notice-icon {
  font-size: 3rem;
  color: rgba(255, 165, 0, 0.9);
  text-shadow: 0 0 15px rgba(255, 165, 0, 0.5);
}

.notice-content h4 {
  font-size: 1.2rem;
  color: var(--cyber-text-primary);
  margin-bottom: 0.5rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.notice-content p {
  color: var(--cyber-text-secondary);
  line-height: 1.5;
  margin: 0;
}

/* 操作按钮 */
.result-actions {
  display: flex;
  justify-content: center;
  padding: 2rem 0;
}

.download-btn-enhanced {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 18px 35px;
  background: var(--cyber-gradient-primary);
  border: none;
  border-radius: 20px;
  color: white;
  font-family: 'Orbitron', monospace;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 2px;
  cursor: pointer;
  transition: all 0.4s ease;
  position: relative;
  overflow: hidden;
  box-shadow: 0 10px 30px rgba(0, 234, 255, 0.3);
}

.download-btn-enhanced:hover {
  transform: translateY(-5px) scale(1.05);
  box-shadow: 0 20px 50px rgba(0, 234, 255, 0.4);
}

.btn-glow {
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
  transition: left 0.6s ease;
}

.download-btn-enhanced:hover .btn-glow {
  left: 100%;
}

/* 响应式设计 */
@media (max-width: 1200px) {
  .main-workspace {
    grid-template-columns: 1fr;
    gap: 2rem;
  }

  .comparison-container {
    grid-template-columns: 1fr;
    gap: 2rem;
  }

  .comparison-arrow {
    transform: rotate(90deg);
  }
}

@media (max-width: 768px) {
  .ir-bg {
    gap: 2rem;
  }

  .page-header {
    padding: 1.5rem 0;
  }

  .title-main {
    font-size: 2.2rem;
    letter-spacing: 2px;
  }

  .title-sub {
    font-size: 1rem;
  }

  .cyber-glass-card {
    padding: 2rem;
  }

  .workspace-header {
    flex-direction: column;
    gap: 1rem;
    text-align: center;
  }

  .image-preview-enhanced {
    height: 250px;
  }

  .result-header {
    flex-direction: column;
    gap: 1rem;
    text-align: center;
  }

  .recovery-info {
    gap: 1rem;
  }

  .info-item {
    flex-direction: column;
    text-align: center;
    gap: 1rem;
  }

  .score-item {
    flex-direction: column;
    text-align: center;
    gap: 1rem;
  }

  .security-notice {
    flex-direction: column;
    text-align: center;
    gap: 1rem;
  }
}

@media (max-width: 480px) {
  .title-main {
    font-size: 1.8rem;
  }

  .cyber-glass-card {
    padding: 1.5rem;
  }

  .image-preview-enhanced {
    height: 200px;
  }

  .comparison-image {
    height: 200px;
  }
}

/* 动画关键帧 */
@keyframes breathe {
  0%, 100% {
    opacity: 0.8;
    transform: scale(1);
  }
  50% {
    opacity: 1;
    transform: scale(1.05);
  }
}

@keyframes floatUp {
  0%, 100% {
    transform: translateY(0px);
  }
  50% {
    transform: translateY(-10px);
  }
}

@keyframes scanLine {
  0% {
    left: -100%;
    opacity: 0;
  }
  50% {
    opacity: 1;
  }
  100% {
    left: 100%;
    opacity: 0;
  }
}

@keyframes progressBar {
  0% { width: 0%; }
  50% { width: 70%; }
  100% { width: 100%; }
}

@keyframes rotate {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}
</style>
