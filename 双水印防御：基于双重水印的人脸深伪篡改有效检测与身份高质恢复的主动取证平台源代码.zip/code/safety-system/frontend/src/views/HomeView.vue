<script setup>
import SciFiHeader from '../components/SciFiHeader.vue'

// 浮动元素样式生成
function getFloatStyle(index) {
  const positions = [
    { top: '15%', left: '10%', animationDelay: '0s' },
    { top: '25%', right: '15%', animationDelay: '1s' },
    { top: '45%', left: '8%', animationDelay: '2s' },
    { top: '60%', right: '12%', animationDelay: '0.5s' },
    { top: '75%', left: '20%', animationDelay: '1.5s' },
    { top: '35%', right: '25%', animationDelay: '2.5s' }
  ]

  return {
    ...positions[index - 1],
    animationDuration: `${4 + Math.random() * 2}s`
  }
}

// 浮动元素图标
function getFloatIcon(index) {
  const icons = [
    'ri-shield-line',
    'ri-cpu-line',
    'ri-lock-line',
    'ri-eye-line',
    'ri-fingerprint-line',
    'ri-scan-line'
  ]

  return icons[index - 1]
}
</script>

<template>
  <div class="main-bg">
    <!-- 动态背景效果 -->
    <div class="cyber-particles-home"></div>
    <div class="cyber-grid-bg"></div>
    <div class="floating-elements">
      <div class="float-element" v-for="i in 6" :key="i" :style="getFloatStyle(i)">
        <i :class="getFloatIcon(i)"></i>
      </div>
    </div>

    <SciFiHeader />

    <!-- 主内容区域 -->
    <section class="hero-section">

      <!-- 主标题区域 -->
      <div class="title-container">
        <div class="title-decoration-top">
          <div class="deco-line"></div>
          <div class="deco-diamond">◆</div>
          <div class="deco-line"></div>
        </div>

        <p class="system-subtitle">ADVANCED DEEPFAKE DETECTION & IDENTITY RECOVERY</p>
        <h1 class="hero-title">
          <span class="title-line-1">人脸深度伪造主动取证平台</span>
          <span class="title-glow"></span>
        </h1>
        <p class="system-description">基于篡改定位与身份恢复双重水印的智能取证系统</p>

        <div class="title-decoration-bottom">
          <div class="deco-line"></div>
          <div class="deco-text">DUAL WATERMARK TECHNOLOGY</div>
          <div class="deco-line"></div>
        </div>
      </div>

      <!-- 特性展示 -->
      <div class="features-grid">
        <div class="feature-item">
          <div class="feature-icon">
            <i class="ri-shield-star-line"></i>
          </div>
          <div class="feature-text">
            <h3>水印嵌入</h3>
            <p>不可见水印保护</p>
          </div>
        </div>
        <div class="feature-item">
          <div class="feature-icon">
            <i class="ri-focus-3-line"></i>
          </div>
          <div class="feature-text">
            <h3>篡改定位</h3>
            <p>精确检测伪造区域</p>
          </div>
        </div>
        <div class="feature-item">
          <div class="feature-icon">
            <i class="ri-user-search-line"></i>
          </div>
          <div class="feature-text">
            <h3>身份恢复</h3>
            <p>重建真实身份信息</p>
          </div>
        </div>
        <div class="feature-item">
          <div class="feature-icon">
            <i class="ri-cpu-line"></i>
          </div>
          <div class="feature-text">
            <h3>AI驱动</h3>
            <p>深度学习算法</p>
          </div>
        </div>
      </div>

      <!-- 安全认证标识 -->
      <div class="security-certifications">
        <div class="cert-item">
          <i class="ri-shield-check-fill"></i>
          <span>ISO 27001认证</span>
        </div>
        <div class="cert-item">
          <i class="ri-lock-2-fill"></i>
          <span>256位加密</span>
        </div>
        <div class="cert-item">
          <i class="ri-verified-badge-fill"></i>
          <span>AI安全认证</span>
        </div>
      </div>
    </section>

    <!-- 底部装饰 -->
    <div class="bottom-decoration">
      <div class="scan-line"></div>
      <div class="footer-text">POWERED BY ADVANCED AI TECHNOLOGY</div>
    </div>
  </div>
</template>

<style scoped>
@import '@/assets/enhanced-cyber-theme.css';

.main-bg {
  min-height: 100vh;
  background:
    radial-gradient(ellipse at top, #232946 0%, #121629 40%, #0a0e1a 100%),
    linear-gradient(45deg, rgba(0, 234, 255, 0.03) 0%, transparent 50%, rgba(0, 80, 255, 0.02) 100%);
  color: var(--cyber-text-primary);
  font-family: 'Orbitron', 'Share Tech Mono', 'Consolas', monospace;
  position: relative;
  overflow: hidden;
}

/* 动态背景效果 */
.cyber-particles-home {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 0;
  background:
    radial-gradient(3px 3px at 30px 50px, rgba(0, 234, 255, 0.5), transparent),
    radial-gradient(2px 2px at 80px 120px, rgba(0, 80, 255, 0.4), transparent),
    radial-gradient(1px 1px at 150px 80px, rgba(255, 0, 110, 0.4), transparent),
    radial-gradient(2px 2px at 200px 160px, rgba(0, 234, 255, 0.3), transparent),
    radial-gradient(3px 3px at 250px 40px, rgba(0, 80, 255, 0.5), transparent);
  background-repeat: repeat;
  background-size: 300px 200px;
  animation: dataFlow 30s linear infinite;
}

.cyber-grid-bg {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 0;
  background-image:
    linear-gradient(rgba(0, 234, 255, 0.1) 1px, transparent 1px),
    linear-gradient(90deg, rgba(0, 234, 255, 0.1) 1px, transparent 1px);
  background-size: 100px 100px;
  opacity: 0.3;
}

/* 浮动元素 */
.floating-elements {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 1;
}

.float-element {
  position: absolute;
  font-size: 2rem;
  color: rgba(0, 234, 255, 0.3);
  animation: floatUp 6s ease-in-out infinite;
}

.float-element i {
  filter: drop-shadow(0 0 10px currentColor);
}

/* 主内容区域 */
.hero-section {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 85vh;
  padding: 2rem;
  position: relative;
  z-index: 10;
}

/* 系统标识 */
.system-badge {
  display: flex;
  align-items: center;
  gap: 1rem;
  background: rgba(18, 22, 41, 0.95);
  border: 2px solid rgba(0, 234, 255, 0.4);
  border-radius: 25px;
  padding: 1rem 2rem;
  margin-bottom: 3rem;
  backdrop-filter: blur(20px);
  box-shadow:
    0 10px 30px rgba(0, 0, 0, 0.3),
    0 0 30px rgba(0, 234, 255, 0.2);
  animation: breathe 4s ease-in-out infinite;
}

.badge-text {
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
}

.badge-version {
  font-size: 0.8rem;
  color: var(--cyber-text-secondary);
  text-transform: uppercase;
  letter-spacing: 1px;
}

/* 标题容器 */
.title-container {
  text-align: center;
  margin-top: -30px;
  margin-bottom: 4rem;
  position: relative;
}

.title-decoration-top {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 2rem;
  margin-bottom: 2rem;
}

.deco-line {
  width: 100px;
  height: 2px;
  background: var(--cyber-gradient-primary);
  border-radius: 1px;
}

.deco-diamond {
  font-size: 1.5rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  animation: rotateGlow 8s linear infinite;
}

.system-subtitle {
  font-size: 1rem;
  color: var(--cyber-text-secondary);
  text-transform: uppercase;
  letter-spacing: 3px;
  margin-bottom: 1.5rem;
  font-weight: 600;
  margin-top: -20px;
  opacity: 0.9;
}

.hero-title {
  position: relative;
  margin: 2rem 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
}

.title-line-1,
.title-line-2 {
  font-size: 4rem;
  font-weight: 900;
  text-transform: uppercase;
  letter-spacing: 4px;
  color: var(--cyber-primary);
  text-shadow:
    0 0 30px var(--cyber-primary),
    0 0 60px var(--cyber-secondary),
    0 0 90px var(--cyber-primary);
  font-family: 'Orbitron', monospace;
  animation: hologramGlow 5s ease-in-out infinite;
  position: relative;
}

.title-line-2 {
  animation-delay: 0.5s;
}

.title-glow {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 120%;
  height: 120%;
  background: radial-gradient(ellipse, rgba(0, 234, 255, 0.1) 0%, transparent 70%);
  border-radius: 50%;
  animation: breathe 6s ease-in-out infinite;
  z-index: -1;
}

.system-description {
  font-size: 1.3rem;
  color: var(--cyber-text-secondary);
  margin-bottom: 2rem;
  text-shadow: 0 0 10px rgba(0, 234, 255, 0.3);
  font-weight: 500;
  line-height: 1.6;
}

.title-decoration-bottom {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 2rem;
  margin-top: 2rem;
}

.deco-text {
  font-size: 0.9rem;
  color: var(--cyber-text-muted);
  text-transform: uppercase;
  letter-spacing: 2px;
  font-weight: 600;
}

/* 特性网格 */
.features-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 2rem;
  margin-bottom: 4rem;
  max-width: 1200px;
  width: 100%;
}

.feature-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  padding: 2rem 1.5rem;
  background: rgba(18, 22, 41, 0.8);
  border: 1px solid rgba(0, 234, 255, 0.3);
  border-radius: 20px;
  backdrop-filter: blur(15px);
  transition: all 0.4s ease;
  position: relative;
  overflow: hidden;
}

.feature-item::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 2px;
  background: var(--cyber-gradient-primary);
}

.feature-item:hover {
  transform: translateY(-10px) scale(1.05);
  border-color: var(--cyber-primary);
  box-shadow:
    0 15px 40px rgba(0, 0, 0, 0.3),
    0 0 30px rgba(0, 234, 255, 0.3);
}

.feature-icon {
  font-size: 3rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  margin-bottom: 1rem;
  position: relative;
}

.feature-icon::after {
  content: '';
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 80px;
  height: 80px;
  background: radial-gradient(circle, rgba(0, 234, 255, 0.1) 0%, transparent 70%);
  border-radius: 50%;
  animation: breathe 3s ease-in-out infinite;
}

.feature-text h3 {
  font-size: 1.2rem;
  color: var(--cyber-text-primary);
  margin-bottom: 0.5rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.feature-text p {
  font-size: 0.9rem;
  color: var(--cyber-text-secondary);
  line-height: 1.4;
}

/* 操作按钮 */
.action-buttons {
  display: flex;
  gap: 2rem;
  margin-bottom: 4rem;
}

.primary-btn,
.secondary-btn {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 18px 35px;
  border: none;
  border-radius: 20px;
  font-family: 'Orbitron', monospace;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 2px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  font-size: 1.1rem;
}

.primary-btn {
  background: var(--cyber-gradient-primary);
  color: white;
  box-shadow:
    0 10px 30px rgba(0, 234, 255, 0.3),
    inset 0 1px 0 rgba(255, 255, 255, 0.2);
}

.primary-btn:hover {
  transform: translateY(-5px) scale(1.05);
  box-shadow:
    0 20px 50px rgba(0, 234, 255, 0.4),
    0 0 40px rgba(0, 234, 255, 0.3);
}

.secondary-btn {
  background: transparent;
  color: var(--cyber-primary);
  border: 2px solid var(--cyber-primary);
  box-shadow:
    0 10px 30px rgba(0, 0, 0, 0.2),
    inset 0 0 20px rgba(0, 234, 255, 0.1);
}

.secondary-btn:hover {
  transform: translateY(-5px) scale(1.05);
  background: rgba(0, 234, 255, 0.1);
  box-shadow:
    0 20px 50px rgba(0, 0, 0, 0.3),
    0 0 40px rgba(0, 234, 255, 0.2);
}

.btn-glow {
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
  transition: left 0.6s ease;
}

.primary-btn:hover .btn-glow {
  left: 100%;
}

.btn-scan {
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(0, 234, 255, 0.3), transparent);
  transition: left 0.6s ease;
}

.secondary-btn:hover .btn-scan {
  left: 100%;
}

.btn-icon {
  font-size: 1.3rem;
  transition: transform 0.3s ease;
}

.primary-btn:hover .btn-icon,
.secondary-btn:hover .btn-icon {
  transform: translateX(5px);
}

/* 安全认证 */
.security-certifications {
  display: flex;
  gap: 3rem;
  justify-content: center;
  flex-wrap: wrap;
}

.cert-item {
  display: flex;
  align-items: center;
  gap: 0.8rem;
  font-size: 0.9rem;
  color: var(--cyber-text-secondary);
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.cert-item i {
  font-size: 1.2rem;
  color: var(--cyber-success);
  text-shadow: 0 0 10px var(--cyber-success);
}

/* 底部装饰 */
.bottom-decoration {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  padding: 2rem;
  text-align: center;
  z-index: 5;
}

.scan-line {
  width: 100%;
  height: 2px;
  background: var(--cyber-gradient-primary);
  margin-bottom: 1rem;
  position: relative;
  overflow: hidden;
}

.scan-line::after {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.8), transparent);
  animation: scanLine 3s ease-in-out infinite;
}

.footer-text {
  font-size: 0.8rem;
  color: var(--cyber-text-muted);
  text-transform: uppercase;
  letter-spacing: 2px;
  font-weight: 600;
}

/* 响应式设计 */
@media (max-width: 1200px) {
  .hero-section {
    padding: 1.5rem;
  }

  .title-line-1,
  .title-line-2 {
    font-size: 3.5rem;
    letter-spacing: 3px;
  }
}

@media (max-width: 768px) {
  .hero-section {
    padding: 1rem;
    min-height: 90vh;
  }

  .system-badge {
    flex-direction: column;
    text-align: center;
    padding: 1.5rem;
    margin-bottom: 2rem;
  }

  .title-decoration-top,
  .title-decoration-bottom {
    gap: 1rem;
  }

  .deco-line {
    width: 60px;
  }

  .title-line-1,
  .title-line-2 {
    font-size: 2.8rem;
    letter-spacing: 2px;
  }

  .system-description {
    font-size: 1.1rem;
    padding: 0 1rem;
  }

  .features-grid {
    grid-template-columns: repeat(2, 1fr);
    gap: 1.5rem;
    margin-bottom: 3rem;
  }

  .feature-item {
    padding: 1.5rem 1rem;
  }

  .feature-icon {
    font-size: 2.5rem;
  }

  .action-buttons {
    flex-direction: column;
    gap: 1.5rem;
    width: 100%;
    max-width: 300px;
  }

  .primary-btn,
  .secondary-btn {
    width: 100%;
    justify-content: center;
    padding: 16px 30px;
    font-size: 1rem;
  }

  .security-certifications {
    gap: 2rem;
  }
}

@media (max-width: 480px) {
  .title-line-1,
  .title-line-2 {
    font-size: 2.2rem;
    letter-spacing: 1px;
  }

  .system-subtitle {
    font-size: 0.8rem;
    letter-spacing: 2px;
  }

  .system-description {
    font-size: 1rem;
  }

  .features-grid {
    grid-template-columns: 1fr;
  }

  .feature-item {
    padding: 1.2rem 0.8rem;
  }

  .security-certifications {
    flex-direction: column;
    gap: 1rem;
  }

  .cert-item {
    justify-content: center;
    font-size: 0.8rem;
  }
}

/* 动画关键帧 */
@keyframes dataFlow {
  0% { background-position: 0% 50%; }
  100% { background-position: 100% 50%; }
}

@keyframes floatUp {
  0%, 100% {
    transform: translateY(0px) rotate(0deg);
    opacity: 0.3;
  }
  50% {
    transform: translateY(-20px) rotate(180deg);
    opacity: 0.7;
  }
}

@keyframes hologramGlow {
  0%, 100% {
    text-shadow:
      0 0 30px var(--cyber-primary),
      0 0 60px var(--cyber-secondary),
      0 0 90px var(--cyber-primary);
  }
  50% {
    text-shadow:
      0 0 40px var(--cyber-primary),
      0 0 80px var(--cyber-secondary),
      0 0 120px var(--cyber-primary);
  }
}

@keyframes breathe {
  0%, 100% {
    opacity: 0.8;
    transform: scale(1);
  }
  50% {
    opacity: 1;
    transform: scale(1.05);
  }
}

@keyframes rotateGlow {
  0% {
    transform: rotate(0deg);
    filter: hue-rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
    filter: hue-rotate(360deg);
  }
}

@keyframes scanLine {
  0% {
    left: -100%;
    opacity: 0;
  }
  50% {
    opacity: 1;
  }
  100% {
    left: 100%;
    opacity: 0;
  }
}
</style>
