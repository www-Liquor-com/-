<template>
  <div class="inpaint-edit-container">
    <!-- 上传区域 -->
    <div class="upload-container">
      <div class="image-preview-enhanced">
        <div v-if="inpaintImgUrl" class="preview-wrapper">
          <canvas
            ref="canvasRef"
            :width="canvasW"
            :height="canvasH"
            class="inpaint-canvas"
            @mousedown="startDraw"
            @mousemove="drawMove"
            @mouseup="endDraw"
            @mouseleave="endDraw"
          ></canvas>
          <div class="image-overlay">
            <div class="image-info">
              <i class="ri-brush-line"></i>
              <span>点击拖拽标记编辑区域</span>
            </div>
          </div>
        </div>
        <div v-else class="upload-placeholder">
          <div class="placeholder-icon">
            <i class="ri-image-edit-line"></i>
          </div>
          <div class="placeholder-text">
            <h4>拖拽图片到此处或点击上传</h4>
            <p>支持 JPG、PNG 格式，上传后可标记编辑区域</p>
          </div>
          <div class="scan-animation"></div>
        </div>
      </div>

      <div class="upload-controls">
        <el-upload
          class="upload-btn-enhanced"
          :show-file-list="false"
          :before-upload="beforeUpload"
          :on-change="onInpaintFileChange"
          :auto-upload="false"
        >
          <button class="cyber-btn-enhanced">
            <i class="ri-upload-2-line"></i>
            <span>选择图片</span>
          </button>
        </el-upload>
      </div>
    </div>

    <!-- 配置区域 -->
    <div class="config-container">
      <div class="config-section">
        <label class="config-label">
          <i class="ri-cpu-line"></i>
          编辑模型选择
        </label>
        <div class="model-selector">
          <div
            class="model-option active"
            @click="inpaintModel = 'StableDiffusion-inpaint'"
          >
            <div class="model-icon">
              <i class="ri-magic-line"></i>
            </div>
            <div class="model-text">
              <h4>StableDiffusion-inpaint</h4>
              <p>AI智能图像修复与编辑</p>
            </div>
            <div class="model-indicator"></div>
          </div>
        </div>
      </div>

      <div class="tools-section">
        <label class="config-label">
          <i class="ri-tools-line"></i>
          编辑工具
        </label>
        <div class="tool-controls">
          <button
            class="tool-btn"
            :class="{ disabled: !inpaintImgUrl }"
            :disabled="!inpaintImgUrl"
            @click="clearMask"
          >
            <i class="ri-eraser-line"></i>
            <span>清除掩码</span>
          </button>

<!--          <div class="mask-status">
            <div class="status-indicator">
              <div class="status-dot" :class="{ active: hasMask }"></div>
              {{ hasMask ? '已标记区域' : '未标记区域' }}
            </div>
          </div>-->
        </div>
      </div>

      <div class="action-section">
        <button
          class="inpaint-btn-enhanced"
          :class="{ loading: inpaintLoading, disabled: !inpaintImgUrl || !hasMask }"
          :disabled="!inpaintImgUrl || !hasMask || inpaintLoading"
          @click="onInpaint"
        >
          <div class="btn-content">
            <i class="ri-edit-2-line" v-if="!inpaintLoading"></i>
            <i class="ri-loader-4-line rotating" v-else></i>
            <span>{{ inpaintLoading ? '正在编辑...' : '开始局部编辑' }}</span>
          </div>
          <div class="btn-progress" v-if="inpaintLoading"></div>
        </button>
      </div>
    </div>

    <!-- 结果展示区域 - 独立双列框框 -->
    <div v-if="inpaintResultUrl" class="result-workspace">
      <div class="result-header">
        <h3 class="result-title">
          <i class="ri-check-double-line"></i>
          编辑结果
        </h3>
        <div class="result-status success">
          <i class="ri-shield-check-fill"></i>
          <span>编辑完成</span>
        </div>
      </div>

      <!-- 双列图像展示 -->
      <div class="result-content">
        <div class="result-left">
          <div class="image-panel">
            <div class="panel-header">
              <h4>原始图像</h4>
              &nbsp;&nbsp;&nbsp;
              <div class="panel-badge original">ORIGINAL</div>
            </div>
            <div class="image-container">
              <img :src="inpaintImgUrl" alt="原始图片" class="comparison-image" />
              <div class="image-scan-line"></div>
            </div>
          </div>
        </div>

        <div class="result-right">
          <div class="image-panel">
            <div class="panel-header">
              <h4>编辑结果</h4>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <div class="panel-badge edited">EDITED</div>
            </div>
            <div class="image-container">
              <img :src="inpaintResultUrl" alt="局部编辑结果" class="comparison-image" />
              <div class="image-scan-line"></div>
            </div>
          </div>
        </div>
      </div>

      <!-- 操作按钮 -->
      <div class="result-actions">
        <button class="download-btn-enhanced" @click="downloadInpaintResult">
          <i class="ri-download-2-line"></i>
          <span>下载编辑图像</span>
          <div class="btn-glow"></div>
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, nextTick } from 'vue'
import { ElMessage } from 'element-plus'
import { stableDiffusionInpaint } from '../api/deepfake'

const inpaintImgFile = ref(null)
const inpaintImgUrl = ref('')
const inpaintResultUrl = ref('')
const inpaintLoading = ref(false)
const canvasRef = ref(null)
const canvasW = ref(260)
const canvasH = ref(260)
let drawing = false
let hasMask = ref(false)
let maskCanvas = null
let maskCtx = null
let drawCtx = null
const inpaintModel = ref('StableDiffusion-inpaint')

function beforeUpload(rawFile) { return true }
function onInpaintFileChange(uploadFile) {
  inpaintImgFile.value = uploadFile.raw
  inpaintImgUrl.value = URL.createObjectURL(uploadFile.raw)
  inpaintResultUrl.value = ''
  nextTick(() => setupCanvas())
}
function setupCanvas() {
  const canvas = canvasRef.value
  if (!canvas) return
  const img = new window.Image()
  img.onload = () => {
    canvas.width = img.width
    canvas.height = img.height
    canvasW.value = img.width
    canvasH.value = img.height
    drawCtx = canvas.getContext('2d')
    drawCtx.clearRect(0, 0, canvas.width, canvas.height)
    drawCtx.drawImage(img, 0, 0)
    // 初始化mask
    maskCanvas = document.createElement('canvas')
    maskCanvas.width = img.width
    maskCanvas.height = img.height
    maskCtx = maskCanvas.getContext('2d')
    maskCtx.clearRect(0, 0, maskCanvas.width, maskCanvas.height)
    hasMask.value = false
  }
  img.src = inpaintImgUrl.value
}
function startDraw(e) {
  if (!canvasRef.value) return
  drawing = true
  drawOnMask(e)
}
function drawMove(e) {
  if (!drawing) return
  drawOnMask(e)
}
function endDraw() {
  drawing = false
}
function drawOnMask(e) {
  const rect = canvasRef.value.getBoundingClientRect()
  const x = e.clientX - rect.left
  const y = e.clientY - rect.top
  // 画笔粗细
  const radius = 16
  // 在mask上画白色
  maskCtx.beginPath()
  maskCtx.arc(x, y, radius, 0, 2 * Math.PI)
  maskCtx.fillStyle = 'white'
  maskCtx.fill()
  // 在canvas上画红色半透明
  drawCtx.globalAlpha = 0.4
  drawCtx.beginPath()
  drawCtx.arc(x, y, radius, 0, 2 * Math.PI)
  drawCtx.fillStyle = 'red'
  drawCtx.fill()
  drawCtx.globalAlpha = 1.0
  hasMask.value = true
}
function clearMask() {
  if (!canvasRef.value || !maskCtx || !drawCtx) return
  maskCtx.clearRect(0, 0, maskCanvas.width, maskCanvas.height)
  // 重新绘制图片
  const img = new window.Image()
  img.onload = () => {
    drawCtx.clearRect(0, 0, canvasRef.value.width, canvasRef.value.height)
    drawCtx.drawImage(img, 0, 0)
  }
  img.src = inpaintImgUrl.value
  hasMask.value = false
}
async function onInpaint() {
  if (!inpaintImgFile.value || !hasMask.value) {
    ElMessage.error('请上传图片并选择篡改区域')
    return
  }
  inpaintLoading.value = true
  try {
    // 导出mask为png
    const maskBlob = await new Promise(resolve => maskCanvas.toBlob(resolve, 'image/png'))
    const res = await stableDiffusionInpaint({ file: inpaintImgFile.value, mask: maskBlob })
    if (res.status === 200) {
      const blob = await res.blob()
      inpaintResultUrl.value = URL.createObjectURL(blob)
      ElMessage.success('局部编辑成功')
    } else {
      ElMessage.error('局部编辑失败')
    }
  } catch (e) {
    ElMessage.error('网络错误，请稍后重试')
  } finally {
    inpaintLoading.value = false
  }
}
function downloadInpaintResult() {
  if (!inpaintResultUrl.value) return
  const a = document.createElement('a')
  a.href = inpaintResultUrl.value
  a.download = 'inpaint_result.png'
  a.click()
}
</script>

<style scoped>
@import '@/assets/enhanced-cyber-theme.css';

.inpaint-edit-container {
  display: flex;
  flex-direction: column;
  gap: 2.5rem;
  padding: 0;
}

/* 上传区域 */
.upload-container {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

.image-preview-enhanced {
  width: 100%;
  height: 300px;
  border-radius: 20px;
  border: 2px dashed rgba(0, 234, 255, 0.3);
  position: relative;
  overflow: hidden;
  transition: all 0.4s ease;
}

.image-preview-enhanced:hover {
  border-color: var(--cyber-primary);
  box-shadow: 0 0 30px rgba(0, 234, 255, 0.3);
}

.preview-wrapper {
  width: 100%;
  height: 100%;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
}

.inpaint-canvas {
  max-width: 100%;
  max-height: 100%;
  object-fit: contain;
  border-radius: 15px;
  cursor: crosshair;
}

.image-overlay {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  background: linear-gradient(transparent, rgba(0, 0, 0, 0.8));
  padding: 1rem;
  display: flex;
  justify-content: center;
}

.image-info {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  color: var(--cyber-primary);
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.upload-placeholder {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  position: relative;
}

.placeholder-icon {
  font-size: 4rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  margin-bottom: 1.5rem;
  animation: floatUp 3s ease-in-out infinite;
}

.placeholder-text h4 {
  font-size: 1.2rem;
  color: var(--cyber-text-primary);
  margin-bottom: 0.5rem;
  font-weight: 600;
}

.placeholder-text p {
  color: var(--cyber-text-secondary);
  font-size: 0.9rem;
}

.scan-animation {
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(0, 234, 255, 0.1), transparent);
  animation: scanLine 3s ease-in-out infinite;
}

.upload-controls {
  display: flex;
  justify-content: center;
}

.cyber-btn-enhanced {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 15px 30px;
  background: var(--cyber-gradient-primary);
  border: none;
  border-radius: 15px;
  color: white;
  font-family: 'Orbitron', monospace;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
  cursor: pointer;
  transition: all 0.4s ease;
  box-shadow: 0 8px 25px rgba(0, 234, 255, 0.3);
}

.cyber-btn-enhanced:hover {
  transform: translateY(-3px) scale(1.05);
  box-shadow: 0 15px 35px rgba(0, 234, 255, 0.4);
}

/* 配置区域 */
.config-container {
  display: flex;
  flex-direction: column;
  gap: 2.5rem;
}

.config-section {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

.config-label {
  display: flex;
  align-items: center;
  gap: 1rem;
  font-size: 1.2rem;
  color: var(--cyber-text-primary);
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
  margin-bottom: 1rem;
}

.config-label i {
  font-size: 1.3rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
}

.model-selector {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.model-option {
  display: flex;
  align-items: center;
  gap: 1.5rem;
  padding: 1.5rem;
  background: rgba(30, 40, 80, 0.6);
  border: 2px solid rgba(0, 234, 255, 0.2);
  border-radius: 15px;
  cursor: pointer;
  transition: all 0.4s ease;
  position: relative;
  overflow: hidden;
}

.model-option:hover {
  border-color: rgba(0, 234, 255, 0.4);
  transform: translateX(5px);
  box-shadow: 0 5px 20px rgba(0, 234, 255, 0.2);
}

.model-option.active {
  border-color: var(--cyber-primary);
  background: rgba(0, 234, 255, 0.1);
  box-shadow: 0 0 20px rgba(0, 234, 255, 0.3);
}

.model-option.active::after {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(0, 234, 255, 0.1), transparent);
  animation: scanLine 2s ease-in-out;
}

.model-icon {
  font-size: 2rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  min-width: 50px;
  display: flex;
  justify-content: center;
}

.model-text {
  flex: 1;
}

.model-text h4 {
  font-size: 1.1rem;
  color: var(--cyber-text-primary);
  margin-bottom: 0.3rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.model-text p {
  color: var(--cyber-text-secondary);
  font-size: 0.9rem;
  margin: 0;
  line-height: 1.4;
}

.model-indicator {
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: var(--cyber-text-muted);
  transition: all 0.3s ease;
  min-width: 12px;
}

.model-option.active .model-indicator {
  background: var(--cyber-primary);
  box-shadow: 0 0 15px var(--cyber-primary);
}

/* 工具区域 */
.tools-section {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

.tool-controls {
  display: flex;
  align-items: center;
  gap: 1.5rem;
  flex-wrap: wrap;
}

.tool-btn {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 1rem 1.5rem;
  background: rgba(30, 40, 80, 0.6);
  border: 2px solid rgba(0, 234, 255, 0.2);
  border-radius: 15px;
  color: var(--cyber-text-primary);
  cursor: pointer;
  transition: all 0.4s ease;
  font-size: 0.9rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.tool-btn:hover:not(.disabled) {
  border-color: rgba(0, 234, 255, 0.4);
  background: rgba(0, 234, 255, 0.1);
  transform: translateX(3px);
}

.tool-btn.disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.tool-btn i {
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
}

.mask-status {
  display: flex;
  align-items: center;
  width: 200px;
  gap: 0.75rem;
  padding: 1rem 1.5rem;
  background: rgba(30, 40, 80, 0.6);
  border: 2px solid rgba(0, 234, 255, 0.2);
  border-radius: 15px;
}

.status-indicator {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.status-dot {
  width: 200px;
  height: 200px;
  border-radius: 50%;
  background: var(--cyber-text-muted);
  transition: all 0.3s ease;
}

.status-dot.active {
  background: var(--cyber-primary);
  box-shadow: 0 0 15px var(--cyber-primary);
  animation: pulse 2s infinite;
}

.action-section {
  display: flex;
  justify-content: center;
}

.inpaint-btn-enhanced {
  width: 100%;
  padding: 18px;
  background: var(--cyber-gradient-primary);
  border: none;
  border-radius: 15px;
  color: white;
  font-family: 'Orbitron', monospace;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 2px;
  cursor: pointer;
  transition: all 0.4s ease;
  position: relative;
  overflow: hidden;
  box-shadow: 0 10px 30px rgba(0, 234, 255, 0.3);
}

.inpaint-btn-enhanced:hover:not(.disabled) {
  transform: translateY(-3px);
  box-shadow: 0 15px 40px rgba(0, 234, 255, 0.4);
}

.inpaint-btn-enhanced.disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.btn-content {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1rem;
  position: relative;
  z-index: 2;
}

.btn-progress {
  position: absolute;
  bottom: 0;
  left: 0;
  height: 3px;
  background: var(--cyber-gradient-accent);
  animation: progressBar 2s ease-in-out infinite;
}

.rotating {
  animation: rotate 1s linear infinite;
}

/* 结果展示区域 */
.result-workspace {
  display: flex;
  flex-direction: column;
  gap: 2.5rem;
  margin-top: 2rem;
  padding: 2.5rem;
  background: var(--cyber-gradient-glass);
  backdrop-filter: blur(20px);
  border: 2px solid rgba(0, 234, 255, 0.3);
  border-radius: 25px;
  box-shadow:
    0 20px 60px rgba(0, 0, 0, 0.4),
    0 0 40px rgba(0, 234, 255, 0.2);
  position: relative;
  overflow: hidden;
}

.result-workspace::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 3px;
  background: var(--cyber-gradient-primary);
}

.result-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-bottom: 1rem;
  border-bottom: 1px solid rgba(0, 234, 255, 0.2);
}

.result-title {
  display: flex;
  align-items: center;
  gap: 1rem;
  font-size: 1.5rem;
  color: var(--cyber-primary);
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 2px;
  text-shadow: var(--cyber-glow-primary);
  margin: 0;
}

.result-status {
  display: flex;
  align-items: center;
  gap: 0.8rem;
  padding: 8px 16px;
  border-radius: 15px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 1px;
  font-size: 0.9rem;
}

.result-status.success {
  background: rgba(0, 255, 136, 0.1);
  color: var(--cyber-success);
  border: 1px solid var(--cyber-success);
  box-shadow: 0 0 15px rgba(0, 255, 136, 0.3);
}

/* 双列图像展示 */
.result-content {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 2rem;
  margin-bottom: 2rem;
}

.result-left,
.result-right {
  display: flex;
  flex-direction: column;
}

.image-panel {
  background: var(--cyber-bg-primary);
  border: 1px solid var(--cyber-border-secondary);
  border-radius: 16px;
  padding: 1.5rem;
  transition: all 0.3s ease;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
}

.image-panel:hover {
  border-color: var(--cyber-accent-primary);
  box-shadow: 0 8px 30px rgba(0, 255, 255, 0.15);
  transform: translateY(-2px);
}

.panel-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 1rem;
  padding-bottom: 0.75rem;
  border-bottom: 1px solid var(--cyber-border-secondary);
}

.panel-header h4 {
  color: var(--cyber-text-primary);
  margin: 0;
  font-size: 1.1rem;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.panel-badge {
  padding: 0.25rem 0.75rem;
  border-radius: 6px;
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.panel-badge.original {
  background: rgba(100, 149, 237, 0.2);
  color: #6495ED;
  border: 1px solid #6495ED;
}

.panel-badge.edited {
  background: rgba(0, 255, 136, 0.2);
  color: var(--cyber-success);
  border: 1px solid var(--cyber-success);
}

.image-container {
  position: relative;
  border-radius: 12px;
  overflow: hidden;
  background: var(--cyber-bg-secondary);
  border: 1px solid var(--cyber-border-secondary);
  transition: all 0.3s ease;
}

.image-container:hover {
  border-color: var(--cyber-accent-primary);
  box-shadow: 0 4px 20px rgba(0, 255, 255, 0.1);
}

.comparison-image {
  width: 100%;
  height: auto;
  min-height: 250px;
  object-fit: contain;
  display: block;
  border-radius: 12px;
}

.image-scan-line {
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 2px;
  background: linear-gradient(90deg, transparent, var(--cyber-accent-primary), transparent);
  animation: scan 3s linear infinite;
}

/* 操作按钮 */
.result-actions {
  display: flex;
  justify-content: center;
  padding: 1rem 0;
}

.download-btn-enhanced {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 15px 30px;
  background: var(--cyber-gradient-primary);
  border: none;
  border-radius: 15px;
  color: white;
  font-family: 'Orbitron', monospace;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 2px;
  cursor: pointer;
  transition: all 0.4s ease;
  position: relative;
  overflow: hidden;
  box-shadow: 0 8px 25px rgba(0, 234, 255, 0.3);
}

.download-btn-enhanced:hover {
  transform: translateY(-3px) scale(1.05);
  box-shadow: 0 15px 35px rgba(0, 234, 255, 0.4);
}

.btn-glow {
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
  transition: left 0.6s ease;
}

.download-btn-enhanced:hover .btn-glow {
  left: 100%;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .inpaint-edit-container {
    gap: 2rem;
  }

  .image-preview-enhanced {
    height: 250px;
  }

  .result-content {
    grid-template-columns: 1fr;
    gap: 1.5rem;
  }

  .comparison-image {
    height: 200px;
  }

  .model-option {
    flex-direction: column;
    text-align: center;
    gap: 1rem;
    padding: 1.2rem;
  }

  .result-header {
    flex-direction: column;
    gap: 1rem;
    text-align: center;
  }

  .tool-controls {
    flex-direction: column;
    align-items: stretch;
  }
}

@media (max-width: 480px) {
  .image-preview-enhanced {
    height: 200px;
  }

  .comparison-image {
    height: 150px;
  }

  .model-icon {
    font-size: 1.5rem;
  }

  .model-text h4 {
    font-size: 1rem;
  }

  .model-text p {
    font-size: 0.8rem;
  }
}

/* 动画关键帧 */
@keyframes breathe {
  0%, 100% {
    opacity: 0.8;
    transform: scale(1);
  }
  50% {
    opacity: 1;
    transform: scale(1.05);
  }
}

@keyframes floatUp {
  0%, 100% {
    transform: translateY(0px);
  }
  50% {
    transform: translateY(-10px);
  }
}

@keyframes scan {
  0% { left: -100%; }
  100% { left: 100%; }
}

@keyframes scanLine {
  0% {
    left: -100%;
    opacity: 0;
  }
  50% {
    opacity: 1;
  }
  100% {
    left: 100%;
    opacity: 0;
  }
}

@keyframes pulse {
  0%, 100% {
    opacity: 1;
    transform: scale(1);
  }
  50% {
    opacity: 0.8;
    transform: scale(1.05);
  }
}

@keyframes progressBar {
  0% { width: 0%; }
  50% { width: 70%; }
  100% { width: 100%; }
}

@keyframes rotate {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}
</style>
