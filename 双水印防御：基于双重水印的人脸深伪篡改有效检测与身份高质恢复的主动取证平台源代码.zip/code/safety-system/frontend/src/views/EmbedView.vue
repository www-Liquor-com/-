<template>
  <div class="embed-bg">
    <!-- 页面标题区域 -->
    <div class="page-header">
      <div class="header-decoration">
        <div class="deco-line"></div>
        <div class="header-icon">
          <i class="ri-shield-star-line"></i>
        </div>
        <div class="deco-line"></div>
      </div>
      <h1 class="page-title">
        <span class="title-main">WATERMARK EMBEDDING</span>
        <span class="title-sub">水印嵌入系统</span>
      </h1>
      <div class="security-badge">SECURE EMBEDDING</div>
    </div>

    <!-- 主要操作区域 -->
    <div class="main-workspace">
      <!-- 上传区域 -->
      <div class="upload-workspace cyber-glass-card">
        <div class="workspace-header">
          <h3 class="workspace-title">
            <i class="ri-upload-cloud-2-line"></i>
            图像上传区域
          </h3>
          <div class="status-indicator">
            <div class="status-dot" :class="{ active: file }"></div>
            <span>{{ file ? '已上传' : '待上传' }}</span>
          </div>
        </div>

        <div class="upload-container">
          <div class="image-preview-enhanced">
            <div v-if="originUrl" class="preview-wrapper">
              <img :src="originUrl" alt="原始图片" class="preview-image" />
              <div class="image-overlay">
                <div class="image-info">
                  <i class="ri-image-line"></i>
                  <span>原始图像</span>
                </div>
              </div>
            </div>
            <div v-else class="upload-placeholder">
              <div class="placeholder-icon">
                <i class="ri-image-add-line"></i>
              </div>
              <div class="placeholder-text">
                <h4>拖拽图片到此处或点击上传</h4>
                <p>支持 JPG、PNG 格式，建议尺寸 512x512</p>
              </div>
              <div class="scan-animation"></div>
            </div>
          </div>


          <div class="upload-controls">
            <el-upload
              class="upload-btn-enhanced"
              :show-file-list="false"
              :before-upload="beforeUpload"
              :on-change="onFileChange"
              :auto-upload="false"
            >
              <button class="cyber-btn-enhanced">
                <i class="ri-upload-2-line"></i>
                <span>选择图片</span>
              </button>
            </el-upload>
          </div>
        </div>
      </div>

      <!-- 配置区域 -->
      <div class="config-workspace cyber-glass-card">
        <div class="workspace-header">
          <h3 class="workspace-title">
            <i class="ri-settings-3-line"></i>
            水印配置
          </h3>
        </div>

        <div class="config-content">
          <div class="config-section">
            <label class="config-label">水印类型</label>
            <div class="mode-selector">
              <div
                class="mode-option"
                :class="{ active: mode === 1 }"
                @click="mode = 1"
              >
                <div class="mode-icon">
                  <i class="ri-focus-3-line"></i>
                </div>
                <div class="mode-text">
                  <h4>篡改定位水印</h4>
                  <p>检测图像篡改区域</p>
                </div>
                <div class="mode-indicator"></div>
              </div>

              <div
                class="mode-option"
                :class="{ active: mode === 2 }"
                @click="mode = 2"
              >
                <div class="mode-icon">
                  <i class="ri-user-search-line"></i>
                </div>
                <div class="mode-text">
                  <h4>身份恢复水印</h4>
                  <p>恢复真实身份信息</p>
                </div>
                <div class="mode-indicator"></div>
              </div>

              <div
                class="mode-option"
                :class="{ active: mode === 3 }"
                @click="mode = 3"
              >
                <div class="mode-icon">
                  <i class="ri-shield-check-line"></i>
                </div>
                <div class="mode-text">
                  <h4>双重水印</h4>
                  <p>完整保护方案</p>
                </div>
                <div class="mode-indicator"></div>
              </div>
            </div>
          </div>

          <div class="action-section">
            <button
              class="embed-btn-enhanced"
              :class="{ loading: loading, disabled: !file }"
              :disabled="!file || loading"
              @click="onEmbed"
            >
              <div class="btn-content">
                <i class="ri-shield-star-line" v-if="!loading"></i>
                <i class="ri-loader-4-line rotating" v-else></i>
                <span>{{ loading ? '正在嵌入...' : '开始嵌入水印' }}</span>
              </div>
              <div class="btn-progress" v-if="loading"></div>
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- 结果展示区域 -->
    <div v-if="resultUrl" class="result-workspace">
      <div class="result-header">
        <h2 class="result-title">
          <i class="ri-check-double-line"></i>
          嵌入结果
        </h2>
        <div class="result-status success">
          <i class="ri-shield-check-fill"></i>
          <span>水印嵌入成功</span>
        </div>
      </div>

      <!-- 图像对比 -->
      <div class="image-comparison cyber-glass-card">
        <div class="comparison-container">
          <div class="image-panel">
            <div class="panel-header">
              <h4>原始图像</h4>
              <div class="panel-badge original">ORIGINAL</div>
            </div>
            <div class="image-container">
              <img :src="originUrl" alt="原始图片" class="comparison-image" />
              <div class="image-scan-line"></div>
            </div>
          </div>

          <div class="comparison-arrow">
            <div class="arrow-container">
              <i class="ri-arrow-right-line"></i>
              <div class="arrow-glow"></div>
            </div>
          </div>

          <div class="image-panel">
            <div class="panel-header">
              <h4>水印图像</h4>
              <div class="panel-badge watermarked">WATERMARKED</div>
            </div>
            <div class="image-container">
              <img :src="resultUrl" alt="水印图片" class="comparison-image" />
              <div class="image-scan-line"></div>
            </div>
          </div>
        </div>
      </div>

      <!-- 指标展示 -->
      <div v-if="metrics" class="metrics-panel cyber-glass-card">
        <div class="metrics-header">
          <h3>
            <i class="ri-bar-chart-line"></i>
            图像质量指标
          </h3>
        </div>
        <div class="metrics-grid">
          <div class="metric-item">
            <div class="metric-icon">
              <i class="ri-signal-tower-line"></i>
            </div>
            <div class="metric-content">
              <div class="metric-value">{{ metrics.PSNR ?? '--' }}</div>
              <div class="metric-label">PSNR (dB)</div>
              <div class="metric-desc">峰值信噪比</div>
            </div>
          </div>

          <div class="metric-item">
            <div class="metric-icon">
              <i class="ri-eye-line"></i>
            </div>
            <div class="metric-content">
              <div class="metric-value">{{ metrics.SSIM ?? '--' }}</div>
              <div class="metric-label">SSIM</div>
              <div class="metric-desc">结构相似性</div>
            </div>
          </div>

          <div class="metric-item">
            <div class="metric-icon">
              <i class="ri-brain-line"></i>
            </div>
            <div class="metric-content">
              <div class="metric-value">{{ metrics.LPIPS ?? '--' }}</div>
              <div class="metric-label">LPIPS</div>
              <div class="metric-desc">感知距离</div>
            </div>
          </div>
        </div>

        <div v-if="metrics.error" class="metrics-error">
          <i class="ri-error-warning-line"></i>
          <span>错误: {{ metrics.error }}</span>
        </div>
      </div>

      <!-- 操作按钮 -->
      <div class="result-actions">
        <button class="download-btn-enhanced" @click="downloadResult">
          <i class="ri-download-2-line"></i>
          <span>下载水印图像</span>
          <div class="btn-glow"></div>
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { ElMessage } from 'element-plus'
import { embedWatermark } from '../api/watermark'

const file = ref(null)
const originUrl = ref('')
const resultUrl = ref('')
const mode = ref(1)
const loading = ref(false)
const metrics = ref(null)

function beforeUpload(rawFile) {
  // 不做任何处理，直接返回 true
  return true
}

function onFileChange(uploadFile) {
  file.value = uploadFile.raw
  originUrl.value = URL.createObjectURL(uploadFile.raw)
  resultUrl.value = ''
  metrics.value = null
}

async function onEmbed() {
  if (!file.value) {
    ElMessage.error('请先上传图片')
    return
  }
  loading.value = true
  try {
    const res = await embedWatermark({ file: file.value, mode: mode.value })
    if (res.status === 200 && res.blob) {
      console.log(res)
      resultUrl.value = URL.createObjectURL(res.blob)
      metrics.value = res.metrics
      ElMessage.success('水印嵌入成功')
    } else {
      ElMessage.error('水印嵌入失败')
    }
  } catch (e) {
    ElMessage.error('网络错误，请稍后重试')
  } finally {
    loading.value = false
  }
}

function downloadResult() {
  if (!resultUrl.value) return
  const a = document.createElement('a')
  a.href = resultUrl.value
  a.download = 'watermarked.png'
  a.click()
}
</script>

<style scoped>
@import '@/assets/enhanced-cyber-theme.css';

.embed-bg {
  min-height: 80vh;
  padding: 0;
  background: transparent;
  display: flex;
  flex-direction: column;
  gap: 3rem;
}

/* 页面标题区域 */
.page-header {
  text-align: center;
  padding: 2rem 0;
  position: relative;
}

.header-decoration {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 2rem;
  margin-bottom: 2rem;
}

.deco-line {
  flex: 1;
  max-width: 150px;
  height: 2px;
  background: var(--cyber-gradient-primary);
  border-radius: 1px;
}

.header-icon {
  font-size: 3rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  animation: breathe 3s ease-in-out infinite;
}

.page-title {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 1.5rem;
}

.title-main {
  font-size: 2.8rem;
  font-weight: 900;
  text-transform: uppercase;
  letter-spacing: 3px;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  font-family: 'Orbitron', monospace;
}

.title-sub {
  font-size: 1.2rem;
  color: var(--cyber-text-secondary);
  letter-spacing: 2px;
  font-weight: 600;
}

.security-badge {
  background: var(--cyber-gradient-accent);
  color: white;
  padding: 8px 20px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 2px;
  box-shadow: 0 0 20px rgba(255, 0, 110, 0.4);
  animation: breathe 4s ease-in-out infinite;
}

/* 主工作区域 */
.main-workspace {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 3rem;
  margin-bottom: 3rem;
}

.cyber-glass-card {
  background: var(--cyber-gradient-glass);
  backdrop-filter: blur(20px);
  border: 2px solid rgba(0, 234, 255, 0.3);
  border-radius: 25px;
  padding: 2.5rem;
  box-shadow:
    0 20px 60px rgba(0, 0, 0, 0.4),
    0 0 40px rgba(0, 234, 255, 0.2);
  position: relative;
  overflow: hidden;
}

.cyber-glass-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 3px;
  background: var(--cyber-gradient-primary);
}

.workspace-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid rgba(0, 234, 255, 0.2);
}

.workspace-title {
  display: flex;
  align-items: center;
  gap: 1rem;
  font-size: 1.3rem;
  color: var(--cyber-text-primary);
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.workspace-title i {
  font-size: 1.5rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
}

.status-indicator {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.9rem;
  color: var(--cyber-text-secondary);
  text-transform: uppercase;
  letter-spacing: 1px;
  font-weight: 600;
}

.status-dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: var(--cyber-text-muted);
  transition: all 0.3s ease;
}

.status-dot.active {
  background: var(--cyber-success);
  box-shadow: 0 0 15px var(--cyber-success);
  animation: breathe 2s ease-in-out infinite;
}

/* 上传区域 */
.upload-container {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

.image-preview-enhanced {
  width: 100%;
  height: 300px;
  border-radius: 20px;
  border: 2px dashed rgba(0, 234, 255, 0.3);
  position: relative;
  overflow: hidden;
  transition: all 0.4s ease;
}

.image-preview-enhanced:hover {
  border-color: var(--cyber-primary);
  box-shadow: 0 0 30px rgba(0, 234, 255, 0.3);
}

.preview-wrapper {
  width: 100%;
  height: 100%;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
}

.preview-image {
  max-width: 100%;
  max-height: 100%;
  object-fit: contain;
  border-radius: 15px;
}

.image-overlay {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  background: linear-gradient(transparent, rgba(0, 0, 0, 0.8));
  padding: 1rem;
  display: flex;
  justify-content: center;
}

.image-info {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  color: var(--cyber-primary);
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.upload-placeholder {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  position: relative;
}

.placeholder-icon {
  font-size: 4rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  margin-bottom: 1.5rem;
  animation: floatUp 3s ease-in-out infinite;
}

.placeholder-text h4 {
  font-size: 1.2rem;
  color: var(--cyber-text-primary);
  margin-bottom: 0.5rem;
  font-weight: 600;
}

.placeholder-text p {
  color: var(--cyber-text-secondary);
  font-size: 0.9rem;
}

.scan-animation {
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(0, 234, 255, 0.1), transparent);
  animation: scanLine 3s ease-in-out infinite;
}

.upload-controls {
  display: flex;
  justify-content: center;
}

.cyber-btn-enhanced {
  width: 300px;
  text-align: center;
  gap: 1rem;
  padding: 15px 30px;
  background: var(--cyber-gradient-primary);
  border: none;
  border-radius: 15px;
  color: white;
  font-family: 'Orbitron', monospace;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
  cursor: pointer;
  transition: all 0.4s ease;
  box-shadow: 0 8px 25px rgba(0, 234, 255, 0.3);
}

.cyber-btn-enhanced:hover {
  transform: translateY(-3px) scale(1.05);
  box-shadow: 0 15px 35px rgba(0, 234, 255, 0.4);
}

/* 配置区域 */
.config-content {
  display: flex;
  flex-direction: column;
  gap: 2.5rem;
}

.config-label {
  display: block;
  font-size: 1.1rem;
  color: var(--cyber-text-primary);
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
  margin-bottom: 1.5rem;
}

.mode-selector {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.mode-option {
  display: flex;
  align-items: center;
  gap: 1.5rem;
  padding: 1.5rem;
  background: rgba(30, 40, 80, 0.6);
  border: 2px solid rgba(0, 234, 255, 0.2);
  border-radius: 15px;
  cursor: pointer;
  transition: all 0.4s ease;
  position: relative;
  overflow: hidden;
}

.mode-option:hover {
  border-color: rgba(0, 234, 255, 0.4);
  transform: translateX(5px);
}

.mode-option.active {
  border-color: var(--cyber-primary);
  background: rgba(0, 234, 255, 0.1);
  box-shadow: 0 0 25px rgba(0, 234, 255, 0.3);
}

.mode-icon {
  font-size: 2rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  min-width: 50px;
  display: flex;
  justify-content: center;
}

.mode-text h4 {
  font-size: 1.1rem;
  color: var(--cyber-text-primary);
  margin-bottom: 0.3rem;
  font-weight: 700;
}

.mode-text p {
  color: var(--cyber-text-secondary);
  font-size: 0.9rem;
  margin: 0;
}

.mode-indicator {
  position: absolute;
  right: 1.5rem;
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: var(--cyber-text-muted);
  transition: all 0.3s ease;
}

.mode-option.active .mode-indicator {
  background: var(--cyber-primary);
  box-shadow: 0 0 15px var(--cyber-primary);
}

.embed-btn-enhanced {
  width: 100%;
  padding: 18px;
  background: var(--cyber-gradient-primary);
  border: none;
  border-radius: 15px;
  color: white;
  font-family: 'Orbitron', monospace;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 2px;
  cursor: pointer;
  transition: all 0.4s ease;
  position: relative;
  overflow: hidden;
  box-shadow: 0 10px 30px rgba(0, 234, 255, 0.3);
}

.embed-btn-enhanced:hover:not(.disabled) {
  transform: translateY(-3px);
  box-shadow: 0 15px 40px rgba(0, 234, 255, 0.4);
}

.embed-btn-enhanced.disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.btn-content {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1rem;
  position: relative;
  z-index: 2;
}

.btn-progress {
  position: absolute;
  bottom: 0;
  left: 0;
  height: 3px;
  background: var(--cyber-gradient-accent);
  animation: progressBar 2s ease-in-out infinite;
}

@keyframes progressBar {
  0% { width: 0%; }
  50% { width: 70%; }
  100% { width: 100%; }
}

.rotating {
  animation: rotate 1s linear infinite;
}

@keyframes rotate {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

/* 结果展示区域 */
.result-workspace {
  display: flex;
  flex-direction: column;
  gap: 2.5rem;
}

.result-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.5rem 0;
}

.result-title {
  display: flex;
  align-items: center;
  gap: 1rem;
  font-size: 2rem;
  color: var(--cyber-primary);
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 2px;
  text-shadow: var(--cyber-glow-primary);
}

.result-status {
  display: flex;
  align-items: center;
  gap: 0.8rem;
  padding: 10px 20px;
  border-radius: 20px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.result-status.success {
  background: rgba(0, 255, 136, 0.1);
  color: var(--cyber-success);
  border: 1px solid var(--cyber-success);
  box-shadow: 0 0 15px rgba(0, 255, 136, 0.3);
}

/* 图像对比 */
.comparison-container {
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  gap: 3rem;
  align-items: center;
}

.image-panel {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.panel-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.panel-header h4 {
  font-size: 1.2rem;
  color: var(--cyber-text-primary);
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
  margin: 0;
}

.panel-badge {
  padding: 4px 12px;
  border-radius: 15px;
  font-size: 10px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.panel-badge.original {
  background: rgba(0, 234, 255, 0.2);
  color: var(--cyber-primary);
  border: 1px solid var(--cyber-primary);
}

.panel-badge.watermarked {
  background: rgba(0, 255, 136, 0.2);
  color: var(--cyber-success);
  border: 1px solid var(--cyber-success);
}

.image-container {
  position: relative;
  border-radius: 20px;
  overflow: hidden;
  border: 2px solid rgba(0, 234, 255, 0.3);
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
}

.comparison-image {
  width: 100%;
  height: 300px;
  object-fit: contain;
  background: var(--cyber-bg-primary);
}

.image-scan-line {
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(0, 234, 255, 0.2), transparent);
  animation: scanLine 4s ease-in-out infinite;
}

.comparison-arrow {
  display: flex;
  justify-content: center;
  align-items: center;
}

.arrow-container {
  position: relative;
  font-size: 3rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  animation: floatUp 2s ease-in-out infinite;
}

.arrow-glow {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 60px;
  height: 60px;
  background: radial-gradient(circle, rgba(0, 234, 255, 0.2) 0%, transparent 70%);
  border-radius: 50%;
  animation: breathe 3s ease-in-out infinite;
}

/* 指标面板 */
.metrics-header {
  margin-bottom: 2rem;
}

.metrics-header h3 {
  display: flex;
  align-items: center;
  gap: 1rem;
  font-size: 1.5rem;
  color: var(--cyber-text-primary);
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
  margin: 0;
}

.metrics-header i {
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
}

.metrics-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 2rem;
}

.metric-item {
  display: flex;
  align-items: center;
  gap: 1.5rem;
  padding: 2rem;
  background: rgba(30, 40, 80, 0.6);
  border: 1px solid rgba(0, 234, 255, 0.3);
  border-radius: 20px;
  transition: all 0.4s ease;
}

.metric-item:hover {
  border-color: var(--cyber-primary);
  transform: translateY(-5px);
  box-shadow: 0 10px 30px rgba(0, 234, 255, 0.3);
}

.metric-icon {
  font-size: 2.5rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  min-width: 60px;
  display: flex;
  justify-content: center;
}

.metric-content {
  flex: 1;
}

.metric-value {
  font-size: 2rem;
  font-weight: 900;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  font-family: 'Orbitron', monospace;
  margin-bottom: 0.3rem;
}

.metric-label {
  font-size: 1rem;
  color: var(--cyber-text-primary);
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
  margin-bottom: 0.2rem;
}

.metric-desc {
  font-size: 0.8rem;
  color: var(--cyber-text-secondary);
}

.metrics-error {
  display: flex;
  align-items: center;
  gap: 0.8rem;
  padding: 1rem;
  background: rgba(255, 77, 79, 0.1);
  border: 1px solid var(--cyber-danger);
  border-radius: 10px;
  color: var(--cyber-danger);
  font-weight: 600;
  margin-top: 1rem;
}

/* 操作按钮 */
.result-actions {
  display: flex;
  justify-content: center;
  padding: 2rem 0;
}

.download-btn-enhanced {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 18px 35px;
  background: var(--cyber-gradient-primary);
  border: none;
  border-radius: 20px;
  color: white;
  font-family: 'Orbitron', monospace;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 2px;
  cursor: pointer;
  transition: all 0.4s ease;
  position: relative;
  overflow: hidden;
  box-shadow: 0 10px 30px rgba(0, 234, 255, 0.3);
}

.download-btn-enhanced:hover {
  transform: translateY(-5px) scale(1.05);
  box-shadow: 0 20px 50px rgba(0, 234, 255, 0.4);
}

.btn-glow {
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
  transition: left 0.6s ease;
}

.download-btn-enhanced:hover .btn-glow {
  left: 100%;
}

/* 响应式设计 */
@media (max-width: 1200px) {
  .main-workspace {
    grid-template-columns: 1fr;
    gap: 2rem;
  }

  .comparison-container {
    grid-template-columns: 1fr;
    gap: 2rem;
  }

  .comparison-arrow {
    transform: rotate(90deg);
  }
}

@media (max-width: 768px) {
  .embed-bg {
    gap: 2rem;
  }

  .page-header {
    padding: 1.5rem 0;
  }

  .title-main {
    font-size: 2.2rem;
    letter-spacing: 2px;
  }

  .title-sub {
    font-size: 1rem;
  }

  .cyber-glass-card {
    padding: 2rem;
  }

  .workspace-header {
    flex-direction: column;
    gap: 1rem;
    text-align: center;
  }

  .image-preview-enhanced {
    height: 250px;
  }

  .mode-option {
    padding: 1.2rem;
  }

  .metrics-grid {
    grid-template-columns: 1fr;
  }

  .result-header {
    flex-direction: column;
    gap: 1rem;
    text-align: center;
  }
}

@media (max-width: 480px) {
  .title-main {
    font-size: 1.8rem;
  }

  .cyber-glass-card {
    padding: 1.5rem;
  }

  .image-preview-enhanced {
    height: 200px;
  }

  .mode-option {
    flex-direction: column;
    text-align: center;
    gap: 1rem;
  }

  .metric-item {
    flex-direction: column;
    text-align: center;
    gap: 1rem;
  }
}

/* 动画关键帧 */
@keyframes breathe {
  0%, 100% {
    opacity: 0.8;
    transform: scale(1);
  }
  50% {
    opacity: 1;
    transform: scale(1.05);
  }
}

@keyframes floatUp {
  0%, 100% {
    transform: translateY(0px);
  }
  50% {
    transform: translateY(-10px);
  }
}

@keyframes scanLine {
  0% {
    left: -100%;
    opacity: 0;
  }
  50% {
    opacity: 1;
  }
  100% {
    left: 100%;
    opacity: 0;
  }
}
</style>
