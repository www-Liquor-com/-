<template>
  <div class="tl-bg">
    <!-- 页面标题区域 -->
    <div class="page-header">
      <div class="header-decoration">
        <div class="deco-line"></div>
        <div class="header-icon">
          <i class="ri-focus-3-line"></i>
        </div>
        <div class="deco-line"></div>
      </div>
      <h1 class="page-title">
        <span class="title-main">TAMPER DETECTION</span>
        <span class="title-sub">篡改定位系统</span>
      </h1>
      <div class="security-badge">DETECTION MODE</div>
    </div>

    <!-- 主要操作区域 -->
    <div class="main-workspace">
      <!-- 上传区域 -->
      <div class="upload-workspace cyber-glass-card">
        <div class="workspace-header">
          <h3 class="workspace-title">
            <i class="ri-upload-cloud-2-line"></i>
            图像上传区域
          </h3>
          <div class="status-indicator">
            <div class="status-dot" :class="{ active: file }"></div>
            <span>{{ file ? '已上传' : '待上传' }}</span>
          </div>
        </div>

        <div class="upload-container">
          <div class="image-preview-enhanced">
            <div v-if="originUrl" class="preview-wrapper">
              <img :src="originUrl" alt="原始图片" class="preview-image" />
              <div class="image-overlay">
                <div class="image-info">
                  <i class="ri-image-line"></i>
                  <span>待检测图像</span>
                </div>
              </div>
            </div>
            <div v-else class="upload-placeholder">
              <div class="placeholder-icon">
                <i class="ri-image-add-line"></i>
              </div>
              <div class="placeholder-text">
                <h4>拖拽图片到此处或点击上传</h4>
                <p>支持 JPG、PNG 格式，建议尺寸 512x512</p>
              </div>
              <div class="scan-animation"></div>
            </div>
          </div>

          <div class="upload-controls">
            <el-upload
              class="upload-btn-enhanced"
              :show-file-list="false"
              :before-upload="beforeUpload"
              :on-change="onFileChange"
              :auto-upload="false"
            >
              <button class="cyber-btn-enhanced">
                <i class="ri-upload-2-line"></i>
                <span>选择图片</span>
              </button>
            </el-upload>
          </div>
        </div>
      </div>

      <!-- 检测区域 -->
      <div class="detection-workspace cyber-glass-card">
        <div class="workspace-header">
          <h3 class="workspace-title">
            <i class="ri-search-eye-line"></i>
            篡改检测
          </h3>
        </div>

        <div class="detection-content">
          <div class="detection-info">
            <div class="info-item">
              <div class="info-icon">
                <i class="ri-focus-3-line"></i>
              </div>
              <div class="info-text">
                <h4>精确定位</h4>
                <p>像素级篡改区域检测</p>
              </div>
            </div>

            <div class="info-item">
              <div class="info-icon">
                <i class="ri-eye-line"></i>
              </div>
              <div class="info-text">
                <h4>可视化分析</h4>
                <p>生成篡改掩码图像</p>
              </div>
            </div>
          </div>

          <div class="action-section">
            <button
              class="detect-btn-enhanced"
              :class="{ loading: loading, disabled: !file }"
              :disabled="!file || loading"
              @click="onExtract"
            >
              <div class="btn-content">
                <i class="ri-search-eye-line" v-if="!loading"></i>
                <i class="ri-loader-4-line rotating" v-else></i>
                <span>{{ loading ? '正在检测...' : '开始篡改检测' }}</span>
              </div>
              <div class="btn-progress" v-if="loading"></div>
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- 结果展示区域 -->
    <div v-if="resultUrl" class="result-workspace">
      <div class="result-header">
        <h2 class="result-title">
          <i class="ri-check-double-line"></i>
          检测结果
        </h2>
        <div class="result-status success">
          <i class="ri-shield-check-fill"></i>
          <span>篡改检测完成</span>
        </div>
      </div>

      <!-- 图像对比 -->
      <div class="image-comparison cyber-glass-card">
        <div class="comparison-container">
          <div class="image-panel">
            <div class="panel-header">
              <h4>原始图像</h4>
              <div class="panel-badge original">ORIGINAL</div>
            </div>
            <div class="image-container">
              <img :src="originUrl" alt="原始图片" class="comparison-image" />
              <div class="image-scan-line"></div>
            </div>
          </div>

          <div class="comparison-arrow">
            <div class="arrow-container">
              <i class="ri-arrow-right-line"></i>
              <div class="arrow-glow"></div>
            </div>
          </div>

          <div class="image-panel">
            <div class="panel-header">
              <h4>篡改掩码</h4>
              <div class="panel-badge detected">DETECTED</div>
            </div>
            <div class="image-container">
              <img :src="resultUrl" alt="掩码图片" class="comparison-image" />
              <div class="image-scan-line"></div>
            </div>
          </div>
        </div>
      </div>

      <!-- 检测说明 -->
      <div class="detection-info-panel cyber-glass-card">
        <div class="info-header">
          <h3>
            <i class="ri-information-line"></i>
            检测说明
          </h3>
        </div>
        <div class="info-content">
          <div class="info-tip">
            <div class="tip-icon">
              <i class="ri-lightbulb-line"></i>
            </div>
            <div class="tip-text">
              <strong>掩码解读：</strong>白色区域表示检测到的篡改区域，黑色区域表示未篡改的原始内容。
            </div>
          </div>
        </div>
      </div>

      <!-- 操作按钮 -->
      <div class="result-actions">
        <button class="download-btn-enhanced" @click="downloadResult">
          <i class="ri-download-2-line"></i>
          <span>下载掩码图像</span>
          <div class="btn-glow"></div>
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { ElMessage } from 'element-plus'
import { extractTamperLocation } from '../api/watermark'

const file = ref(null)
const originUrl = ref('')
const resultUrl = ref('')
const loading = ref(false)

function beforeUpload(rawFile) {
  return true
}

function onFileChange(uploadFile) {
  file.value = uploadFile.raw
  originUrl.value = URL.createObjectURL(uploadFile.raw)
  resultUrl.value = ''
}

async function onExtract() {
  if (!file.value) {
    ElMessage.error('请先上传图片')
    return
  }
  loading.value = true
  try {
    const res = await extractTamperLocation({ file: file.value })
    if (res.status === 200) {
      const blob = await res.blob()
      resultUrl.value = URL.createObjectURL(blob)
      ElMessage.success('掩码生成成功')
    } else {
      ElMessage.error('掩码生成失败')
    }
  } catch (e) {
    ElMessage.error('网络错误，请稍后重试')
  } finally {
    loading.value = false
  }
}

function downloadResult() {
  if (!resultUrl.value) return
  const a = document.createElement('a')
  a.href = resultUrl.value
  a.download = 'mask.png'
  a.click()
}
</script>

<style scoped>
@import '@/assets/enhanced-cyber-theme.css';

.tl-bg {
  min-height: 80vh;
  padding: 0;
  background: transparent;
  display: flex;
  flex-direction: column;
  gap: 3rem;
}

/* 页面标题区域 */
.page-header {
  text-align: center;
  padding: 2rem 0;
  position: relative;
}

.header-decoration {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 2rem;
  margin-bottom: 2rem;
}

.deco-line {
  flex: 1;
  max-width: 150px;
  height: 2px;
  background: var(--cyber-gradient-primary);
  border-radius: 1px;
}

.header-icon {
  font-size: 3rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  animation: breathe 3s ease-in-out infinite;
}

.page-title {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 1.5rem;
}

.title-main {
  font-size: 2.8rem;
  font-weight: 900;
  text-transform: uppercase;
  letter-spacing: 3px;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  font-family: 'Orbitron', monospace;
}

.title-sub {
  font-size: 1.2rem;
  color: var(--cyber-text-secondary);
  letter-spacing: 2px;
  font-weight: 600;
}

.security-badge {
  background: var(--cyber-gradient-accent);
  color: white;
  padding: 8px 20px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 2px;
  box-shadow: 0 0 20px rgba(255, 0, 110, 0.4);
  animation: breathe 4s ease-in-out infinite;
}

/* 主工作区域 */
.main-workspace {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 3rem;
  margin-bottom: 3rem;
}

.cyber-glass-card {
  background: var(--cyber-gradient-glass);
  backdrop-filter: blur(20px);
  border: 2px solid rgba(0, 234, 255, 0.3);
  border-radius: 25px;
  padding: 2.5rem;
  box-shadow:
    0 20px 60px rgba(0, 0, 0, 0.4),
    0 0 40px rgba(0, 234, 255, 0.2);
  position: relative;
  overflow: hidden;
}

.cyber-glass-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 3px;
  background: var(--cyber-gradient-primary);
}

.workspace-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid rgba(0, 234, 255, 0.2);
}

.workspace-title {
  display: flex;
  align-items: center;
  gap: 1rem;
  font-size: 1.3rem;
  color: var(--cyber-text-primary);
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.workspace-title i {
  font-size: 1.5rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
}

.status-indicator {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.9rem;
  color: var(--cyber-text-secondary);
  text-transform: uppercase;
  letter-spacing: 1px;
  font-weight: 600;
}

.status-dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: var(--cyber-text-muted);
  transition: all 0.3s ease;
}

.status-dot.active {
  background: var(--cyber-success);
  box-shadow: 0 0 15px var(--cyber-success);
  animation: breathe 2s ease-in-out infinite;
}

/* 上传区域 */
.upload-container {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

.image-preview-enhanced {
  width: 100%;
  height: 300px;
  border-radius: 20px;
  border: 2px dashed rgba(0, 234, 255, 0.3);
  position: relative;
  overflow: hidden;
  transition: all 0.4s ease;
}

.image-preview-enhanced:hover {
  border-color: var(--cyber-primary);
  box-shadow: 0 0 30px rgba(0, 234, 255, 0.3);
}

.preview-wrapper {
  width: 100%;
  height: 100%;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
}

.preview-image {
  max-width: 100%;
  max-height: 100%;
  object-fit: contain;
  border-radius: 15px;
}

.image-overlay {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  background: linear-gradient(transparent, rgba(0, 0, 0, 0.8));
  padding: 1rem;
  display: flex;
  justify-content: center;
}

.image-info {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  color: var(--cyber-primary);
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.upload-placeholder {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  position: relative;
}

.placeholder-icon {
  font-size: 4rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  margin-bottom: 1.5rem;
  animation: floatUp 3s ease-in-out infinite;
}

.placeholder-text h4 {
  font-size: 1.2rem;
  color: var(--cyber-text-primary);
  margin-bottom: 0.5rem;
  font-weight: 600;
}

.placeholder-text p {
  color: var(--cyber-text-secondary);
  font-size: 0.9rem;
}

.scan-animation {
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(0, 234, 255, 0.1), transparent);
  animation: scanLine 3s ease-in-out infinite;
}

.upload-controls {
  display: flex;
  justify-content: center;
}

.cyber-btn-enhanced {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 15px 30px;
  background: var(--cyber-gradient-primary);
  border: none;
  border-radius: 15px;
  color: white;
  font-family: 'Orbitron', monospace;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
  cursor: pointer;
  transition: all 0.4s ease;
  box-shadow: 0 8px 25px rgba(0, 234, 255, 0.3);
}

.cyber-btn-enhanced:hover {
  transform: translateY(-3px) scale(1.05);
  box-shadow: 0 15px 35px rgba(0, 234, 255, 0.4);
}

/* 检测区域 */
.detection-content {
  display: flex;
  flex-direction: column;
  gap: 2.5rem;
}

.detection-info {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

.info-item {
  display: flex;
  align-items: center;
  gap: 1.5rem;
  padding: 1.5rem;
  background: rgba(30, 40, 80, 0.6);
  border: 1px solid rgba(0, 234, 255, 0.3);
  border-radius: 15px;
  transition: all 0.4s ease;
}

.info-item:hover {
  border-color: var(--cyber-primary);
  transform: translateX(5px);
  box-shadow: 0 5px 15px rgba(0, 234, 255, 0.2);
}

.info-icon {
  font-size: 2rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  min-width: 50px;
  display: flex;
  justify-content: center;
}

.info-text h4 {
  font-size: 1.1rem;
  color: var(--cyber-text-primary);
  margin-bottom: 0.3rem;
  font-weight: 700;
}

.info-text p {
  color: var(--cyber-text-secondary);
  font-size: 0.9rem;
  margin: 0;
}

.detect-btn-enhanced {
  width: 100%;
  padding: 18px;
  background: var(--cyber-gradient-primary);
  border: none;
  border-radius: 15px;
  color: white;
  font-family: 'Orbitron', monospace;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 2px;
  cursor: pointer;
  transition: all 0.4s ease;
  position: relative;
  overflow: hidden;
  box-shadow: 0 10px 30px rgba(0, 234, 255, 0.3);
}

.detect-btn-enhanced:hover:not(.disabled) {
  transform: translateY(-3px);
  box-shadow: 0 15px 40px rgba(0, 234, 255, 0.4);
}

.detect-btn-enhanced.disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.btn-content {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1rem;
  position: relative;
  z-index: 2;
}

.btn-progress {
  position: absolute;
  bottom: 0;
  left: 0;
  height: 3px;
  background: var(--cyber-gradient-accent);
  animation: progressBar 2s ease-in-out infinite;
}

.rotating {
  animation: rotate 1s linear infinite;
}

/* 结果展示区域 */
.result-workspace {
  display: flex;
  flex-direction: column;
  gap: 2.5rem;
}

.result-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.5rem 0;
}

.result-title {
  display: flex;
  align-items: center;
  gap: 1rem;
  font-size: 2rem;
  color: var(--cyber-primary);
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 2px;
  text-shadow: var(--cyber-glow-primary);
}

.result-status {
  display: flex;
  align-items: center;
  gap: 0.8rem;
  padding: 10px 20px;
  border-radius: 20px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.result-status.success {
  background: rgba(0, 255, 136, 0.1);
  color: var(--cyber-success);
  border: 1px solid var(--cyber-success);
  box-shadow: 0 0 15px rgba(0, 255, 136, 0.3);
}

/* 图像对比 */
.comparison-container {
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  gap: 3rem;
  align-items: center;
}

.image-panel {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.panel-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.panel-header h4 {
  font-size: 1.2rem;
  color: var(--cyber-text-primary);
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
  margin: 0;
}

.panel-badge {
  padding: 4px 12px;
  border-radius: 15px;
  font-size: 10px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.panel-badge.original {
  background: rgba(0, 234, 255, 0.2);
  color: var(--cyber-primary);
  border: 1px solid var(--cyber-primary);
}

.panel-badge.detected {
  background: rgba(255, 165, 0, 0.2);
  color: rgba(255, 165, 0, 0.9);
  border: 1px solid rgba(255, 165, 0, 0.5);
}

.image-container {
  position: relative;
  border-radius: 20px;
  overflow: hidden;
  border: 2px solid rgba(0, 234, 255, 0.3);
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
}

.comparison-image {
  width: 100%;
  height: 300px;
  object-fit: contain;
  background: var(--cyber-bg-primary);
}

.image-scan-line {
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(0, 234, 255, 0.2), transparent);
  animation: scanLine 4s ease-in-out infinite;
}

.comparison-arrow {
  display: flex;
  justify-content: center;
  align-items: center;
}

.arrow-container {
  position: relative;
  font-size: 3rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  animation: floatUp 2s ease-in-out infinite;
}

.arrow-glow {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 60px;
  height: 60px;
  background: radial-gradient(circle, rgba(0, 234, 255, 0.2) 0%, transparent 70%);
  border-radius: 50%;
  animation: breathe 3s ease-in-out infinite;
}

/* 检测说明面板 */
.detection-info-panel {
  max-width: 800px;
  margin: 0 auto;
}

.info-header {
  margin-bottom: 1.5rem;
}

.info-header h3 {
  display: flex;
  align-items: center;
  gap: 1rem;
  font-size: 1.3rem;
  color: var(--cyber-text-primary);
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
  margin: 0;
}

.info-header i {
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
}

.info-content {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.info-tip {
  display: flex;
  align-items: flex-start;
  gap: 1rem;
  padding: 1.5rem;
  background: rgba(0, 234, 255, 0.05);
  border: 1px solid rgba(0, 234, 255, 0.2);
  border-radius: 15px;
}

.tip-icon {
  font-size: 1.5rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  min-width: 30px;
  margin-top: 0.2rem;
}

.tip-text {
  color: var(--cyber-text-secondary);
  line-height: 1.5;
}

.tip-text strong {
  color: var(--cyber-text-primary);
}

/* 操作按钮 */
.result-actions {
  display: flex;
  justify-content: center;
  padding: 2rem 0;
}

.download-btn-enhanced {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 18px 35px;
  background: var(--cyber-gradient-primary);
  border: none;
  border-radius: 20px;
  color: white;
  font-family: 'Orbitron', monospace;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 2px;
  cursor: pointer;
  transition: all 0.4s ease;
  position: relative;
  overflow: hidden;
  box-shadow: 0 10px 30px rgba(0, 234, 255, 0.3);
}

.download-btn-enhanced:hover {
  transform: translateY(-5px) scale(1.05);
  box-shadow: 0 20px 50px rgba(0, 234, 255, 0.4);
}

.btn-glow {
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
  transition: left 0.6s ease;
}

.download-btn-enhanced:hover .btn-glow {
  left: 100%;
}

/* 响应式设计 */
@media (max-width: 1200px) {
  .main-workspace {
    grid-template-columns: 1fr;
    gap: 2rem;
  }

  .comparison-container {
    grid-template-columns: 1fr;
    gap: 2rem;
  }

  .comparison-arrow {
    transform: rotate(90deg);
  }
}

@media (max-width: 768px) {
  .tl-bg {
    gap: 2rem;
  }

  .page-header {
    padding: 1.5rem 0;
  }

  .title-main {
    font-size: 2.2rem;
    letter-spacing: 2px;
  }

  .title-sub {
    font-size: 1rem;
  }

  .cyber-glass-card {
    padding: 2rem;
  }

  .workspace-header {
    flex-direction: column;
    gap: 1rem;
    text-align: center;
  }

  .image-preview-enhanced {
    height: 250px;
  }

  .result-header {
    flex-direction: column;
    gap: 1rem;
    text-align: center;
  }

  .detection-info {
    gap: 1rem;
  }

  .info-item {
    flex-direction: column;
    text-align: center;
    gap: 1rem;
  }
}

@media (max-width: 480px) {
  .title-main {
    font-size: 1.8rem;
  }

  .cyber-glass-card {
    padding: 1.5rem;
  }

  .image-preview-enhanced {
    height: 200px;
  }

  .info-tip {
    flex-direction: column;
    gap: 0.8rem;
  }
}

/* 动画关键帧 */
@keyframes breathe {
  0%, 100% {
    opacity: 0.8;
    transform: scale(1);
  }
  50% {
    opacity: 1;
    transform: scale(1.05);
  }
}

@keyframes floatUp {
  0%, 100% {
    transform: translateY(0px);
  }
  50% {
    transform: translateY(-10px);
  }
}

@keyframes scanLine {
  0% {
    left: -100%;
    opacity: 0;
  }
  50% {
    opacity: 1;
  }
  100% {
    left: 100%;
    opacity: 0;
  }
}

@keyframes progressBar {
  0% { width: 0%; }
  50% { width: 70%; }
  100% { width: 100%; }
}

@keyframes rotate {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}
</style>
