<template>
  <div>
    <div class="identity-swap-container">
    <!-- 上传区域 -->
    <div class="upload-container">
      <div class="image-preview-enhanced">
        <div v-if="originUrl" class="preview-wrapper">
          <img :src="originUrl" alt="原始图片" class="preview-image" />
          <div class="image-overlay">
            <div class="image-info">
              <i class="ri-image-line"></i>
              <span>待处理图像</span>
            </div>
          </div>
        </div>
        <div v-else class="upload-placeholder">
          <div class="placeholder-icon">
            <i class="ri-image-add-line"></i>
          </div>
          <div class="placeholder-text">
            <h4>拖拽图片到此处或点击上传</h4>
            <p>支持 JPG、PNG 格式，建议尺寸 512x512</p>
          </div>
          <div class="scan-animation"></div>
        </div>
      </div>

      <div class="upload-controls">
        <el-upload
          class="upload-btn-enhanced"
          :show-file-list="false"
          :before-upload="beforeUpload"
          :on-change="onFileChange"
          :auto-upload="false"
        >
          <button class="cyber-btn-enhanced">
            <i class="ri-upload-2-line"></i>
            <span>选择图片</span>
          </button>
        </el-upload>
      </div>
    </div>

    <!-- 配置区域 -->
    <div class="config-container">
      <div class="config-section">
        <label class="config-label">
          <i class="ri-cpu-line"></i>
          伪造模型选择
        </label>
        <div class="model-selector">
          <div
            class="model-option"
            :class="{ active: model === 'FaceShifter' }"
            @click="model = 'FaceShifter'"
          >
            <div class="model-icon">
              <i class="ri-user-shared-line"></i>
            </div>
            <div class="model-text">
              <h4>FaceShifter</h4>
              <p>高质量面部替换</p>
            </div>
            <div class="model-indicator"></div>
          </div>

          <div
            class="model-option"
            :class="{ active: model === 'Simswap' }"
            @click="model = 'Simswap'"
          >
            <div class="model-icon">
              <i class="ri-swap-line"></i>
            </div>
            <div class="model-text">
              <h4>Simswap</h4>
              <p>快速身份交换</p>
            </div>
            <div class="model-indicator"></div>
          </div>

          <div
            class="model-option"
            :class="{ active: model === 'InfoSwap' }"
            @click="model = 'InfoSwap'"
          >
            <div class="model-icon">
              <i class="ri-information-line"></i>
            </div>
            <div class="model-text">
              <h4>InfoSwap</h4>
              <p>信息保持交换</p>
            </div>
            <div class="model-indicator"></div>
          </div>
        </div>
      </div>

      <div class="action-section">
        <button
          class="deepfake-btn-enhanced"
          :class="{ loading: loading, disabled: !file }"
          :disabled="!file || loading"
          @click="onDeepfake"
        >
          <div class="btn-content">
            <i class="ri-sword-line" v-if="!loading"></i>
            <i class="ri-loader-4-line rotating" v-else></i>
            <span>{{ loading ? '正在伪造...' : '开始身份伪造' }}</span>
          </div>
          <div class="btn-progress" v-if="loading"></div>
        </button>
      </div>
    </div>
  </div>
     <!-- 结果展示区域 - 独立双列框框 -->
  </div>
  <div v-if="resultUrl" class="result-workspace">
      <div class="result-header">
        <h3 class="result-title">
          <i class="ri-check-double-line"></i>
          伪造结果
        </h3>
        <div class="result-status success">
          <i class="ri-shield-check-fill"></i>
          <span>伪造完成</span>
        </div>
      </div>

      <!-- 双列图像展示 -->
      <div class="result-content">
        <div class="result-left">
          <div class="image-panel">
            <div class="panel-header">
              <h4>原始图像</h4>
              &nbsp;&nbsp;&nbsp;
              <div class="panel-badge original">ORIGINAL</div>
            </div>
            <div class="image-container">
              <img :src="originUrl" alt="原始图片" class="comparison-image" />
              <div class="image-scan-line"></div>
            </div>
          </div>
        </div>

        <div class="result-right">
          <div class="image-panel">
            <div class="panel-header">
              <h4>伪造图像</h4>
              <div class="panel-badge deepfake">DEEPFAKE</div>
            </div>
            <div class="image-container">
              <img :src="resultUrl" alt="伪造图片" class="comparison-image" />
              <div class="image-scan-line"></div>
            </div>
          </div>
        </div>
      </div>

      <!-- 操作按钮 -->
      <div class="result-actions">
        <button class="download-btn-enhanced" @click="downloadResult">
          <i class="ri-download-2-line"></i>
          <span>下载伪造图像</span>
          <div class="btn-glow"></div>
        </button>
      </div>
    </div>

</template>

<script setup>
import { ref } from 'vue'
import { ElMessage } from 'element-plus'
import { deepfake } from '../api/deepfake'

const file = ref(null)
const originUrl = ref('')
const resultUrl = ref('')
const model = ref('FaceShifter')
const loading = ref(false)

function beforeUpload(rawFile) { return true }
function onFileChange(uploadFile) {
  file.value = uploadFile.raw
  originUrl.value = URL.createObjectURL(uploadFile.raw)
  resultUrl.value = ''
}
async function onDeepfake() {
  if (!file.value) { ElMessage.error('请先上传图片'); return }
  loading.value = true
  try {
    const res = await deepfake({ file: file.value, model: model.value })
    if (res.status === 200) {
      const blob = await res.blob()
      resultUrl.value = URL.createObjectURL(blob)
      ElMessage.success('伪造成功')
    } else {
      ElMessage.error('伪造失败')
    }
  } catch (e) {
    ElMessage.error('网络错误，请稍后重试')
  } finally {
    loading.value = false
  }
}
function downloadResult() {
  if (!resultUrl.value) return
  const a = document.createElement('a')
  a.href = resultUrl.value
  a.download = 'deepfake.png'
  a.click()
}
</script>

<style scoped>
@import '@/assets/enhanced-cyber-theme.css';

.identity-swap-container {
  display: flex;
  flex-direction: column;
  gap: 2.5rem;
  padding: 0;
}

/* 上传区域 */
.upload-container {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

.image-preview-enhanced {
  width: 100%;
  height: 300px;
  border-radius: 20px;
  border: 2px dashed rgba(0, 234, 255, 0.3);
  position: relative;
  overflow: hidden;
  transition: all 0.4s ease;
}

.image-preview-enhanced:hover {
  border-color: var(--cyber-primary);
  box-shadow: 0 0 30px rgba(0, 234, 255, 0.3);
}

.preview-wrapper {
  width: 100%;
  height: 100%;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
}

.preview-image {
  max-width: 100%;
  max-height: 100%;
  object-fit: contain;
  border-radius: 15px;
}

.image-overlay {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  background: linear-gradient(transparent, rgba(0, 0, 0, 0.8));
  padding: 1rem;
  display: flex;
  justify-content: center;
}

.image-info {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  color: var(--cyber-primary);
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.upload-placeholder {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  position: relative;
}

.placeholder-icon {
  font-size: 4rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  margin-bottom: 1.5rem;
  animation: floatUp 3s ease-in-out infinite;
}

.placeholder-text h4 {
  font-size: 1.2rem;
  color: var(--cyber-text-primary);
  margin-bottom: 0.5rem;
  font-weight: 600;
}

.placeholder-text p {
  color: var(--cyber-text-secondary);
  font-size: 0.9rem;
}

.scan-animation {
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(0, 234, 255, 0.1), transparent);
  animation: scanLine 3s ease-in-out infinite;
}

.upload-controls {
  display: flex;
  justify-content: center;
}

.cyber-btn-enhanced {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 15px 30px;
  background: var(--cyber-gradient-primary);
  border: none;
  border-radius: 15px;
  color: white;
  font-family: 'Orbitron', monospace;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
  cursor: pointer;
  transition: all 0.4s ease;
  box-shadow: 0 8px 25px rgba(0, 234, 255, 0.3);
}

.cyber-btn-enhanced:hover {
  transform: translateY(-3px) scale(1.05);
  box-shadow: 0 15px 35px rgba(0, 234, 255, 0.4);
}

/* 配置区域 */
.config-container {
  display: flex;
  flex-direction: column;
  gap: 2.5rem;
}

.config-section {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

.config-label {
  display: flex;
  align-items: center;
  gap: 1rem;
  font-size: 1.2rem;
  color: var(--cyber-text-primary);
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
  margin-bottom: 1rem;
}

.config-label i {
  font-size: 1.3rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
}

.model-selector {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.model-option {
  display: flex;
  align-items: center;
  gap: 1.5rem;
  padding: 1.5rem;
  background: rgba(30, 40, 80, 0.6);
  border: 2px solid rgba(0, 234, 255, 0.2);
  border-radius: 15px;
  cursor: pointer;
  transition: all 0.4s ease;
  position: relative;
  overflow: hidden;
}

.model-option:hover {
  border-color: rgba(0, 234, 255, 0.4);
  transform: translateX(5px);
  box-shadow: 0 5px 20px rgba(0, 234, 255, 0.2);
}

.model-option.active {
  border-color: var(--cyber-primary);
  background: rgba(0, 234, 255, 0.1);
  box-shadow: 0 0 20px rgba(0, 234, 255, 0.3);
}

.model-option.active::after {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(0, 234, 255, 0.1), transparent);
  animation: scanLine 2s ease-in-out;
}

.model-icon {
  font-size: 2rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  min-width: 50px;
  display: flex;
  justify-content: center;
}

.model-text {
  flex: 1;
}

.model-text h4 {
  font-size: 1.1rem;
  color: var(--cyber-text-primary);
  margin-bottom: 0.3rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.model-text p {
  color: var(--cyber-text-secondary);
  font-size: 0.9rem;
  margin: 0;
  line-height: 1.4;
}

.model-indicator {
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: var(--cyber-text-muted);
  transition: all 0.3s ease;
  min-width: 12px;
}

.model-option.active .model-indicator {
  background: var(--cyber-primary);
  box-shadow: 0 0 15px var(--cyber-primary);
}

.action-section {
  display: flex;
  justify-content: center;
}

.deepfake-btn-enhanced {
  width: 100%;
  padding: 18px;
  background: var(--cyber-gradient-primary);
  border: none;
  border-radius: 15px;
  color: white;
  font-family: 'Orbitron', monospace;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 2px;
  cursor: pointer;
  transition: all 0.4s ease;
  position: relative;
  overflow: hidden;
  box-shadow: 0 10px 30px rgba(0, 234, 255, 0.3);
}

.deepfake-btn-enhanced:hover:not(.disabled) {
  transform: translateY(-3px);
  box-shadow: 0 15px 40px rgba(0, 234, 255, 0.4);
}

.deepfake-btn-enhanced.disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.btn-content {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1rem;
  position: relative;
  z-index: 2;
}

.btn-progress {
  position: absolute;
  bottom: 0;
  left: 0;
  height: 3px;
  background: var(--cyber-gradient-accent);
  animation: progressBar 2s ease-in-out infinite;
}

.rotating {
  animation: rotate 1s linear infinite;
}

/* 结果展示区域 */
.result-workspace {
  display: flex;
  flex-direction: column;
  gap: 2.5rem;
  margin-top: 2rem;
  padding: 2.5rem;
  background: var(--cyber-gradient-glass);
  backdrop-filter: blur(20px);
  border: 2px solid rgba(0, 234, 255, 0.3);
  border-radius: 25px;
  box-shadow:
    0 20px 60px rgba(0, 0, 0, 0.4),
    0 0 40px rgba(0, 234, 255, 0.2);
  position: relative;
  overflow: hidden;
}

.result-workspace::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 3px;
  background: var(--cyber-gradient-primary);
}

.result-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-bottom: 1rem;
  border-bottom: 1px solid rgba(0, 234, 255, 0.2);
}

.result-title {
  display: flex;
  align-items: center;
  gap: 1rem;
  font-size: 1.5rem;
  color: var(--cyber-primary);
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 2px;
  text-shadow: var(--cyber-glow-primary);
  margin: 0;
}

.result-status {
  display: flex;
  align-items: center;
  gap: 0.8rem;
  padding: 8px 16px;
  border-radius: 15px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 1px;
  font-size: 0.9rem;
}

.result-status.success {
  background: rgba(0, 255, 136, 0.1);
  color: var(--cyber-success);
  border: 1px solid var(--cyber-success);
  box-shadow: 0 0 15px rgba(0, 255, 136, 0.3);
}

/* 双列图像展示 */
.result-content {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 2rem;
  margin-bottom: 2rem;
}

.result-left,
.result-right {
  display: flex;
  flex-direction: column;
}

.image-panel {
  background: var(--cyber-bg-primary);
  border: 1px solid var(--cyber-border-secondary);
  border-radius: 16px;
  padding: 1.5rem;
  transition: all 0.3s ease;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
}

.image-panel:hover {
  border-color: var(--cyber-accent-primary);
  box-shadow: 0 8px 30px rgba(0, 255, 255, 0.15);
  transform: translateY(-2px);
}

.panel-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 1rem;
  padding-bottom: 0.75rem;
  border-bottom: 1px solid var(--cyber-border-secondary);
}

.panel-header h4 {
  color: var(--cyber-text-primary);
  margin: 0;
  font-size: 1.1rem;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.panel-badge {
  padding: 0.25rem 0.75rem;
  border-radius: 6px;
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.panel-badge.original {
  background: rgba(100, 149, 237, 0.2);
  color: #6495ED;
  border: 1px solid #6495ED;
}

.panel-badge.deepfake {
  background: rgba(255, 99, 71, 0.2);
  color: #FF6347;
  border: 1px solid #FF6347;
}

.image-container {
  position: relative;
  border-radius: 12px;
  overflow: hidden;
  background: var(--cyber-bg-secondary);
  border: 1px solid var(--cyber-border-secondary);
  transition: all 0.3s ease;
}

.image-container:hover {
  border-color: var(--cyber-accent-primary);
  box-shadow: 0 4px 20px rgba(0, 255, 255, 0.1);
}

.comparison-image {
  width: 100%;
  height: auto;
  min-height: 250px;
  object-fit: contain;
  display: block;
  border-radius: 12px;
}

.image-scan-line {
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 2px;
  background: linear-gradient(90deg, transparent, var(--cyber-accent-primary), transparent);
  animation: scan 3s linear infinite;
}



/* 操作按钮 */
.result-actions {
  display: flex;
  justify-content: center;
  padding: 1rem 0;
}

.download-btn-enhanced {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 15px 30px;
  background: var(--cyber-gradient-primary);
  border: none;
  border-radius: 15px;
  color: white;
  font-family: 'Orbitron', monospace;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 2px;
  cursor: pointer;
  transition: all 0.4s ease;
  position: relative;
  overflow: hidden;
  box-shadow: 0 8px 25px rgba(0, 234, 255, 0.3);
}

.download-btn-enhanced:hover {
  transform: translateY(-3px) scale(1.05);
  box-shadow: 0 15px 35px rgba(0, 234, 255, 0.4);
}

.btn-glow {
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
  transition: left 0.6s ease;
}

.download-btn-enhanced:hover .btn-glow {
  left: 100%;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .identity-swap-container {
    gap: 2rem;
  }

  .image-preview-enhanced {
    height: 250px;
  }

  .result-content {
    grid-template-columns: 1fr;
    gap: 1.5rem;
  }

  .comparison-image {
    height: 200px;
  }

  .model-option {
    flex-direction: column;
    text-align: center;
    gap: 1rem;
    padding: 1.2rem;
  }

  .result-header {
    flex-direction: column;
    gap: 1rem;
    text-align: center;
  }
}

@media (max-width: 480px) {
  .image-preview-enhanced {
    height: 200px;
  }

  .comparison-image {
    height: 150px;
  }

  .model-icon {
    font-size: 1.5rem;
  }

  .model-text h4 {
    font-size: 1rem;
  }

  .model-text p {
    font-size: 0.8rem;
  }
}

/* 动画关键帧 */
@keyframes breathe {
  0%, 100% {
    opacity: 0.8;
    transform: scale(1);
  }
  50% {
    opacity: 1;
    transform: scale(1.05);
  }
}

@keyframes floatUp {
  0%, 100% {
    transform: translateY(0px);
  }
  50% {
    transform: translateY(-10px);
  }
}

@keyframes scan {
  0% { left: -100%; }
  100% { left: 100%; }
}

@keyframes scanLine {
  0% {
    left: -100%;
    opacity: 0;
  }
  50% {
    opacity: 1;
  }
  100% {
    left: 100%;
    opacity: 0;
  }
}

@keyframes pulse {
  0%, 100% {
    opacity: 1;
    transform: scale(1);
  }
  50% {
    opacity: 0.8;
    transform: scale(1.05);
  }
}

@keyframes progressBar {
  0% { width: 0%; }
  50% { width: 70%; }
  100% { width: 100%; }
}

@keyframes rotate {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}
</style>
