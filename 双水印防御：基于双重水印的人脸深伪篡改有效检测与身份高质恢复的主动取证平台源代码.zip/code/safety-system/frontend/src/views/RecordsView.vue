<template>
  <div class="records-bg">
    <h2 class="records-title">水印操作记录</h2>
    <el-table
      v-if="records.length"
      :data="records"
      border
      class="records-table"
      style="width: 100%; max-width: 1100px; margin: 0 auto;"
    >
      <el-table-column prop="displayId" label="序号" width="80" align="center" header-align="center" />
      <el-table-column label="水印类型" min-width="140" align="center" header-align="center">
        <template #default="scope">
          <span :class="['wm-type-tag', getTypeClass(scope.row.type)]">{{ scope.row.type }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="file_hash" label="文件哈希" min-width="220" align="center" header-align="center" />
      <el-table-column label="操作" width="100" align="center" header-align="center">
        <template #default="scope">
          <span :class="['op-tag', getOpClass(scope.row.operation)]">{{ scope.row.operation }}</span>
        </template>
      </el-table-column>
      <el-table-column label="时间" min-width="200" align="center" header-align="center">
        <template #default="scope">
          <span class="time-cell">{{ formatTime(scope.row.time) }}</span>
        </template>
      </el-table-column>
    </el-table>
    <div v-else class="empty-tip">暂无水印操作记录</div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { getWatermarkRecords } from '../api/watermark'
import { ElMessage } from 'element-plus'

const records = ref([])

function getOpClass(op) {
  return op === '嵌入' ? 'op-embed' : 'op-extract'
}
function getTypeClass(type) {
  if (type.includes('双重')) return 'wm-type-double'
  if (type.includes('身份恢复')) return 'wm-type-id'
  if (type.includes('篡改定位')) return 'wm-type-tl'
  return ''
}
function formatTime(timeStr) {
  if (!timeStr) return ''
  const d = new Date(timeStr)
  if (isNaN(d.getTime())) return timeStr
  const pad = n => n.toString().padStart(2, '0')
  return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`
}

onMounted(async () => {
  const { status, data } = await getWatermarkRecords()
  if (status === 200 && data.records) {
    // 先按原始id顺序排序
    const sorted = [...data.records].sort((a, b) => a.id - b.id)
    // 重新编号，id从1递增
    const reNumbered = sorted.map((item, idx) => ({ ...item, displayId: idx + 1 }))
    // 按新编号倒序排列
    records.value = reNumbered.sort((a, b) => b.displayId - a.displayId)
  } else {
    ElMessage.error('获取水印记录失败')
  }
})
</script>

<style scoped>
.records-bg {
  min-height: 80vh;
  padding: 2.5rem 2rem;
  background: transparent;
}
.records-title {
  font-size: 2rem;
  color: #00eaff;
  text-shadow: 0 0 8px #00eaff, 0 0 16px #0050ff;
  margin-bottom: 2.2rem;
  letter-spacing: 2px;
  text-align: center;
}
.records-table {
  font-size: 1.1rem;
  border-radius: 1.2rem;
  box-shadow: 0 0 16px #00eaff33, 0 0 32px #0050ff22;
  background: rgba(30, 40, 80, 0.92);
}
.el-table th {
  font-family: 'Orbitron', 'Share Tech Mono', 'Consolas', monospace;
  font-size: 1.15rem;
  font-weight: bold;
  color: #00eaff;
  background: #181e2a !important;
  letter-spacing: 1px;
}
.el-table td {
  color: #e0eaff;
  background: #1a2233;
}
.empty-tip {
  color: #a0bfff;
  font-size: 1.2rem;
  text-align: center;
  margin-top: 3rem;
}
/* 操作类型标签 */
.op-tag {
  display: inline-block;
  padding: 0.18em 1.1em;
  border-radius: 1em;
  font-weight: bold;
  font-size: 1.05em;
  border: 2px solid;
  letter-spacing: 1px;
}
.op-embed {
  color: #2196f3;
  border-color: #2196f3;
  background: rgba(33,150,243,0.08);
}
.op-extract {
  color: #43c97f;
  border-color: #43c97f;
  background: rgba(67,201,127,0.08);
}
/* 水印类型标签 */
.wm-type-tag {
  display: inline-block;
  padding: 0.18em 1.1em;
  border-radius: 1em;
  font-weight: bold;
  font-size: 1.05em;
  border: 2px solid;
  letter-spacing: 1px;
}
.wm-type-double {
  color: #ff3b3b;
  border-color: #ff3b3b;
  background: rgba(255,59,59,0.08);
}
.wm-type-id {
  color: #a259ff;
  border-color: #a259ff;
  background: rgba(162,89,255,0.08);
}
.wm-type-tl {
  color: #00bcd4;
  border-color: #00bcd4;
  background: rgba(0,188,212,0.08);
}
.time-cell {
  font-family: 'Share Tech Mono', 'Consolas', monospace;
  font-size: 1.08em;
  color: #222;
  letter-spacing: 1px;
  background: rgba(0,234,255,0.03);
  border-radius: 0.5em;
  padding: 0.1em 0.7em;
  display: inline-block;
}
</style> 