<template>
  <div class="login-container">
    <!-- 动态背景 -->
    <div class="cyber-background">
      <div class="particle-field"></div>
      <div class="grid-overlay"></div>
      <div class="scan-lines"></div>
      <div class="floating-elements">
        <div class="float-element element-1"></div>
        <div class="float-element element-2"></div>
        <div class="float-element element-3"></div>
        <div class="float-element element-4"></div>
      </div>
    </div>


    <!-- 主要内容区域 -->
    <div class="main-content">
      <!-- 左侧信息区域 -->
      <div class="info-section">
        <div class="system-branding">
          <div class="brand-icon">
            <i class="ri-shield-keyhole-line"></i>
          </div>
          <h1 class="brand-title">FORENSIC SYSTEM</h1>
          <p class="brand-subtitle">人脸深度伪造主动取证系统</p>
        </div>

        <div class="feature-highlights">
          <div class="feature-item">
            <div class="feature-icon">
              <i class="ri-shield-star-line"></i>
            </div>
            <div class="feature-text">
              <h3>双重水印保护</h3>
              <p>篡改定位与身份恢复双重防护</p>
            </div>
          </div>

          <div class="feature-item">
            <div class="feature-icon">
              <i class="ri-eye-line"></i>
            </div>
            <div class="feature-text">
              <h3>智能检测技术</h3>
              <p>基于深度学习的高精度识别</p>
            </div>
          </div>

          <div class="feature-item">
            <div class="feature-icon">
              <i class="ri-lock-line"></i>
            </div>
            <div class="feature-text">
              <h3>安全加密传输</h3>
              <p>端到端加密保护数据安全</p>
            </div>
          </div>
        </div>

<!--        <div class="security-status">-->
<!--          <div class="status-indicator">-->
<!--            <div class="status-dot active"></div>-->
<!--            <span>系统安全运行中</span>-->
<!--          </div>-->
<!--          <div class="encryption-badge">-->
<!--            <i class="ri-shield-check-fill"></i>-->
<!--            <span>256位加密</span>-->
<!--          </div>-->
<!--        </div>-->
      </div>

       <!-- 返回主页按钮 -->
      <div class="back-to-home">
        <button class="home-btn" @click="$router.push('/')" title="返回主页">
          <i class="ri-home-line"></i>
          <span>返回主页</span>
        </button>
      </div>

      <!-- 右侧登录区域 -->
      <div class="login-section">

        <div class="login-panel">
          <!-- 登录头部 -->
          <div class="login-header">
            <div class="header-icon">
              <i class="ri-login-circle-line"></i>
            </div>
            <h2 class="login-title">系统登录</h2>
            <p class="login-subtitle">请输入您的凭据以访问系统</p>
          </div>

          <!-- 登录表单 -->
          <el-form
            :model="loginForm"
            :rules="rules"
            ref="formRef"
            class="login-form"
            @submit.prevent="onLogin"
          >
            <div class="form-group">
              <label class="form-label">邮箱地址</label>
              <el-form-item prop="email" class="form-item-enhanced">
                  <div class="input-icon" style="margin-left: 18px">
                    <i class="ri-mail-line"></i>
                  </div>
                  <el-input
                    v-model="loginForm.email"
                    placeholder="请输入您的邮箱地址"
                    clearable
                    class="cyber-input"
                    size="large"
                    autocomplete="off"
                  />
                  <div class="input-glow"></div>
              </el-form-item>
            </div>

            <div class="form-group">
              <label class="form-label">登录密码</label>
              <el-form-item prop="password" class="form-item-enhanced">
                  <div class="input-icon" style="margin-left: 18px">
                    <i class="ri-lock-line"></i>
                  </div>
                  <el-input
                    v-model="loginForm.password"
                    placeholder="请输入您的密码"
                    show-password
                    clearable
                    class="cyber-input"
                    size="large"
                    autocomplete="new-password"
                  />
                  <div class="input-glow"></div>
              </el-form-item>
            </div>

            <div class="form-actions">
              <button
                class="login-btn-enhanced"
                :class="{ loading: loading }"
                :disabled="loading"
                @click="onLogin"
                type="button"
              >
                <div class="btn-content">
                  <i class="ri-shield-check-line" v-if="!loading"></i>
                  <i class="ri-loader-4-line rotating" v-else></i>
                  <span>{{ loading ? '验证中...' : '安全登录' }}</span>
                </div>
                <div class="btn-progress" v-if="loading"></div>
                <div class="btn-glow"></div>
              </button>
            </div>
          </el-form>

          <!-- 表单底部 -->
          <div class="form-footer">
            <div class="divider">
              <span class="divider-text">其他选项</span>
            </div>
            <div class="register-section">
              <span class="register-text">还没有账号？</span>
              <button class="register-link" @click="$router.push('/register')">
                <i class="ri-user-add-line"></i>
                <span>立即注册</span>
              </button>
            </div>
          </div>

          <!-- 错误提示 -->
          <div v-if="errorMsg" class="error-panel">
            <div class="error-content">
              <i class="ri-error-warning-line"></i>
              <span>{{ errorMsg }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { login as loginApi } from '../api/auth'

const router = useRouter()
const loginForm = ref({ email: '', password: '' })
const loading = ref(false)
const errorMsg = ref('')
const formRef = ref()

const rules = {
  email: [
    { required: true, message: '请输入邮箱', trigger: 'blur' },
    { type: 'email', message: '邮箱格式不正确', trigger: ['blur', 'change'] }
  ],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, message: '密码至少6位', trigger: 'blur' }
  ]
}

async function onLogin() {
  errorMsg.value = ''
  await formRef.value.validate(async (valid) => {
    if (!valid) return
    loading.value = true
    try {
      const { status, data } = await loginApi(loginForm.value)
      if ((status === 200 || status === 201) && data.access_token) {
        localStorage.setItem('token', data.access_token)
        ElMessage.success('登录成功')
        router.push('/dashboard')
      } else {
        errorMsg.value = data.msg || '登录失败，账号或密码错误'
      }
    } catch (e) {
      errorMsg.value = '网络错误，请稍后重试'
    } finally {
      loading.value = false
    }
  })
}
</script>

<style scoped>
@import '@/assets/enhanced-cyber-theme.css';

.login-container {
  min-height: 100vh;
  width: 100vw;
  position: relative;
  overflow: hidden;
  background: var(--cyber-bg-primary);
  font-family: 'Orbitron', monospace;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* 动态背景 */
.cyber-background {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 1;
}

.particle-field {
  position: absolute;
  width: 100%;
  height: 100%;
  background-image:
    radial-gradient(2px 2px at 20px 30px, var(--cyber-primary), transparent),
    radial-gradient(2px 2px at 40px 70px, var(--cyber-accent), transparent),
    radial-gradient(1px 1px at 90px 40px, var(--cyber-primary), transparent),
    radial-gradient(1px 1px at 130px 80px, var(--cyber-accent), transparent),
    radial-gradient(2px 2px at 160px 30px, var(--cyber-primary), transparent);
  background-repeat: repeat;
  background-size: 200px 100px;
  animation: particleFloat 20s linear infinite;
  opacity: 0.4;
}

.grid-overlay {
  position: absolute;
  width: 100%;
  height: 100%;
  background-image:
    linear-gradient(rgba(0, 234, 255, 0.08) 1px, transparent 1px),
    linear-gradient(90deg, rgba(0, 234, 255, 0.08) 1px, transparent 1px);
  background-size: 60px 60px;
  animation: gridMove 40s linear infinite;
}

.scan-lines {
  position: absolute;
  width: 100%;
  height: 100%;
  background: repeating-linear-gradient(
    0deg,
    transparent,
    transparent 2px,
    rgba(0, 234, 255, 0.02) 2px,
    rgba(0, 234, 255, 0.02) 4px
  );
  animation: scanMove 12s linear infinite;
}

.floating-elements {
  position: absolute;
  width: 100%;
  height: 100%;
  pointer-events: none;
}

.float-element {
  position: absolute;
  border: 2px solid rgba(0, 234, 255, 0.15);
  border-radius: 50%;
}

.element-1 {
  width: 300px;
  height: 300px;
  top: 10%;
  left: 5%;
  border-style: dashed;
  animation: rotate 30s linear infinite;
}

.element-2 {
  width: 200px;
  height: 200px;
  bottom: 15%;
  right: 8%;
  animation: rotate 25s linear infinite reverse;
}

.element-3 {
  width: 150px;
  height: 150px;
  top: 60%;
  left: 15%;
  border-color: rgba(255, 0, 110, 0.15);
  animation: rotate 35s linear infinite;
}

.element-4 {
  width: 100px;
  height: 100px;
  top: 20%;
  right: 25%;
  border-style: dotted;
  animation: rotate 20s linear infinite reverse;
}

/* 主要内容区域 */
.main-content {
  position: relative;
  z-index: 10;
  width: 100%;
  max-width: 1400px;
  height: 100vh;
  display: grid;
  grid-template-columns: 1fr 1fr;
  align-items: center;
  padding: 0 4rem;
  gap: 6rem;
}

/* 左侧信息区域 */
.info-section {
  display: flex;
  flex-direction: column;
  gap: 4rem;
  padding: 2rem 0;
}

.system-branding {
  text-align: left;
}

.brand-icon {
  font-size: 5rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  margin-bottom: 2rem;
  animation: breathe 4s ease-in-out infinite;
}

.brand-title {
  font-size: 3.5rem;
  font-weight: 900;
  text-transform: uppercase;
  letter-spacing: 4px;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  margin: 0 0 1rem 0;
  line-height: 1.1;
}

.brand-subtitle {
  font-size: 1.3rem;
  color: var(--cyber-text-secondary);
  letter-spacing: 2px;
  font-weight: 400;
  margin: 0;
  opacity: 0.9;
}

.feature-highlights {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

.feature-item {
  display: flex;
  align-items: center;
  gap: 1.5rem;
  padding: 1.5rem;
  background: rgba(30, 40, 80, 0.3);
  border: 1px solid rgba(0, 234, 255, 0.2);
  border-radius: 20px;
  backdrop-filter: blur(10px);
  transition: all 0.4s ease;
}

.feature-item:hover {
  border-color: rgba(0, 234, 255, 0.4);
  transform: translateX(10px);
  box-shadow: 0 10px 30px rgba(0, 234, 255, 0.2);
}

.feature-icon {
  font-size: 2.5rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  min-width: 60px;
}

.feature-text h3 {
  font-size: 1.2rem;
  color: var(--cyber-text-primary);
  font-weight: 700;
  margin: 0 0 0.5rem 0;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.feature-text p {
  font-size: 0.9rem;
  color: var(--cyber-text-secondary);
  margin: 0;
  line-height: 1.4;
}

.security-status {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.5rem;
  background: rgba(0, 255, 136, 0.05);
  border: 1px solid rgba(0, 255, 136, 0.2);
  border-radius: 20px;
  backdrop-filter: blur(10px);
}

.status-indicator {
  display: flex;
  align-items: center;
  gap: 0.8rem;
  color: var(--cyber-success);
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.status-dot {
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: var(--cyber-text-muted);
  transition: all 0.3s ease;
}

.status-dot.active {
  background: var(--cyber-success);
  box-shadow: 0 0 15px var(--cyber-success);
  animation: breathe 2s ease-in-out infinite;
}

.encryption-badge {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 8px 15px;
  background: rgba(0, 255, 136, 0.1);
  border: 1px solid var(--cyber-success);
  border-radius: 15px;
  color: var(--cyber-success);
  font-size: 0.8rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
}

/* 右侧登录区域 */
.login-section {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-end;
  position: relative;
}

/* 返回主页按钮 */
.back-to-home {
  position: absolute;
  margin-top: 60px;
  margin-right: -180px;
  top: -2rem;
  right: 0;
  z-index: 20;
}

.home-btn {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 12px 20px;
  background: rgba(0, 234, 255, 0.1);
  border: 2px solid rgba(0, 234, 255, 0.3);
  border-radius: 25px;
  color: var(--cyber-primary);
  font-family: 'Orbitron', monospace;
  font-size: 0.9rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 1px;
  cursor: pointer;
  transition: all 0.4s ease;
  backdrop-filter: blur(10px);
  box-shadow:
    0 4px 15px rgba(0, 234, 255, 0.2),
    inset 0 1px 0 rgba(255, 255, 255, 0.1);
  position: relative;
  overflow: hidden;
}

.home-btn::before {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(0, 234, 255, 0.2), transparent);
  transition: left 0.6s ease;
}

.home-btn:hover {
  border-color: var(--cyber-primary);
  background: rgba(0, 234, 255, 0.2);
  transform: translateY(-2px) scale(1.05);
  box-shadow:
    0 8px 25px rgba(0, 234, 255, 0.3),
    0 0 20px rgba(0, 234, 255, 0.2);
  text-shadow: 0 0 10px rgba(0, 234, 255, 0.5);
}

.home-btn:hover::before {
  left: 100%;
}

.home-btn:active {
  transform: translateY(-1px) scale(1.02);
}

.home-btn i {
  font-size: 1.1rem;
  text-shadow: var(--cyber-glow-primary);
}

.home-btn span {
  position: relative;
  z-index: 2;
}

.login-panel {
  width: 100%;
  max-width: 500px;
  background: var(--cyber-gradient-glass);
  backdrop-filter: blur(25px);
  border: 2px solid rgba(0, 234, 255, 0.3);
  border-radius: 30px;
  padding: 3rem;
  box-shadow:
    0 25px 80px rgba(0, 0, 0, 0.5),
    0 0 50px rgba(0, 234, 255, 0.2),
    inset 0 1px 0 rgba(255, 255, 255, 0.1);
  position: relative;
  overflow: hidden;
}

.login-panel::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 4px;
  background: var(--cyber-gradient-primary);
  border-radius: 30px 30px 0 0;
}

.login-panel::after {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: linear-gradient(45deg, transparent 30%, rgba(0, 234, 255, 0.05) 50%, transparent 70%);
  pointer-events: none;
  animation: shimmer 3s ease-in-out infinite;
}

.login-header {
  text-align: center;
  margin-bottom: 3rem;
  position: relative;
  z-index: 2;
}

.header-icon {
  font-size: 3.5rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  margin-bottom: 1.5rem;
  animation: breathe 4s ease-in-out infinite;
}

.login-title {
  font-size: 2.2rem;
  color: var(--cyber-text-primary);
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 2px;
  margin: 0 0 1rem 0;
  text-shadow: 0 0 20px rgba(0, 234, 255, 0.3);
}

.login-subtitle {
  font-size: 1rem;
  color: var(--cyber-text-secondary);
  margin: 0;
  letter-spacing: 1px;
}

/* 表单样式 */
.login-form {
  position: relative;
  z-index: 2;
}

.form-group {
  margin-bottom: 2rem;
}

.form-label {
  display: block;
  font-size: 0.9rem;
  color: var(--cyber-text-primary);
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 1px;
  margin-bottom: 0.8rem;
}

.form-item-enhanced {
  margin-bottom: 0;
}

.input-wrapper {
  position: relative;
  display: flex;
  align-items: center;
}

.input-icon {
  position: absolute;
  left: 18px;
  z-index: 3;
  font-size: 1.3rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
}

.cyber-input {
  width: 100%;
}

.cyber-input :deep(.el-input__wrapper) {
  background: rgba(18, 22, 41, 0.9);
  border: 2px solid rgba(0, 234, 255, 0.3);
  border-radius: 18px;
  padding: 18px 25px 18px 55px;
  box-shadow:
    0 8px 25px rgba(0, 0, 0, 0.4),
    inset 0 1px 0 rgba(255, 255, 255, 0.1);
  transition: all 0.4s ease;
  min-height: 60px;
}

.cyber-input :deep(.el-input__wrapper:hover) {
  border-color: rgba(0, 234, 255, 0.5);
  box-shadow:
    0 8px 25px rgba(0, 0, 0, 0.4),
    0 0 20px rgba(0, 234, 255, 0.2);
}

.cyber-input :deep(.el-input__wrapper.is-focus) {
  border-color: var(--cyber-primary);
  box-shadow:
    0 8px 25px rgba(0, 0, 0, 0.4),
    0 0 30px rgba(0, 234, 255, 0.3);
}

.cyber-input :deep(.el-input__inner) {
  background: transparent;
  border: none;
  color: var(--cyber-text-primary);
  font-size: 1.1rem;
  font-weight: 500;
  padding: 0;
}

.cyber-input :deep(.el-input__inner::placeholder) {
  color: var(--cyber-text-muted);
  font-weight: 400;
}

/* 覆盖浏览器自动填充样式 */
.cyber-input :deep(.el-input__inner:-webkit-autofill) {
  -webkit-box-shadow: 0 0 0 1000px rgba(18, 22, 41, 0.9) inset !important;
  -webkit-text-fill-color: var(--cyber-text-primary) !important;
  background-color: rgba(18, 22, 41, 0.9) !important;
  color: var(--cyber-text-primary) !important;
  transition: background-color 5000s ease-in-out 0s;
}

.cyber-input :deep(.el-input__inner:-webkit-autofill:hover) {
  -webkit-box-shadow: 0 0 0 1000px rgba(18, 22, 41, 0.9) inset !important;
  -webkit-text-fill-color: var(--cyber-text-primary) !important;
  background-color: rgba(18, 22, 41, 0.9) !important;
}

.cyber-input :deep(.el-input__inner:-webkit-autofill:focus) {
  -webkit-box-shadow: 0 0 0 1000px rgba(18, 22, 41, 0.9) inset !important;
  -webkit-text-fill-color: var(--cyber-text-primary) !important;
  background-color: rgba(18, 22, 41, 0.9) !important;
}

.cyber-input :deep(.el-input__inner:-webkit-autofill:active) {
  -webkit-box-shadow: 0 0 0 1000px rgba(18, 22, 41, 0.9) inset !important;
  -webkit-text-fill-color: var(--cyber-text-primary) !important;
  background-color: rgba(18, 22, 41, 0.9) !important;
}

.input-glow {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  border-radius: 18px;
  background: linear-gradient(45deg, transparent, rgba(0, 234, 255, 0.1), transparent);
  opacity: 0;
  transition: opacity 0.4s ease;
  pointer-events: none;
}

.cyber-input:focus-within .input-glow {
  opacity: 1;
}

/* 按钮样式 */
.form-actions {
  margin: 3rem 0 2rem 0;
}

.login-btn-enhanced {
  width: 100%;
  padding: 20px;
  background: var(--cyber-gradient-primary);
  border: none;
  border-radius: 18px;
  color: white;
  font-family: 'Orbitron', monospace;
  font-weight: 700;
  font-size: 1.1rem;
  text-transform: uppercase;
  letter-spacing: 2px;
  cursor: pointer;
  transition: all 0.4s ease;
  position: relative;
  overflow: hidden;
  box-shadow:
    0 10px 30px rgba(0, 234, 255, 0.3),
    0 0 20px rgba(0, 234, 255, 0.2);
}

.login-btn-enhanced:hover:not(.loading) {
  transform: translateY(-3px) scale(1.02);
  box-shadow:
    0 15px 40px rgba(0, 234, 255, 0.4),
    0 0 30px rgba(0, 234, 255, 0.3);
}

.login-btn-enhanced:active {
  transform: translateY(-1px) scale(1.01);
}

.login-btn-enhanced.loading {
  opacity: 0.8;
  cursor: not-allowed;
}

.btn-content {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1rem;
  position: relative;
  z-index: 2;
}

.btn-progress {
  position: absolute;
  bottom: 0;
  left: 0;
  height: 3px;
  background: var(--cyber-gradient-accent);
  animation: progressBar 2s ease-in-out infinite;
  border-radius: 0 0 18px 18px;
}

.btn-glow {
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
  transition: left 0.6s ease;
}

.login-btn-enhanced:hover .btn-glow {
  left: 100%;
}

.rotating {
  animation: rotate 1s linear infinite;
}

/* 表单底部 */
.form-footer {
  margin-top: 2.5rem;
  position: relative;
  z-index: 2;
}

.divider {
  position: relative;
  text-align: center;
  margin: 2rem 0;
}

.divider::before {
  content: '';
  position: absolute;
  top: 50%;
  left: 0;
  right: 0;
  height: 1px;
  background: linear-gradient(90deg, transparent, rgba(0, 234, 255, 0.3), transparent);
}

.divider-text {
  background: var(--cyber-bg-primary);
  padding: 0 1rem;
  color: var(--cyber-text-muted);
  font-size: 0.9rem;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.register-section {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1rem;
  flex-wrap: wrap;
}

.register-text {
  color: var(--cyber-text-secondary);
  font-size: 0.9rem;
}

.register-link {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 10px 18px;
  background: rgba(0, 234, 255, 0.1);
  border: 1px solid rgba(0, 234, 255, 0.3);
  border-radius: 20px;
  color: var(--cyber-primary);
  text-decoration: none;
  font-size: 0.9rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 1px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.register-link:hover {
  background: rgba(0, 234, 255, 0.2);
  border-color: var(--cyber-primary);
  transform: translateY(-2px);
  box-shadow: 0 5px 15px rgba(0, 234, 255, 0.3);
}

/* 错误面板 */
.error-panel {
  margin-top: 1.5rem;
  padding: 1rem;
  background: rgba(255, 77, 79, 0.1);
  border: 1px solid var(--cyber-danger);
  border-radius: 15px;
  animation: slideIn 0.3s ease;
  position: relative;
  z-index: 2;
}

.error-content {
  display: flex;
  align-items: center;
  gap: 0.8rem;
  color: var(--cyber-danger);
  font-weight: 600;
}

.error-content i {
  font-size: 1.2rem;
}

/* 响应式设计 */
@media (max-width: 1200px) {
  .main-content {
    grid-template-columns: 1fr;
    gap: 3rem;
    padding: 2rem;
  }

  .info-section {
    text-align: center;
    gap: 2rem;
  }

  .brand-title {
    font-size: 2.8rem;
  }

  .feature-highlights {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1.5rem;
  }

  .feature-item:hover {
    transform: translateY(-5px);
  }
}

@media (max-width: 768px) {
  .main-content {
    padding: 1rem;
    gap: 2rem;
  }

  .login-panel {
    padding: 2rem;
  }

  .brand-title {
    font-size: 2.2rem;
    letter-spacing: 2px;
  }

  .brand-subtitle {
    font-size: 1.1rem;
  }

  .login-title {
    font-size: 1.8rem;
  }

  .feature-highlights {
    grid-template-columns: 1fr;
  }

  .security-status {
    flex-direction: column;
    gap: 1rem;
    text-align: center;
  }
}

@media (max-width: 480px) {
  .login-panel {
    padding: 1.5rem;
    border-radius: 20px;
  }

  .brand-title {
    font-size: 1.8rem;
  }

  .login-title {
    font-size: 1.5rem;
  }

  .cyber-input :deep(.el-input__wrapper) {
    padding: 15px 20px 15px 50px;
    min-height: 55px;
  }

  .login-btn-enhanced {
    padding: 18px;
  }

  .feature-item {
    padding: 1rem;
  }

  .feature-icon {
    font-size: 2rem;
  }
}

/* 动画关键帧 */
@keyframes particleFloat {
  0% { transform: translateY(0px) translateX(0px); }
  33% { transform: translateY(-10px) translateX(5px); }
  66% { transform: translateY(5px) translateX(-5px); }
  100% { transform: translateY(0px) translateX(0px); }
}

@keyframes gridMove {
  0% { transform: translate(0, 0); }
  100% { transform: translate(60px, 60px); }
}

@keyframes scanMove {
  0% { transform: translateY(-100%); }
  100% { transform: translateY(100vh); }
}

@keyframes shimmer {
  0% { transform: translateX(-100%); }
  100% { transform: translateX(100%); }
}

@keyframes breathe {
  0%, 100% {
    opacity: 0.8;
    transform: scale(1);
  }
  50% {
    opacity: 1;
    transform: scale(1.05);
  }
}

@keyframes rotate {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

@keyframes progressBar {
  0% { width: 0%; }
  50% { width: 70%; }
  100% { width: 100%; }
}

@keyframes slideIn {
  from {
    opacity: 0;
    transform: translateY(-10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
</style>
