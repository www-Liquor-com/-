<template>
  <div class="deepfake-bg">
    <!-- 页面标题区域 -->
    <div class="page-header">
      <div class="header-decoration">
        <div class="deco-line"></div>
        <div class="header-icon">
          <i class="ri-sword-line"></i>
        </div>
        <div class="deco-line"></div>
      </div>
      <h1 class="page-title">
        <span class="title-main">DEEPFAKE SIMULATION</span>
        <span class="title-sub">伪造模拟系统</span>
      </h1>
      <div class="security-badge">SIMULATION MODE</div>
    </div>

    <!-- 主要操作区域 -->
    <div class="main-workspace">
      <!-- 模式选择区域 -->
      <div class="mode-workspace cyber-glass-card">
        <div class="workspace-header">
          <h3 class="workspace-title">
            <i class="ri-settings-3-line"></i>
            模拟模式选择
          </h3>
          <div class="status-indicator">
            <div class="status-dot active"></div>
            <span>系统就绪</span>
          </div>
        </div>

        <div class="mode-content">

<!--          &lt;!&ndash; 安全警告 &ndash;&gt;-->
<!--          <div class="security-warning">-->
<!--            <div class="warning-icon">-->
<!--              <i class="ri-error-warning-line"></i>-->
<!--            </div>-->
<!--            <div class="warning-content">-->
<!--              <h4 class="warning-title">安全提醒</h4>-->
<!--              <p class="warning-text">本模块仅用于学术研究与安全测试，严禁用于任何非法用途！</p>-->
<!--            </div>-->
<!--            <div class="warning-scan-line"></div>-->
<!--          </div>-->
          <div class="mode-selector">
            <div
              class="mode-option"
              :class="{ active: activeTab === 'face' }"
              @click="selectTab('face')"
            >
              <div class="mode-icon">
                <i class="ri-user-shared-line"></i>
              </div>
              <div class="mode-text">
                <h4>身份替换</h4>
                <p>深度学习身份交换技术</p>
              </div>
              <div class="mode-indicator"></div>
            </div>

            <div
              class="mode-option"
              :class="{ active: activeTab === 'inpaint' }"
              @click="selectTab('inpaint')"
            >
              <div class="mode-icon">
                <i class="ri-edit-2-line"></i>
              </div>
              <div class="mode-text">
                <h4>局部编辑</h4>
                <p>智能图像修复与编辑</p>
              </div>
              <div class="mode-indicator"></div>
            </div>
          </div>

          <!-- 安全警告 -->
          <div class="security-warning">
            <div class="warning-icon">
              <i class="ri-error-warning-line"></i>
            </div>
            <div class="warning-content">
              <h4 class="warning-title">安全提醒</h4>
              <p class="warning-text">本模块仅用于学术研究与安全测试，严禁用于任何非法用途！</p>
            </div>
            <div class="warning-scan-line"></div>
          </div>
        </div>
      </div>

      <!-- 功能模块区域 -->
      <div class="module-workspace cyber-glass-card">
        <div class="workspace-header">
          <h3 class="workspace-title">
            <i class="ri-cpu-line"></i>
            {{ activeTab === 'face' ? '身份替换模块' : '局部编辑模块' }}
          </h3>
          <div class="status-indicator">
            <div class="status-dot" :class="{ active: activeTab }"></div>
            <span>{{ activeTab === 'face' ? '身份交换' : '图像修复' }}</span>
          </div>
        </div>

        <div class="module-container">
          <div v-show="activeTab === 'face'" class="module-content">
            <IdentitySwapView />
          </div>
          <div v-show="activeTab === 'inpaint'" class="module-content">
            <InpaintEditView />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import IdentitySwapView from './IdentitySwapView.vue'
import InpaintEditView from './InpaintEditView.vue'
const activeTab = ref('face')
const dropdownOpen = ref(false)
function selectTab(tab) {
  activeTab.value = tab
  dropdownOpen.value = false
}
</script>

<style scoped>
@import '@/assets/enhanced-cyber-theme.css';
@import './deepfake-common.css';

.deepfake-bg {
  min-height: 80vh;
  padding: 0;
  background: transparent;
  display: flex;
  flex-direction: column;
  gap: 3rem;
}

/* 页面标题区域 */
.page-header {
  text-align: center;
  padding: 2rem 0;
  position: relative;
}

.header-decoration {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 2rem;
  margin-bottom: 2rem;
}

.deco-line {
  flex: 1;
  max-width: 150px;
  height: 2px;
  background: var(--cyber-gradient-primary);
  border-radius: 1px;
}

.header-icon {
  font-size: 3rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  animation: breathe 3s ease-in-out infinite;
}

.page-title {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 1.5rem;
}

.title-main {
  font-size: 2.8rem;
  font-weight: 900;
  text-transform: uppercase;
  letter-spacing: 3px;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  font-family: 'Orbitron', monospace;
}

.title-sub {
  font-size: 1.2rem;
  color: var(--cyber-text-secondary);
  letter-spacing: 2px;
  font-weight: 600;
}

.security-badge {
  background: var(--cyber-gradient-accent);
  color: white;
  padding: 8px 20px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 2px;
  box-shadow: 0 0 20px rgba(255, 0, 110, 0.4);
  animation: breathe 4s ease-in-out infinite;
}

/* 主工作区域 */
.main-workspace {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 3rem;
  margin-bottom: 3rem;
}

/* 玻璃卡片样式 */
.cyber-glass-card {
  background: var(--cyber-gradient-glass);
  backdrop-filter: blur(20px);
  border: 2px solid rgba(0, 234, 255, 0.3);
  border-radius: 25px;
  padding: 2.5rem;
  box-shadow:
    0 20px 60px rgba(0, 0, 0, 0.4),
    0 0 40px rgba(0, 234, 255, 0.2);
  position: relative;
  overflow: hidden;
}

.cyber-glass-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 3px;
  background: var(--cyber-gradient-primary);
}

.workspace-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid rgba(0, 234, 255, 0.2);
}

.workspace-title {
  display: flex;
  align-items: center;
  gap: 1rem;
  font-size: 1.3rem;
  color: var(--cyber-text-primary);
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.workspace-title i {
  font-size: 1.5rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
}

.status-indicator {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.9rem;
  color: var(--cyber-text-secondary);
  text-transform: uppercase;
  letter-spacing: 1px;
  font-weight: 600;
}

.status-dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: var(--cyber-text-muted);
  transition: all 0.3s ease;
}

.status-dot.active {
  background: var(--cyber-success);
  box-shadow: 0 0 15px var(--cyber-success);
  animation: breathe 2s ease-in-out infinite;
}

/* 模式选择区域 */
.mode-content {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

.mode-selector {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

.mode-option {
  display: flex;
  align-items: center;
  gap: 1.5rem;
  padding: 1.5rem;
  background: rgba(30, 40, 80, 0.6);
  border: 2px solid rgba(0, 234, 255, 0.2);
  border-radius: 15px;
  cursor: pointer;
  transition: all 0.4s ease;
  position: relative;
  overflow: hidden;
}

.mode-option:hover {
  border-color: rgba(0, 234, 255, 0.4);
  transform: translateX(5px);
  box-shadow: 0 5px 20px rgba(0, 234, 255, 0.2);
}

.mode-option.active {
  border-color: var(--cyber-primary);
  background: rgba(0, 234, 255, 0.1);
  box-shadow: 0 0 20px rgba(0, 234, 255, 0.3);
}

.mode-option.active::after {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(0, 234, 255, 0.1), transparent);
  animation: scanLine 2s ease-in-out;
}

.mode-icon {
  font-size: 2.5rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  min-width: 60px;
  display: flex;
  justify-content: center;
}

.mode-text {
  flex: 1;
}

.mode-text h4 {
  font-size: 1.2rem;
  color: var(--cyber-text-primary);
  margin-bottom: 0.3rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.mode-text p {
  color: var(--cyber-text-secondary);
  font-size: 0.9rem;
  margin: 0;
  line-height: 1.4;
}

.mode-indicator {
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: var(--cyber-text-muted);
  transition: all 0.3s ease;
  min-width: 12px;
}

.mode-option.active .mode-indicator {
  background: var(--cyber-primary);
  box-shadow: 0 0 15px var(--cyber-primary);
}

/* 安全警告区域 */
.security-warning {
  display: flex;
  align-items: center;
  gap: 1.5rem;
  padding: 1.5rem;
  background: rgba(255, 77, 79, 0.1);
  border: 2px solid var(--cyber-danger);
  border-radius: 15px;
  position: relative;
  overflow: hidden;
  animation: warningPulse 3s ease-in-out infinite;
}

.security-warning::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 2px;
  background: linear-gradient(90deg, var(--cyber-danger), rgba(255, 0, 110, 0.8));
}

.warning-icon {
  font-size: 2rem;
  color: var(--cyber-danger);
  text-shadow: 0 0 15px var(--cyber-danger);
  min-width: 40px;
  display: flex;
  justify-content: center;
}

.warning-content {
  flex: 1;
}

.warning-title {
  font-size: 1rem;
  color: var(--cyber-danger);
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
  margin: 0 0 0.3rem 0;
}

.warning-text {
  color: var(--cyber-text-primary);
  font-size: 0.85rem;
  margin: 0;
  line-height: 1.4;
}

.warning-scan-line {
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255, 77, 79, 0.2), transparent);
  animation: scanLine 4s ease-in-out infinite;
}

@keyframes warningPulse {
  0%, 100% {
    box-shadow: 0 0 15px rgba(255, 77, 79, 0.3);
  }
  50% {
    box-shadow: 0 0 25px rgba(255, 77, 79, 0.5), 0 0 35px rgba(255, 77, 79, 0.2);
  }
}

/* 功能模块区域 */
.module-container {
  position: relative;
  min-height: 400px;
}

.module-content {
  position: relative;
  width: 100%;
  height: 100%;
}

/* 响应式设计 */
@media (max-width: 1200px) {
  .main-workspace {
    grid-template-columns: 1fr;
    gap: 2rem;
  }
}

@media (max-width: 768px) {
  .deepfake-bg {
    gap: 2rem;
  }

  .page-header {
    padding: 1.5rem 0;
  }

  .title-main {
    font-size: 2.2rem;
    letter-spacing: 2px;
  }

  .title-sub {
    font-size: 1rem;
  }

  .cyber-glass-card {
    padding: 2rem;
  }

  .workspace-header {
    flex-direction: column;
    gap: 1rem;
    text-align: center;
  }

  .mode-content {
    gap: 1.5rem;
  }

  .mode-selector {
    gap: 1rem;
  }

  .mode-option {
    flex-direction: column;
    text-align: center;
    gap: 1rem;
    padding: 1.5rem;
  }

  .mode-option:hover {
    transform: translateY(-3px);
  }

  .security-warning {
    flex-direction: column;
    text-align: center;
    gap: 1rem;
    padding: 1.2rem;
  }

  .module-container {
    min-height: 300px;
  }
}

@media (max-width: 480px) {
  .title-main {
    font-size: 1.8rem;
  }

  .cyber-glass-card {
    padding: 1.5rem;
  }

  .mode-icon {
    font-size: 2rem;
  }

  .mode-text h4 {
    font-size: 1rem;
  }

  .mode-text p {
    font-size: 0.8rem;
  }

  .warning-icon {
    font-size: 1.5rem;
  }

  .warning-title {
    font-size: 0.9rem;
  }

  .warning-text {
    font-size: 0.75rem;
  }

  .module-container {
    min-height: 250px;
  }
}

/* 动画关键帧 */
@keyframes breathe {
  0%, 100% {
    opacity: 0.8;
    transform: scale(1);
  }
  50% {
    opacity: 1;
    transform: scale(1.05);
  }
}

@keyframes scanLine {
  0% {
    left: -100%;
    opacity: 0;
  }
  50% {
    opacity: 1;
  }
  100% {
    left: 100%;
    opacity: 0;
  }
}
</style>
