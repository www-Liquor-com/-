<template>
  <div class="dashboard-bg">
    <!-- 主标题区域 -->
    <div class="title-section">
      <div class="title-decoration">
        <div class="title-line"></div>
        <div class="title-icon">
          <i class="ri-shield-check-line cyber-rotate"></i>
        </div>
        <div class="title-line"></div>
      </div>
      <h1 class="dashboard-title cyber-glow-text">
        <span class="title-main">FORENSIC CONTROL CENTER</span>
        <span class="title-sub">取证平台控制中心</span>
      </h1>
      <div class="security-badge-enhanced">SECURE</div>
    </div>

    <!-- 系统状态监控 -->
    <div class="system-monitor">
      <div class="monitor-card cyber-glass-card">
        <div class="monitor-header">
          <i class="ri-cpu-line"></i>
          <span>系统状态</span>
        </div>
        <div class="monitor-grid">
          <div class="monitor-item">
            <div class="monitor-value cyber-glow-text">98%</div>
            <div class="monitor-label">系统健康度</div>
            <div class="monitor-bar">
              <div class="bar-fill" style="width: 98%"></div>
            </div>
          </div>
          <div class="monitor-item">
            <div class="monitor-value cyber-glow-text">24/7</div>
            <div class="monitor-label">运行时间</div>
            <div class="monitor-bar">
              <div class="bar-fill" style="width: 100%"></div>
            </div>
          </div>
          <div class="monitor-item">
            <div class="monitor-value cyber-glow-text">256</div>
            <div class="monitor-label">加密强度</div>
            <div class="monitor-bar">
              <div class="bar-fill" style="width: 100%"></div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 数据统计面板 -->
    <div class="dashboard-stats">
      <div class="stat-card-enhanced cyber-float">
        <div class="stat-icon">
          <i class="ri-database-2-line"></i>
        </div>
        <div class="stat-content">
          <div class="stat-value cyber-glow-text">{{ stats.total ?? '--' }}</div>
          <div class="stat-label">总操作数</div>
          <div class="stat-trend">
            <i class="ri-arrow-up-line"></i>
            <span>+12%</span>
          </div>
        </div>
        <div class="stat-progress">
          <div class="progress-ring">
            <svg viewBox="0 0 36 36">
              <path class="circle-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"/>
              <path class="circle" stroke-dasharray="85, 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"/>
            </svg>
          </div>
        </div>
      </div>

      <div class="stat-card-enhanced cyber-float">
        <div class="stat-icon">
          <i class="ri-shield-star-line"></i>
        </div>
        <div class="stat-content">
          <div class="stat-value cyber-glow-text">{{ stats.embed ?? '--' }}</div>
          <div class="stat-label">水印嵌入次数</div>
          <div class="stat-trend">
            <i class="ri-arrow-up-line"></i>
            <span>+8%</span>
          </div>
        </div>
        <div class="stat-progress">
          <div class="progress-ring">
            <svg viewBox="0 0 36 36">
              <path class="circle-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"/>
              <path class="circle" stroke-dasharray="72, 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"/>
            </svg>
          </div>
        </div>
      </div>

      <div class="stat-card-enhanced cyber-float">
        <div class="stat-icon">
          <i class="ri-search-eye-line"></i>
        </div>
        <div class="stat-content">
          <div class="stat-value cyber-glow-text">{{ stats.extract ?? '--' }}</div>
          <div class="stat-label">水印提取次数</div>
          <div class="stat-trend">
            <i class="ri-arrow-up-line"></i>
            <span>+15%</span>
          </div>
        </div>
        <div class="stat-progress">
          <div class="progress-ring">
            <svg viewBox="0 0 36 36">
              <path class="circle-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"/>
              <path class="circle" stroke-dasharray="63, 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"/>
            </svg>
          </div>
        </div>
      </div>
    </div>

    <!-- 功能模块面板 -->
    <div class="dashboard-actions">
      <div class="action-card-enhanced" @click="go('/dashboard/embed')">
        <div class="card-header">
          <div class="action-icon-enhanced">
            <i class="ri-shield-star-line"></i>
            <div class="icon-glow"></div>
          </div>
          <div class="card-badge">EMBED</div>
        </div>
        <div class="card-content">
          <h3 class="card-title">水印嵌入系统</h3>
          <p class="card-desc">将不可见水印嵌入到人脸图像中，提供身份保护和篡改检测能力。支持多种水印算法和强度调节。</p>
          <div class="card-features">
            <span class="feature-tag">身份保护</span>
            <span class="feature-tag">不可见水印</span>
            <span class="feature-tag">高鲁棒性</span>
          </div>
        </div>
        <div class="card-footer">
          <div class="action-btn-enhanced">
            <span>启动嵌入</span>
            <i class="ri-arrow-right-line"></i>
          </div>
        </div>
        <div class="card-scan-line"></div>
      </div>

      <div class="action-card-enhanced" @click="go('/dashboard/forge')">
        <div class="card-header">
          <div class="action-icon-enhanced">
            <i class="ri-sword-line"></i>
            <div class="icon-glow"></div>
          </div>
          <div class="card-badge">FORGE</div>
        </div>
        <div class="card-content">
          <h3 class="card-title">伪造模拟系统</h3>
          <p class="card-desc">使用深度学习技术模拟人脸伪造攻击，测试水印系统的鲁棒性和检测能力。</p>
          <div class="card-features">
            <span class="feature-tag">深度伪造</span>
            <span class="feature-tag">攻击模拟</span>
            <span class="feature-tag">鲁棒性测试</span>
          </div>
        </div>
        <div class="card-footer">
          <div class="action-btn-enhanced">
            <span>开始模拟</span>
            <i class="ri-arrow-right-line"></i>
          </div>
        </div>
        <div class="card-scan-line"></div>
      </div>

      <div class="action-card-enhanced" @click="go('/dashboard/tamper')">
        <div class="card-header">
          <div class="action-icon-enhanced">
            <i class="ri-focus-3-line"></i>
            <div class="icon-glow"></div>
          </div>
          <div class="card-badge">DETECT</div>
        </div>
        <div class="card-content">
          <h3 class="card-title">篡改定位系统</h3>
          <p class="card-desc">精确检测和定位图像中的篡改区域，提供像素级的篡改检测和可视化分析。</p>
          <div class="card-features">
            <span class="feature-tag">精确定位</span>
            <span class="feature-tag">像素级检测</span>
            <span class="feature-tag">可视化分析</span>
          </div>
        </div>
        <div class="card-footer">
          <div class="action-btn-enhanced">
            <span>开始检测</span>
            <i class="ri-arrow-right-line"></i>
          </div>
        </div>
        <div class="card-scan-line"></div>
      </div>

      <div class="action-card-enhanced" @click="go('/dashboard/recover')">
        <div class="card-header">
          <div class="action-icon-enhanced">
            <i class="ri-user-search-line"></i>
            <div class="icon-glow"></div>
          </div>
          <div class="card-badge">RECOVER</div>
        </div>
        <div class="card-content">
          <h3 class="card-title">身份恢复系统</h3>
          <p class="card-desc">从被篡改的图像中恢复原始身份信息，重建真实的人脸特征和身份数据。</p>
          <div class="card-features">
            <span class="feature-tag">身份重建</span>
            <span class="feature-tag">特征恢复</span>
            <span class="feature-tag">数据修复</span>
          </div>
        </div>
        <div class="card-footer">
          <div class="action-btn-enhanced">
            <span>启动恢复</span>
            <i class="ri-arrow-right-line"></i>
          </div>
        </div>
        <div class="card-scan-line"></div>
      </div>

      <div class="action-card-enhanced coming-soon">
<!--      <div class="action-card-enhanced">-->
        <div class="card-header">
          <div class="action-icon-enhanced">
            <i class="ri-search-2-line"></i>
            <div class="icon-glow"></div>
          </div>
          <div class="card-badge">EXPLORE</div>
        </div>
        <div class="card-content">
          <h3 class="card-title">更多功能</h3>
          <p class="card-desc">更多强大的取证分析功能正在开发中，包括高级算法、智能分析和扩展工具等。</p>
          <div class="card-features">
            <span class="feature-tag">敬请期待</span>
            <span class="feature-tag">持续更新</span>
            <span class="feature-tag">功能扩展</span>
          </div>
        </div>
        <div class="card-footer">
<!--          <div class="action-btn-enhanced">-->
          <div class="action-btn-enhanced coming-soon-btn">
            <span>敬请期待</span>
            <i class="ri-time-line"></i>
          </div>
        </div>
        <div class="card-scan-line"></div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { getWatermarkStats } from '../api/watermark'
import { ElMessage } from 'element-plus'

const stats = ref({ total: 0, embed: 0, extract: 0 })
const router = useRouter()
const route = useRoute()

function go(path) {
  router.push(path)
}

onMounted(async () => {
  const token = localStorage.getItem('token')
  if (!token) {
    ElMessage.error('未登录，请重新登录')
    router.push('/login')
    return
  }
  const { status, data } = await getWatermarkStats()
  if (status === 200) {
    stats.value = data
  } else {
    ElMessage.error(data.detail || '获取统计信息失败，请重新登录')
  }
})
</script>

<style scoped>
@import '@/assets/enhanced-cyber-theme.css';

.dashboard-bg {
  min-height: 80vh;
  padding: 0;
  background: transparent;
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 3rem;
}

/* 标题区域 */
.title-section {
  text-align: center;
  position: relative;
  padding: 2rem 0;
}

.title-decoration {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 2rem;
  margin-bottom: 2rem;
}

.title-line {
  flex: 1;
  max-width: 200px;
  height: 2px;
  background: var(--cyber-gradient-primary);
  border-radius: 1px;
  opacity: 0.8;
}

.title-icon {
  font-size: 3rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
}

.dashboard-title {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
  position: relative;
}

.title-main {
  font-size: 3.2rem;
  font-weight: 900;
  text-transform: uppercase;
  letter-spacing: 4px;
  color: var(--cyber-primary);
  text-shadow:
    0 0 20px var(--cyber-primary),
    0 0 40px var(--cyber-secondary);
  font-family: 'Orbitron', monospace;
  animation: hologramGlow 4s ease-in-out infinite;
}

.title-sub {
  font-size: 1.4rem;
  color: var(--cyber-text-secondary);
  letter-spacing: 2px;
  font-weight: 600;
  opacity: 0.9;
}

.security-badge-enhanced {
  position: absolute;
  top: -20px;
  right: 20%;
  background: var(--cyber-gradient-accent);
  color: white;
  padding: 12px 20px;
  border-radius: 25px;
  font-size: 14px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 2px;
  z-index: 10;
  box-shadow:
    var(--cyber-shadow-glow),
    0 0 25px rgba(255, 0, 110, 0.4);
  animation: breathe 3s ease-in-out infinite;
}

/* 系统监控面板 */
.system-monitor {
  margin-bottom: 2rem;
}

.monitor-card {
  padding: 2rem;
  border-radius: 20px;
  background: var(--cyber-gradient-glass);
  backdrop-filter: blur(20px);
  border: 2px solid rgba(0, 234, 255, 0.3);
  box-shadow: var(--cyber-shadow-strong);
}

.monitor-header {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 2rem;
  font-size: 1.2rem;
  font-weight: 700;
  color: var(--cyber-text-accent);
  text-transform: uppercase;
  letter-spacing: 1px;
}

.monitor-header i {
  font-size: 1.5rem;
  text-shadow: var(--cyber-glow-primary);
}

.monitor-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 2rem;
}

.monitor-item {
  text-align: center;
}

.monitor-value {
  font-size: 2.5rem;
  font-weight: 900;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  margin-bottom: 0.5rem;
  font-family: 'Orbitron', monospace;
}

.monitor-label {
  font-size: 0.9rem;
  color: var(--cyber-text-secondary);
  text-transform: uppercase;
  letter-spacing: 1px;
  margin-bottom: 1rem;
}

.monitor-bar {
  width: 100%;
  height: 6px;
  background: rgba(30, 40, 80, 0.8);
  border-radius: 10px;
  overflow: hidden;
  position: relative;
}

.bar-fill {
  height: 100%;
  background: var(--cyber-gradient-primary);
  border-radius: 10px;
  position: relative;
  transition: width 1s ease;
  box-shadow: 0 0 15px rgba(0, 234, 255, 0.5);
}

.bar-fill::after {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
  animation: scanLine 2s ease-in-out infinite;
}

/* 统计卡片增强版 */
.dashboard-stats {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
  gap: 2rem;
  margin-bottom: 3rem;
}

.stat-card-enhanced {
  background: var(--cyber-gradient-card);
  border-radius: 25px;
  padding: 2.5rem;
  border: 2px solid rgba(0, 234, 255, 0.3);
  box-shadow:
    var(--cyber-shadow-strong),
    0 0 40px rgba(0, 234, 255, 0.2);
  position: relative;
  overflow: hidden;
  transition: all 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  backdrop-filter: blur(20px);
  display: flex;
  align-items: center;
  gap: 2rem;
}

.stat-card-enhanced::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 3px;
  background: var(--cyber-gradient-primary);
}

.stat-card-enhanced::after {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent);
  animation: scanLine 4s ease-in-out infinite;
}

.stat-card-enhanced:hover {
  transform: translateY(-10px) scale(1.02);
  box-shadow:
    0 25px 60px rgba(0, 0, 0, 0.4),
    0 0 60px rgba(0, 234, 255, 0.4);
  border-color: var(--cyber-primary);
}

.stat-icon {
  font-size: 3rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  min-width: 80px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.stat-content {
  flex: 1;
}

.stat-value {
  font-size: 3.5rem;
  font-weight: 900;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
  margin-bottom: 0.5rem;
  font-family: 'Orbitron', monospace;
  letter-spacing: 2px;
}

.stat-label {
  font-size: 1rem;
  color: var(--cyber-text-secondary);
  text-transform: uppercase;
  letter-spacing: 1px;
  font-weight: 600;
  margin-bottom: 0.5rem;
}

.stat-trend {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  color: var(--cyber-success);
  font-size: 0.9rem;
  font-weight: 600;
}

.stat-progress {
  min-width: 80px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.progress-ring {
  width: 60px;
  height: 60px;
}

.progress-ring svg {
  width: 100%;
  height: 100%;
  transform: rotate(-90deg);
}

.circle-bg {
  fill: none;
  stroke: rgba(30, 40, 80, 0.8);
  stroke-width: 3;
}

.circle {
  fill: none;
  stroke: var(--cyber-primary);
  stroke-width: 3;
  stroke-linecap: round;
  filter: drop-shadow(0 0 8px var(--cyber-primary));
  animation: drawCircle 2s ease-in-out;
}

@keyframes drawCircle {
  from { stroke-dasharray: 0, 100; }
}

/* 功能卡片增强版 */
.dashboard-actions {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: 2.5rem;
}

.action-card-enhanced {
  background: var(--cyber-gradient-card);
  border-radius: 25px;
  padding: 0;
  border: 2px solid rgba(0, 234, 255, 0.3);
  box-shadow:
    var(--cyber-shadow-strong),
    0 0 40px rgba(0, 234, 255, 0.2);
  position: relative;
  overflow: hidden;
  transition: all 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  cursor: pointer;
  backdrop-filter: blur(20px);
  min-height: 320px;
  display: flex;
  flex-direction: column;
}

.action-card-enhanced::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 3px;
  background: var(--cyber-gradient-primary);
  z-index: 2;
}

.action-card-enhanced:hover {
  transform: translateY(-15px) scale(1.03);
  box-shadow:
    0 30px 80px rgba(0, 0, 0, 0.5),
    0 0 80px rgba(0, 234, 255, 0.5);
  border-color: var(--cyber-primary);
}

.action-card-enhanced:hover .card-scan-line {
  animation: scanLine 0.8s ease-in-out;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 2rem 2rem 1rem 2rem;
}

.action-icon-enhanced {
  position: relative;
  font-size: 3.5rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
}

.icon-glow {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 80px;
  height: 80px;
  background: radial-gradient(circle, rgba(0, 234, 255, 0.2) 0%, transparent 70%);
  border-radius: 50%;
  animation: breathe 3s ease-in-out infinite;
}

.card-badge {
  background: var(--cyber-gradient-accent);
  color: white;
  padding: 8px 16px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
  box-shadow: 0 0 15px rgba(255, 0, 110, 0.4);
}

.card-content {
  padding: 0 2rem 1rem 2rem;
  flex: 1;
}

.card-title {
  font-size: 1.5rem;
  color: var(--cyber-text-primary);
  font-weight: 700;
  margin-bottom: 1rem;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.card-desc {
  color: var(--cyber-text-secondary);
  line-height: 1.6;
  margin-bottom: 1.5rem;
  font-size: 0.95rem;
}

.card-features {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
}

.feature-tag {
  background: rgba(0, 234, 255, 0.1);
  color: var(--cyber-primary);
  padding: 4px 12px;
  border-radius: 15px;
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 1px;
  font-weight: 600;
  border: 1px solid rgba(0, 234, 255, 0.3);
}

.card-footer {
  padding: 1rem 2rem 2rem 2rem;
}

.action-btn-enhanced {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  padding: 15px 20px;
  background: var(--cyber-gradient-primary);
  border: none;
  border-radius: 15px;
  color: white;
  font-family: 'Orbitron', monospace;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow:
    0 8px 25px rgba(0, 234, 255, 0.3),
    inset 0 1px 0 rgba(255, 255, 255, 0.2);
}

.action-btn-enhanced:hover {
  transform: translateY(-2px);
  box-shadow:
    0 12px 30px rgba(0, 234, 255, 0.4),
    0 0 25px rgba(0, 234, 255, 0.3);
}

.card-scan-line {
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent);
  z-index: 1;
}

/* 敬请期待卡片样式 */
.action-card-enhanced.coming-soon {
  opacity: 0.8;
  cursor: default;
}

.action-card-enhanced.coming-soon:hover {
  transform: translateY(-5px) scale(1.01);
  box-shadow:
    0 15px 40px rgba(0, 0, 0, 0.3),
    0 0 40px rgba(255, 165, 0, 0.3);
  border-color: rgba(255, 165, 0, 0.5);
}

.action-card-enhanced.coming-soon .action-icon-enhanced {
  color: rgba(255, 165, 0, 0.9);
  text-shadow: 0 0 20px rgba(255, 165, 0, 0.5);
}

.action-card-enhanced.coming-soon .icon-glow {
  background: radial-gradient(circle, rgba(255, 165, 0, 0.2) 0%, transparent 70%);
}

.action-card-enhanced.coming-soon .card-badge {
  background: linear-gradient(135deg, rgba(255, 165, 0, 0.8), rgba(255, 140, 0, 0.9));
  box-shadow: 0 0 15px rgba(255, 165, 0, 0.4);
}

.coming-soon-btn {
  background: linear-gradient(135deg, rgba(255, 165, 0, 0.6), rgba(255, 140, 0, 0.7)) !important;
  cursor: default !important;
  box-shadow:
    0 8px 25px rgba(255, 165, 0, 0.2),
    inset 0 1px 0 rgba(255, 255, 255, 0.2) !important;
}

.coming-soon-btn:hover {
  transform: none !important;
  box-shadow:
    0 8px 25px rgba(255, 165, 0, 0.3),
    inset 0 1px 0 rgba(255, 255, 255, 0.2) !important;
}

.action-card-enhanced.coming-soon .feature-tag {
  background: rgba(255, 165, 0, 0.1);
  color: rgba(255, 165, 0, 0.9);
  border: 1px solid rgba(255, 165, 0, 0.3);
}

/* 响应式设计 */
@media (max-width: 1200px) {
  .dashboard-stats {
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  }

  .dashboard-actions {
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  }
}

@media (max-width: 768px) {
  .dashboard-bg {
    gap: 2rem;
  }

  .title-section {
    padding: 1.5rem 0;
  }

  .title-main {
    font-size: 2.5rem;
    letter-spacing: 2px;
  }

  .title-sub {
    font-size: 1.2rem;
  }

  .security-badge-enhanced {
    position: static;
    margin-top: 1rem;
    display: inline-block;
  }

  .monitor-card {
    padding: 1.5rem;
  }

  .monitor-grid {
    grid-template-columns: 1fr;
    gap: 1.5rem;
  }

  .dashboard-stats {
    grid-template-columns: 1fr;
    gap: 1.5rem;
  }

  .dashboard-actions {
    grid-template-columns: 1fr;
    gap: 2rem;
  }

  .stat-card-enhanced {
    padding: 2rem;
    flex-direction: column;
    text-align: center;
    gap: 1.5rem;
  }

  .stat-value {
    font-size: 3rem;
  }

  .action-card-enhanced {
    min-height: 280px;
  }

  .card-header {
    padding: 1.5rem 1.5rem 1rem 1.5rem;
  }

  .card-content {
    padding: 0 1.5rem 1rem 1.5rem;
  }

  .card-footer {
    padding: 1rem 1.5rem 1.5rem 1.5rem;
  }
}

@media (max-width: 480px) {
  .title-main {
    font-size: 2rem;
    letter-spacing: 1px;
  }

  .title-sub {
    font-size: 1rem;
  }

  .stat-value {
    font-size: 2.5rem;
  }

  .action-icon-enhanced {
    font-size: 3rem;
  }

  .card-title {
    font-size: 1.3rem;
  }
}

/* 动画关键帧 */
@keyframes hologramGlow {
  0%, 100% {
    text-shadow:
      0 0 20px var(--cyber-primary),
      0 0 40px var(--cyber-secondary);
  }
  50% {
    text-shadow:
      0 0 30px var(--cyber-primary),
      0 0 60px var(--cyber-secondary),
      0 0 80px var(--cyber-primary);
  }
}

@keyframes breathe {
  0%, 100% {
    opacity: 0.8;
    transform: scale(1);
  }
  50% {
    opacity: 1;
    transform: scale(1.1);
  }
}

@keyframes scanLine {
  0% {
    left: -100%;
    opacity: 0;
  }
  50% {
    opacity: 1;
  }
  100% {
    left: 100%;
    opacity: 0;
  }
}

@keyframes floatUp {
  0%, 100% {
    transform: translateY(0px);
  }
  50% {
    transform: translateY(-8px);
  }
}
</style>
