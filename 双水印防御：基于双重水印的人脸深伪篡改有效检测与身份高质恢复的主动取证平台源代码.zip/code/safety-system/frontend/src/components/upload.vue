<template>
    <div>
      <input type="file" @change="handleUpload" accept="image/*" />
      <button @click="submit">添加水印</button>
      <div v-if="result">
        <h3>处理结果：</h3>
        <img :src="result.watermarked_url" alt="水印图片" />
      </div>
    </div>
  </template>
  
  <script setup>
  import { ref } from 'vue'
  import axios from 'axios'
  
  const file = ref(null)
  const result = ref(null)
  
  const handleUpload = (e) => {
    file.value = e.target.files[0]
  }
  
  const submit = async () => {
    const formData = new FormData()
    formData.append('file', file.value)
    
    try {
      const res = await axios.post('http://localhost:8000/api/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      })
      result.value = res.data
    } catch (error) {
      console.error("上传失败:", error)
    }
  }
  </script>