<template>
  <header class="scifi-header">
    <!-- Logo区域 -->
    <div class="logo-area" @click="$router.push('/')">
      <div class="logo-container">
        <div class="logo-ring">
          <div class="ring-outer"></div>
          <div class="ring-inner"></div>
          <img src="/favicon.ico" alt="logo" class="logo-img" />
        </div>
        <div class="logo-text">
          <span class="logo-title">鉴伪复原</span>
          <span class="logo-subtitle">FORENSIC AI</span>
        </div>
      </div>
      <div class="logo-glow"></div>
    </div>

      <!-- 系统标识 -->
    <div class="system-badge">
      <div class="badge-icon">
        <i class="ri-shield-check-line"></i>
      </div>
      <div class="badge-text">
        <span class="badge-title">FORENSIC AI SYSTEM</span>
        <span class="badge-version">v2.0 SECURE</span>
      </div>
    </div>

    <!-- 系统状态指示器 -->
    <div class="system-indicators">
      <div class="indicator-item">
        <div class="indicator-dot active"></div>
        <span class="indicator-text">ONLINE</span>
      </div>
      <div class="indicator-item">
        <div class="indicator-dot secure"></div>
        <span class="indicator-text">SECURE</span>
      </div>
    </div>

    <!-- 操作按钮 -->
    <div class="header-action">
      <button
        v-if="$route.path !== '/login' && $route.path !== '/register'"
        @click="$router.push('/login')"
        class="header-btn primary">
        <i class="ri-login-circle-line"></i>
        <span>登录系统</span>
        <div class="btn-scan-effect"></div>
      </button>
      <button
        v-else
        @click="$router.push('/')"
        class="header-btn secondary">
        <i class="ri-home-line"></i>
        <span>返回主页</span>
        <div class="btn-scan-effect"></div>
      </button>
    </div>
  </header>
</template>

<script setup>
// 无需props
</script>

<style scoped>
@import '@/assets/enhanced-cyber-theme.css';

.scifi-header {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.5rem 3rem;
  background: rgba(18, 22, 41, 0.95);
  backdrop-filter: blur(20px);
  border-bottom: 1px solid rgba(0, 234, 255, 0.2);
  position: relative;
  z-index: 100;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
}

.scifi-header::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 2px;
  background: var(--cyber-gradient-primary);
}

/* Logo区域 */
.logo-area {
  display: flex;
  align-items: center;
  cursor: pointer;
  position: relative;
  transition: all 0.4s ease;
}

.logo-area:hover {
  transform: scale(1.05);
}

.logo-container {
  display: flex;
  align-items: center;
  gap: 1rem;
  position: relative;
  z-index: 2;
}

.logo-ring {
  position: relative;
  width: 50px;
  height: 50px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.ring-outer {
  position: absolute;
  width: 50px;
  height: 50px;
  border: 2px solid rgba(0, 234, 255, 0.4);
  border-radius: 50%;
  animation: rotateGlow 10s linear infinite;
}

.ring-inner {
  position: absolute;
  width: 35px;
  height: 35px;
  border: 1px solid rgba(0, 80, 255, 0.6);
  border-radius: 50%;
  animation: rotateGlow 8s linear infinite reverse;
}

.logo-img {
  width: 28px;
  height: 28px;
  filter:
    drop-shadow(0 0 10px rgba(0, 234, 255, 0.8))
    drop-shadow(0 0 20px rgba(0, 80, 255, 0.4));
  z-index: 3;
  position: relative;
}

.logo-text {
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
}

.logo-title {
  font-size: 1.6rem;
  font-family: 'Orbitron', monospace;
  color: var(--cyber-primary);
  letter-spacing: 2px;
  text-shadow:
    0 0 15px var(--cyber-primary),
    0 0 30px var(--cyber-secondary);
  font-weight: 700;
  text-transform: uppercase;
  animation: hologramGlow 4s ease-in-out infinite;
}

.logo-subtitle {
  font-size: 0.7rem;
  color: var(--cyber-text-secondary);
  text-transform: uppercase;
  letter-spacing: 3px;
  font-weight: 600;
  opacity: 0.8;
}

.logo-glow {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 120px;
  height: 60px;
  background: radial-gradient(ellipse, rgba(0, 234, 255, 0.1) 0%, transparent 70%);
  border-radius: 50%;
  animation: breathe 4s ease-in-out infinite;
  z-index: 1;
}

/* 系统状态指示器 */
.system-indicators {
  display: flex;
  gap: 2rem;
  align-items: center;
}

.indicator-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.indicator-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  position: relative;
}

.indicator-dot::before {
  content: '';
  position: absolute;
  top: -2px;
  left: -2px;
  right: -2px;
  bottom: -2px;
  border-radius: 50%;
  opacity: 0.6;
  animation: breathe 2s ease-in-out infinite;
}

.indicator-dot.active {
  background: var(--cyber-success);
  box-shadow: 0 0 10px var(--cyber-success);
}

.indicator-dot.active::before {
  background: var(--cyber-success);
}

.indicator-dot.secure {
  background: var(--cyber-primary);
  box-shadow: 0 0 10px var(--cyber-primary);
}

.indicator-dot.secure::before {
  background: var(--cyber-primary);
}

.indicator-text {
  font-size: 0.7rem;
  color: var(--cyber-text-secondary);
  text-transform: uppercase;
  letter-spacing: 1px;
  font-weight: 600;
}

/* 操作按钮 */
.header-action {
  display: flex;
  align-items: center;
}

.header-btn {
  display: flex;
  align-items: center;
  gap: 0.8rem;
  padding: 12px 24px;
  border: none;
  border-radius: 15px;
  font-family: 'Orbitron', monospace;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  font-size: 0.9rem;
}

.header-btn.primary {
  background: var(--cyber-gradient-primary);
  color: white;
  box-shadow:
    0 8px 25px rgba(0, 234, 255, 0.3),
    inset 0 1px 0 rgba(255, 255, 255, 0.2);
}

.header-btn.primary:hover {
  transform: translateY(-3px) scale(1.05);
  box-shadow:
    0 15px 35px rgba(0, 234, 255, 0.4),
    0 0 30px rgba(0, 234, 255, 0.3);
}

.header-btn.secondary {
  background: transparent;
  color: var(--cyber-primary);
  border: 2px solid var(--cyber-primary);
  box-shadow:
    0 8px 25px rgba(0, 0, 0, 0.2),
    inset 0 0 20px rgba(0, 234, 255, 0.1);
}

.header-btn.secondary:hover {
  transform: translateY(-3px) scale(1.05);
  background: rgba(0, 234, 255, 0.1);
  box-shadow:
    0 15px 35px rgba(0, 0, 0, 0.3),
    0 0 30px rgba(0, 234, 255, 0.2);
}

.header-btn i {
  font-size: 1.1rem;
  transition: transform 0.3s ease;
}

.header-btn:hover i {
  transform: scale(1.1);
}

.btn-scan-effect {
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
  transition: left 0.6s ease;
}

.header-btn:hover .btn-scan-effect {
  left: 100%;
}

.badge-text {
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .scifi-header {
    padding: 1rem 1.5rem;
    flex-direction: column;
    gap: 1rem;
  }

  .logo-container {
    gap: 0.8rem;
  }

  .logo-ring {
    width: 40px;
    height: 40px;
  }

  .ring-outer {
    width: 40px;
    height: 40px;
  }

  .ring-inner {
    width: 28px;
    height: 28px;
  }

  .logo-img {
    width: 22px;
    height: 22px;
  }

  .logo-title {
    font-size: 1.3rem;
    letter-spacing: 1px;
  }

  .logo-subtitle {
    font-size: 0.6rem;
    letter-spacing: 2px;
  }

  .system-indicators {
    gap: 1.5rem;
  }

  .header-btn {
    padding: 10px 20px;
    font-size: 0.8rem;
    gap: 0.6rem;
  }
}

/* 系统标识 */
.system-badge {
  display: flex;
  margin: auto 0;
  align-items: center;
  gap: 1rem;
  background: rgba(18, 22, 41, 0.95);
  border: 2px solid rgba(0, 234, 255, 0.4);
  border-radius: 25px;
  padding: 1rem 2rem;
  backdrop-filter: blur(20px);
  box-shadow:
    0 10px 30px rgba(0, 0, 0, 0.3),
    0 0 30px rgba(0, 234, 255, 0.2);
  animation: breathe 4s ease-in-out infinite;
}

.badge-icon {
  font-size: 2rem;
  color: var(--cyber-primary);
  text-shadow: var(--cyber-glow-primary);
}

@media (max-width: 480px) {
  .scifi-header {
    padding: 0.8rem 1rem;
  }

  .logo-title {
    font-size: 1.1rem;
  }

  .system-indicators {
    display: none;
  }

  .header-btn {
    padding: 8px 16px;
    font-size: 0.7rem;
  }
}

/* 动画关键帧 */
@keyframes rotateGlow {
  0% {
    transform: rotate(0deg);
    filter: hue-rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
    filter: hue-rotate(360deg);
  }
}

@keyframes hologramGlow {
  0%, 100% {
    text-shadow:
      0 0 15px var(--cyber-primary),
      0 0 30px var(--cyber-secondary);
  }
  50% {
    text-shadow:
      0 0 25px var(--cyber-primary),
      0 0 50px var(--cyber-secondary),
      0 0 75px var(--cyber-primary);
  }
}

@keyframes breathe {
  0%, 100% {
    opacity: 0.6;
    transform: scale(1);
  }
  50% {
    opacity: 1;
    transform: scale(1.2);
  }
}
</style>
