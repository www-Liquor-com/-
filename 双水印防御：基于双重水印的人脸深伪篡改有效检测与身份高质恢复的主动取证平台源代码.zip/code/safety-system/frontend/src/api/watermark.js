export async function getWatermarkStats() {
  const token = localStorage.getItem('token')
  const res = await fetch('http://localhost:8000/api/v1/watermark/stats', {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`
    }
  })
  const data = await res.json()
  return { status: res.status, data }
}

export async function embedWatermark({ file, mode }) {
  const token = localStorage.getItem('token')
  const formData = new FormData()
  formData.append('file', file)
  formData.append('mode', mode)
  const res = await fetch('http://localhost:8000/api/v1/watermark/embed', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`
    },
    body: formData
  })
  if (res.status === 200) {
    const data = await res.json()
    let blob = null
    if (data.file_base64 && typeof data.file_base64 === 'string') {
      const base64 = data.file_base64
      const byteString = atob(base64.split(',')[1] || base64)
      const mimeString = base64.split(',')[0]?.split(':')[1]?.split(';')[0] || 'image/png'
      const ab = new ArrayBuffer(byteString.length)
      const ia = new Uint8Array(ab)
      for (let i = 0; i < byteString.length; i++) {
        ia[i] = byteString.charCodeAt(i)
      }
      blob = new Blob([ab], { type: mimeString })
    }
    return { status: 200, blob, metrics: data.metrics }
  } else {
    return { status: res.status, blob: null, metrics: null }
  }
}

export async function extractTamperLocation({ file }) {
  const token = localStorage.getItem('token')
  const formData = new FormData()
  formData.append('file', file)
  const res = await fetch('http://localhost:8000/api/v1/watermark/extract-tl', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`
    },
    body: formData
  })
  return res
}

export async function extractIdentityRecovery({ file }) {
  const token = localStorage.getItem('token')
  const formData = new FormData()
  formData.append('file', file)
  const res = await fetch('http://localhost:8000/api/v1/watermark/extract-ir', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`
    },
    body: formData
  })
  return res
}

export async function getWatermarkRecords() {
  const token = localStorage.getItem('token')
  const res = await fetch('http://localhost:8000/api/v1/watermark/records', {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`
    }
  })
  const data = await res.json()
  return { status: res.status, data }
}

export async function evaluateImage({ file1, file2, quality_compare = 0, id_compare = 1 }) {
  const token = localStorage.getItem('token')
  const formData = new FormData()
  formData.append('file1', file1)
  formData.append('file2', file2)
  formData.append('quality_compare', quality_compare)
  formData.append('id_compare', id_compare)
  const res = await fetch('http://localhost:8000/api/v1/evaluate/evaluate_img', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`
    },
    body: formData
  })
  if (res.status === 200) {
    const data = await res.json()
    return { status: 200, data }
  } else {
    return { status: res.status, data: null }
  }
} 