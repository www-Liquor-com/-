export async function deepfake({ file, model }) {
  const token = localStorage.getItem('token')
  const formData = new FormData()
  formData.append('file', file)
  let url = ''
  if (model === 'FaceShifter') url = 'http://localhost:8000/api/v1/deepfake/faceshifter'
  else if (model === 'Simswap') url = 'http://localhost:8000/api/v1/deepfake/simswap'
  else if (model === 'InfoSwap') url = 'http://localhost:8000/api/v1/deepfake/infoswap'
  else throw new Error('未知模型')
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`
    },
    body: formData
  })
  return res
}

export async function stableDiffusionInpaint({ file, mask }) {
  const token = localStorage.getItem('token')
  const formData = new FormData()
  formData.append('file', file)
  formData.append('mask', mask)
  const res = await fetch('http://localhost:8000/api/v1/deepfake/stablediffusion', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`
    },
    body: formData
  })
  return res
} 