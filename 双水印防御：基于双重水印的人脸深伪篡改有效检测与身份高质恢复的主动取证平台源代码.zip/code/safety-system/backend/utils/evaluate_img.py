import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import cv2
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from skimage.metrics import structural_similarity as ssim
from skimage.metrics import peak_signal_noise_ratio as psnr
import lpips
from ISC_Net.insightface_func.face_detect_crop_single import Face_detect_crop
from torchvision import transforms
import warnings

warnings.filterwarnings('ignore')


def calculate_psnr(img1, img2):
    """
    计算PSNR (Peak Signal-to-Noise Ratio)

    Args:
        img1, img2: numpy.ndarray格式的图像

    Returns:
        float: PSNR值
    """
    return psnr(img1, img2, data_range=255)


def calculate_ssim(img1, img2):
    """
    计算SSIM (Structural Similarity Index)

    Args:
        img1, img2: numpy.ndarray格式的图像

    Returns:
        float: SSIM值
    """
    return ssim(img1, img2, data_range=255, channel_axis=2)


def load_image(image_path):
    """
    加载图像
    Args:
        image_path: 图像文件路径
    Returns:
        numpy.ndarray: 加载的图像数组
    """
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"图像文件不存在: {image_path}")

    # 使用OpenCV加载图像
    image = cv2.imread(image_path)
    if image is None:
        raise ValueError(f"无法加载图像: {image_path}")

    # 转换为RGB格式
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    return image


def resize_image(image, target_size=(256, 256)):
    """
    将图像resize到指定尺寸
    Args:
        image: numpy.ndarray 图像数组
        target_size: 目标尺寸 (width, height)
    Returns:
        numpy.ndarray: resize后的图像数组
    """
    image = load_image(image)
    return cv2.resize(image, target_size, interpolation=cv2.INTER_LANCZOS4)

class ImageEvaluator:
    def __init__(self, device='cuda' if torch.cuda.is_available() else 'cpu'):
        """
        初始化图像评估器
        Args:
            device: 计算设备 ('cuda' 或 'cpu')
        """
        self.device = device
        # 初始化默认 LPIPS模型
        self.lpips_fn = lpips.LPIPS().to(device)

    def preprocess_for_lpips(self, image):
        """
        为LPIPS预处理图像
        
        Args:
            image: numpy.ndarray格式的图像
            
        Returns:
            torch.Tensor: 预处理后的张量
        """
        # 转换为PIL图像
        pil_image = Image.fromarray(image)

        # 调整大小为256x256
        pil_image = pil_image.resize((256, 256), Image.LANCZOS)

        # 转换为张量并归一化到[-1, 1]
        image_tensor = torch.from_numpy(np.array(pil_image)).float()
        image_tensor = image_tensor.permute(2, 0, 1).unsqueeze(0)  # (1, 3, H, W)
        image_tensor = image_tensor / 127.5 - 1.0  # 归一化到[-1, 1]

        return image_tensor.to(self.device)

    def calculate_lpips(self, img1, img2):
        """
        计算LPIPS (Learned Perceptual Image Patch Similarity)
        
        Args:
            img1, img2: numpy.ndarray格式的图像
            
        Returns:
            float: LPIPS值
        """
        # 预处理图像
        img1_tensor = self.preprocess_for_lpips(img1)
        img2_tensor = self.preprocess_for_lpips(img2)

        # 计算LPIPS
        with torch.no_grad():
            lpips_value = self.lpips_fn(img1_tensor, img2_tensor).item()

        return lpips_value

    def extract_face_embedding(self, image):
        """
        提取人脸特征向量
        Args: 
            image: numpy.ndarray格式的图像 
            
        Returns: 
            numpy.ndarray: 人脸特征向量，如果没有检测到人脸则返回None 
        """
        # 初始化人脸裁剪框架 
        detector = Face_detect_crop(name='antelope', root=f'ISC_Net/insightface_func/models')
        detector.prepare(ctx_id=0, det_thresh=0.1, det_size=(256, 256))
        # 初始化ArcFace模型 
        arc_path = 'ISC_Net/arcface_model/arcface_checkpoint.tar'
        arc = torch.load(arc_path, map_location=self.device, weights_only=False)

        # 将输入的image转为BGR格式以适配OpenCV 和 detector
        if image.shape[2] == 3:
            image_bgr = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
        else:
            image_bgr = image  # 如果不是3通道，保持原样 

        b_align_crop_list, mat_list = detector.get(image_bgr, crop_size=112)
        if not b_align_crop_list:
            print("图像评估模块--人脸评估：！！！未检测到人脸！！！")
            return None
        face = b_align_crop_list[0]  # numpy.ndarray, shape [H, W, C], BGR, uint8

        preprocess = transforms.Compose([
            transforms.ToPILImage(),  # numpy [H,W,C] -> PIL
            transforms.Resize((112, 112)),
            transforms.ToTensor(),  # [0,1], [C,H,W]
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        # 转换为RGB
        face_rgb = cv2.cvtColor(face, cv2.COLOR_BGR2RGB)
        # 应用transform并加batch维
        face_tensor = preprocess(face_rgb).unsqueeze(0).to(self.device)

        # ArcFace模型前向
        arc.eval()
        with torch.no_grad():
            embedding = arc(face_tensor)
            embedding = torch.nn.functional.normalize(embedding, p=2, dim=1)
        # 返回numpy向量 
        return embedding.cpu().numpy().flatten()

    def calculate_face_similarity(self, img1, img2):
        """
        计算两张图像中的人脸相似度
        Args:
            img1, img2: numpy.ndarray格式的图像
        Returns:
            float: 人脸相似度分数 (0-1之间，1表示完全相同)
        """
        # 提取人脸特征向量
        embedding1 = self.extract_face_embedding(img1)
        embedding2 = self.extract_face_embedding(img2)

        if embedding1 is None or embedding2 is None:
            return 0.0  # 如果任一张图像没有检测到人脸，返回0

        # 计算余弦相似度
        similarity = np.dot(embedding1, embedding2) / (np.linalg.norm(embedding1) * np.linalg.norm(embedding2))

        return float(similarity)

    def evaluate_images(self, img1_path, img2_path, quality_compare=True, id_compare=True):
        """
        评估两张图像的质量和身份相似度
        Args:
            img1_path: 第一张图像的文件路径
            img2_path: 第二张图像的文件路径
            quality_compare: 是否进行质量比较
            id_compare: 是否进行身份比较
            
        Returns:
            dict: 包含评估结果的字典
        """
        try:

            # 加载图像
            # 重新设置图片路径
            img1 = resize_image(img1_path, (256, 256))
            img2 = resize_image(img2_path, (256, 256))


            results = {
                'img1_path': img1_path,
                'img2_path': img2_path,
                'success': True
            }

            # 质量比较
            if quality_compare:
                print("正在进行质量比较...")
                psnr_value = calculate_psnr(img1, img2)
                ssim_value = calculate_ssim(img1, img2)
                lpips_value = self.calculate_lpips(img1, img2)

                results['quality_metrics'] = {
                    'PSNR': round(psnr_value, 4),
                    'SSIM': round(ssim_value, 4),
                    'LPIPS': round(lpips_value, 4)
                }

                print(f"PSNR: {psnr_value:.4f}")
                print(f"SSIM: {ssim_value:.4f}")
                print(f"LPIPS: {lpips_value:.4f}")

            # 身份比较
            if id_compare:
                print("正在进行身份比较...")
                face_similarity = self.calculate_face_similarity(img1, img2)

                results['identity_metrics'] = {
                    'Face_Similarity': round(face_similarity, 4)
                }

                print(f"人脸相似度: {face_similarity:.4f}")

            return results

        except Exception as e:
            return {
                'img1_path': img1_path,
                'img2_path': img2_path,
                'success': False,
                'error': str(e)
            }


def main():
    """
    主函数，用于测试图像评估功能
    """
    # 创建评估器实例
    evaluator = ImageEvaluator()

    # 示例用法
    img1_path = r"E:\train_program\ISC_Project\backend\test_imgs\recovered_id.png"
    img2_path = r"E:\train_program\ISC_Project\backend\test_imgs\raw.png"

    # 检查文件是否存在
    if not os.path.exists(img1_path) or not os.path.exists(img2_path):
        print("请提供有效的图像文件路径")
        return

    # 进行评估
    results = evaluator.evaluate_images(
        img1_path=img1_path,
        img2_path=img2_path,
        quality_compare=True,
        id_compare=True
    )

    # 打印结果
    if results['success']:
        print("\n=== 评估结果 ===")
        if 'quality_metrics' in results:
            print("质量指标:")
            for metric, value in results['quality_metrics'].items():
                print(f"  {metric}: {value}")

        if 'identity_metrics' in results:
            print("身份指标:")
            for metric, value in results['identity_metrics'].items():
                print(f"  {metric}: {value}")
    else:
        print(f"评估失败: {results['error']}")


if __name__ == "__main__":
    main()
