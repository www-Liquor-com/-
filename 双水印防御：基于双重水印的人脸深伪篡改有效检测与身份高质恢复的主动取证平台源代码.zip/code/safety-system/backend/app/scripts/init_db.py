import asyncio
from tortoise import Tortoise
from backend.app.core.config import settings
from backend.app.models.user import User
from backend.app.models.watermark_type import WatermarkType

async def init():
    await Tortoise.init(
        db_url=settings.TORTOISE_ORM_DB_URI,
        modules={"models": ["backend.app.models"]},
    )
    # 自动建表
    await Tortoise.generate_schemas()

    # 初始化水印类型
    types = [
        {"name": "篡改定位水印", "description": "用于篡改定位的水印"},
        {"name": "身份恢复水印", "description": "用于身份恢复的水印"},
        {"name": "双重水印", "description": "同时具备篡改定位和身份恢复功能的水印"}
    ]
    for t in types:
        exists = await WatermarkType.get_or_none(name=t["name"])
        if not exists:
            await WatermarkType.create(**t)

    # 检查超级管理员是否存在，不存在则创建
    admin_username = "admin"
    admin = await User.get_or_none(username=admin_username)
    if not admin:
        await User.create_user(
            email="admin@example.com",
            username=admin_username,
            password="admin",  # 生产环境请加密
            is_superuser=1,
            status=1
        )
        print("超级管理员已创建")
    else:
        print("超级管理员已存在")

    await Tortoise.close_connections()

if __name__ == "__main__":
    asyncio.run(init())
