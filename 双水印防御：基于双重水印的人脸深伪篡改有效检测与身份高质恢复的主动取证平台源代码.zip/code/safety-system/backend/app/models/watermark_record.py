from tortoise import fields, models
from app.models.user import User
from app.models.watermark_type import WatermarkType

class WatermarkRecord(models.Model):
    id = fields.IntField(pk=True)
    owner = fields.ForeignKeyField("models.User", related_name="watermark_records", to_field="uid")
    file_hash = fields.CharField(max_length=64)
    type = fields.ForeignKeyField("models.WatermarkType", related_name="records")
    time = fields.DatetimeField(auto_now_add=True)
    operation = fields.CharField(max_length=16)  # 'embed' or 'extract'

    class Meta:
        table = "watermark_record" 