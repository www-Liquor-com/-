from tortoise import fields, models

class WatermarkType(models.Model):
    id = fields.IntField(pk=True)
    name = fields.CharField(max_length=32, unique=True)
    description = fields.CharField(max_length=128, null=True)

    class Meta:
        table = "watermark_type" 