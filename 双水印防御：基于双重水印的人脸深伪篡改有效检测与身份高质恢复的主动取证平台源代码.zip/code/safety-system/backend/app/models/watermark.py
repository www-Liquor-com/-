from pydantic import BaseModel

class WatermarkRequest(BaseModel):
    image_data: str  # base64 编码的图片
    watermark: str
 
class WatermarkResponse(BaseModel):
    watermarked_image: str  # base64 编码的图片 