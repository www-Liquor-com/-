from tortoise import fields
from tortoise.models import Model
import shortuuid
from passlib.context import CryptContext
import os

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

class User(Model):
    uid = fields.CharField(pk=True, max_length=22, description="UID")
    email = fields.CharField(max_length=254, null=True, description="邮箱")
    username = fields.CharField(max_length=254, null=True, description="用户名")
    password = fields.CharField(max_length=128, null=True, description="密码")
    is_superuser = fields.IntField(default=0, description="是否为管理员")
    date_joined = fields.DatetimeField(auto_now_add=True, description="注册时间")
    last_login = fields.DatetimeField(null=True, description="上次登录时间")
    status = fields.IntField(default=1, description="用户状态：活跃或锁定")

    @staticmethod 
    def get_password_hash(password: str) -> str:
        return pwd_context.hash(password)

    @staticmethod 
    def verify_password(plain_password: str, hashed_password: str) -> bool:
        return pwd_context.verify(plain_password, hashed_password)

    @classmethod
    async def create_user(cls, email: str, username: str, password: str, is_superuser: int = 0, status: int = 1):
        uid = shortuuid.uuid()
        hashed_password = cls.get_password_hash(password)
        user = await cls.create(
            uid=uid,
            email=email,
            username=username,
            password=hashed_password,
            is_superuser=is_superuser,
            status=status
        )
        # 创建用户专属工作文件夹
        workfolder = os.path.join('media', f'{uid}_workfolder')
        os.makedirs(workfolder, exist_ok=True)
        return user

    class Meta:
        table = "user" 

