import os
class Settings:
    PROJECT_NAME = "DeepFake Proactive Forensics System" 
    VERSION = "1.0.0" 
    # MySQL 数据库配置 
    MYSQL_HOST = "localhost"
    MYSQL_PORT = 3306
    MYSQL_USER = "root"
    MYSQL_PASSWORD = "202312490594"
    MYSQL_DB = "iscp"
    TORTOISE_ORM_DB_URI = (
        f"mysql://{MYSQL_USER}:{MYSQL_PASSWORD}@{MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DB}?charset=utf8mb4"
    )
    # JWT 配置
    JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY", "your-secret-key")
    JWT_ALGORITHM = "HS256"
    JWT_EXPIRE_MINUTES = 60 * 24 * 14 # 14天

settings = Settings() 

