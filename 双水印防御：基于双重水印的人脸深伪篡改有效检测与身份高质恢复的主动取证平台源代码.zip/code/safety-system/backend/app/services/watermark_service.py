class WatermarkService:
    @staticmethod
    def embed_watermark(image_data: str, watermark: str) -> str:
        # TODO: 实现水印嵌入算法
        return image_data

    @staticmethod
    def extract_watermark(image_data: str) -> str:
        # TODO: 实现水印提取算法
        return "watermark" 

