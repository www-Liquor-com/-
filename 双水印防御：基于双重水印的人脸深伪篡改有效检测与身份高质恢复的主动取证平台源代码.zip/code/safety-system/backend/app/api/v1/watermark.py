from fastapi import APIRouter, File, UploadFile, Form, HTTPException, Depends
from fastapi.responses import FileResponse
import os
import cv2
import hashlib
import shortuuid
# 假设ISC_Net已在PYTHONPATH下
from ISC_Net.test_on_image_embed_tl import embed_wm
from ISC_Net.embed_idfmark_whole import embed_idfmark
from ISC_Net.test_on_image_extract_tl import extract_wm
from ISC_Net.extract_idfmark_whole import extract_idfmark
from ISC_Net.id_recovery import recover_id
from app.utils.jwt import get_current_user
from app.models.user import User
from app.models.watermark_type import WatermarkType
from app.models.watermark_record import WatermarkRecord
from tortoise.contrib.pydantic import pydantic_model_creator
from tortoise.expressions import Q
from utils.evaluate_img import ImageEvaluator
from app.utils.image import encode_image
from PIL import Image  

router = APIRouter()

async def get_file_hash(file_path):
    hasher = hashlib.md5()
    with open(file_path, 'rb') as f:
        for chunk in iter(lambda: f.read(4096), b''):
            hasher.update(chunk)
    return hasher.hexdigest()

@router.post("/embed")
async def embed_watermark(
    mode: int = Form(...),
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user)
):
    # 1. 保存图片到用户工作目录
    uid = current_user.uid
    workfolder = os.path.join('media', f'{uid}_workfolder')
    os.makedirs(workfolder, exist_ok=True)
    img_path = os.path.join(workfolder, "input.png")
    with open(img_path, "wb") as f:
        f.write(await file.read())

    # 2. 用opencv读取并包装为列表
    image_input = [cv2.imread(img_path)]

    # 3. 根据mode选择水印
    if mode == 1:
        result_path = embed_wm(image_input, image_input_h=None, message_input=None, save_folder=workfolder)
        wm_type = await WatermarkType.get(name="篡改定位水印")
    elif mode == 2:
        result_path = embed_idfmark(image_input, save_folder=workfolder)
        wm_type = await WatermarkType.get(name="身份恢复水印")
    elif mode == 3:
        result_path1 = embed_wm(image_input, image_input_h=None, message_input=None, save_folder=workfolder)
        img1 = [cv2.imread(result_path1)]
        result_path = embed_idfmark(img1, save_folder=workfolder)
        wm_type = await WatermarkType.get(name="双重水印")
    else:
        raise HTTPException(status_code=400, detail="不支持的mode")

    # 4. 返回最终图片
    if not result_path or not os.path.exists(result_path):
        raise HTTPException(status_code=500, detail="水印嵌入失败")
    # 生成文件哈希
    file_hash = await get_file_hash(img_path)
    # 记录操作
    await WatermarkRecord.create(
        owner=current_user,
        file_hash=file_hash,
        type=wm_type,
        operation="embed"
    )

    # === 新增：计算图像指标 ===
    try:
        evaluator = ImageEvaluator()
        metrics = evaluator.evaluate_images(img1_path=img_path, img2_path=result_path, quality_compare=True, id_compare=False)
        if metrics['success'] and 'quality_metrics' in metrics:
            quality_metrics = metrics['quality_metrics']
        else:
            quality_metrics = {"PSNR": None, "SSIM": None, "LPIPS": None, "error": metrics.get('error', None)}
    except Exception as e:
        quality_metrics = {"PSNR": None, "SSIM": None, "LPIPS": None, "error": str(e)}
    # ======================

    # === 新增：图片转base64 ===
    with Image.open(result_path) as img:
        file_base64 = encode_image(img)
    # ========================

    return {
        "file_base64": file_base64,
        "metrics": quality_metrics
    }

@router.post("/extract-tl")
async def extract_tamper_localization(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user)
):
    uid = current_user.uid
    workfolder = os.path.join('media', f'{uid}_workfolder')
    os.makedirs(workfolder, exist_ok=True)
    
    
    img_path = os.path.join(workfolder, "extract_input.png")
    with open(img_path, "wb") as f:
        f.write(await file.read())
    image_input = [cv2.imread(img_path)]
    # 调用ISC_Net/test_on_image_extract_tl.py的extract_wm
    mask_path = extract_wm(image_input, save_folder=workfolder)
    if not mask_path or not os.path.exists(mask_path):
        raise HTTPException(status_code=500, detail="掩码图像生成失败")
    # 生成文件哈希
    file_hash = await get_file_hash(img_path)
    wm_type = await WatermarkType.get(name="篡改定位水印")
    await WatermarkRecord.create(
        owner=current_user,
        file_hash=file_hash,
        type=wm_type,
        operation="extract"
    )
    return FileResponse(mask_path, media_type="image/png", filename="mask.png") 




@router.post("/extract-ir")
async def extract_identity_recovery(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user)
):
    uid = current_user.uid
    workfolder = os.path.join('media', f'{uid}_workfolder')
    os.makedirs(workfolder, exist_ok=True)
    
    # 1. 保存上传的图片
    img_path = os.path.join(workfolder, "ir_input.png")
    with open(img_path, "wb") as f:
        f.write(await file.read())
        
    # 2. 调用 extract_idfmark 提取身份信息
    decoded_features_list = extract_idfmark([cv2.imread(img_path)]) 
    

    # 4. 调用 recover_id 进行身份恢复
    recovered_id_path = recover_id([cv2.imread(img_path)], decoded_features_list, save_folder=workfolder)
    
    # 5. 返回恢复后的图像
    if not recovered_id_path or not os.path.exists(recovered_id_path):
        raise HTTPException(status_code=500, detail="身份恢复图像生成失败")
    # 生成文件哈希
    file_hash = await get_file_hash(img_path)
    wm_type = await WatermarkType.get(name="身份恢复水印")
    await WatermarkRecord.create(
        owner=current_user,
        file_hash=file_hash,
        type=wm_type,
        operation="extract"
    )
    return FileResponse(recovered_id_path, media_type="image/png", filename="recovered_id.png")

@router.get("/records")
async def get_my_watermark_records(current_user: User = Depends(get_current_user)):
    records = await WatermarkRecord.filter(owner=current_user).prefetch_related("type").order_by("-time")
    op_map = {"embed": "嵌入", "extract": "提取"}
    result = []
    for r in records:
        result.append({
            "id": r.id,
            "file_hash": r.file_hash,
            "type": r.type.name if r.type else None,
            "time": r.time,
            "operation": op_map.get(r.operation, r.operation)
        })
    return {"records": result}

@router.get("/stats")
async def get_watermark_stats(current_user: User = Depends(get_current_user)):
    total = await WatermarkRecord.filter(owner=current_user).count()
    embed_count = await WatermarkRecord.filter(owner=current_user, operation="embed").count()
    extract_count = await WatermarkRecord.filter(owner=current_user, operation="extract").count()
    return {
        "total": total,
        "embed": embed_count,
        "extract": extract_count
    }

@router.get("/ping")
def ping():
    return {"msg": "watermark api v1 ok"} 

@router.post("/evaluate")
async def evaluate_images(
    file1: UploadFile = File(...),
    file2: UploadFile = File(...),
    quality_compare: int = Form(1),
    id_compare: int = Form(1)
):
    """
    图像质量评估接口，评估两张图片的质量和身份相似度。
    参数：
        file1, file2: 两张图片
        quality_compare: 是否评估质量（1/0）
        id_compare: 是否评估身份相似度（1/0）
    返回：
        评估结果字典
    """
    import tempfile
    import shutil
    import os

    # 保存上传的图片到临时文件
    with tempfile.NamedTemporaryFile(delete=False, suffix='.png') as tmp1:
        shutil.copyfileobj(file1.file, tmp1)
        img1_path = tmp1.name
    with tempfile.NamedTemporaryFile(delete=False, suffix='.png') as tmp2:
        shutil.copyfileobj(file2.file, tmp2)
        img2_path = tmp2.name

    try:
        evaluator = ImageEvaluator()
        results = evaluator.evaluate_images(
            img1_path=img1_path,
            img2_path=img2_path,
            quality_compare=bool(quality_compare),
            id_compare=bool(id_compare)
        )
    finally:
        # 清理临时文件
        os.remove(img1_path)
        os.remove(img2_path)

    return results


