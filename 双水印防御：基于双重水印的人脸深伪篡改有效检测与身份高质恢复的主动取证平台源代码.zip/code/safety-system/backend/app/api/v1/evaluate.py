from fastapi import APIRouter, File, UploadFile, Form
from utils.evaluate_img import ImageEvaluator
from PIL import Image
import tempfile
import shutil
import os

router = APIRouter()

@router.post("/evaluate_img")
async def evaluate_images(
    file1: UploadFile = File(...),
    file2: UploadFile = File(...),
    quality_compare: int = Form(1),
    id_compare: int = Form(1)
):
    """
    图像质量评估接口，评估两张图片的质量和身份相似度。
    参数：
        file1, file2: 两张图片
        quality_compare: 是否评估质量（1/0）
        id_compare: 是否评估身份相似度（1/0）
    返回：
        评估结果字典
    """
    # 保存上传的图片到临时文件
    with tempfile.NamedTemporaryFile(delete=False, suffix='.png') as tmp1:
        shutil.copyfileobj(file1.file, tmp1)
        img1_path = tmp1.name
    with tempfile.NamedTemporaryFile(delete=False, suffix='.png') as tmp2:
        shutil.copyfileobj(file2.file, tmp2)
        img2_path = tmp2.name

    try:
        evaluator = ImageEvaluator()
        results = evaluator.evaluate_images(
            img1_path=img1_path,
            img2_path=img2_path,
            quality_compare=bool(quality_compare),
            id_compare=bool(id_compare)
        )
    finally:
        # 清理临时文件
        os.remove(img1_path)
        os.remove(img2_path)

    return results 