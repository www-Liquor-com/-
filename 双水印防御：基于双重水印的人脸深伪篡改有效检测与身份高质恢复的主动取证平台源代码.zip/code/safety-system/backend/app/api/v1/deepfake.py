from fastapi import APIRouter, Depends, File, UploadFile, HTTPException
from fastapi.responses import FileResponse
import os
import hashlib
from app.models.user import User
from app.utils.jwt import get_current_user
import cv2 
# 导入深度伪造方法
from ISC_Net.deepfake import deepfake_simswap,deepfake_faceshifter,deepfake_infoswap, deepfake_sdinpaint

router = APIRouter()

@router.post("/simswap")
async def simswap_deepfake(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user)
):
    """
    使用 SimSwap 对上传的图像进行深度伪造。
    """
    # 1. 将上传的文件保存到用户的工作目录
    uid = current_user.uid
    workfolder = os.path.join('media', f'{uid}_workfolder')
    os.makedirs(workfolder, exist_ok=True)
    
    # 为了避免文件名冲突，使用文件内容的哈希值来命名
    contents = await file.read()
    file_hash = hashlib.md5(contents).hexdigest()
    input_path = os.path.join(workfolder, f"simswap_input_{file_hash}.png")
    
    with open(input_path, "wb") as f:
        f.write(contents)

    # 2. 调用 deepfake_simswap 方法
    # 假设该方法接收输入路径，并返回输出路径
    try:
        output_path = deepfake_simswap([cv2.imread(input_path)],save_folder=workfolder)
    except Exception as e:
        # 捕获可能的处理错误
        raise HTTPException(status_code=500, detail=f"深度伪造处理失败: {e}")

    # 3. 检查输出文件是否存在并返回
    if not output_path or not os.path.exists(output_path):
        raise HTTPException(status_code=500, detail="深度伪造图像生成失败")
        
    return FileResponse(output_path, media_type="image/png", filename="deepfake_result.png") 



@router.post("/infoswap")
async def infoswap_deepfake(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user)
):
    """
    使用 InfoSwap 对上传的图像进行深度伪造。
    """
    # 1. 将上传的文件保存到用户的工作目录
    uid = current_user.uid
    workfolder = os.path.join('media', f'{uid}_workfolder')
    os.makedirs(workfolder, exist_ok=True)
    
    # 为了避免文件名冲突，使用文件内容的哈希值来命名
    contents = await file.read()
    file_hash = hashlib.md5(contents).hexdigest()
    input_path = os.path.join(workfolder, f"infoswap_input_{file_hash}.png")
    
    with open(input_path, "wb") as f:
        f.write(contents)

    # 2. 调用 deepfake_infoswap 方法
    # 假设该方法接收输入路径，并返回输出路径
    try:
        output_path = deepfake_infoswap([cv2.imread(input_path)],save_folder=workfolder)
    except Exception as e:
        # 捕获可能的处理错误
        raise HTTPException(status_code=500, detail=f"深度伪造处理失败: {e}")

    # 3. 检查输出文件是否存在并返回
    if not output_path or not os.path.exists(output_path):
        raise HTTPException(status_code=500, detail="深度伪造图像生成失败")
        
    return FileResponse(output_path, media_type="image/png", filename="deepfake_result.png") 



@router.post("/faceshifter")
async def faceshifter_deepfake(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user)
):
    """
    使用 FaceShifter 对上传的图像进行深度伪造。
    """
    # 1. 将上传的文件保存到用户的工作目录
    uid = current_user.uid
    workfolder = os.path.join('media', f'{uid}_workfolder')
    os.makedirs(workfolder, exist_ok=True)
    
    # 为了避免文件名冲突，使用文件内容的哈希值来命名
    contents = await file.read()
    file_hash = hashlib.md5(contents).hexdigest()
    input_path = os.path.join(workfolder, f"faceshifter_input_{file_hash}.png")
    
    with open(input_path, "wb") as f: 
        f.write(contents)

    # 2. 调用 deepfake_faceshifter 方法
    # 假设该方法接收输入路径，并返回输出路径
    try:
        output_path = deepfake_faceshifter([cv2.imread(input_path)],save_folder=workfolder) 
    except Exception as e:
        # 捕获可能的处理错误
        raise HTTPException(status_code=500, detail=f"深度伪造处理失败: {e}")

    # 3. 检查输出文件是否存在并返回
    if not output_path or not os.path.exists(output_path):
        raise HTTPException(status_code=500, detail="深度伪造图像生成失败")
        
    return FileResponse(output_path, media_type="image/png", filename="deepfake_result.png") 



@router.post("/stablediffusion")
async def stablediffusion_deepfake(
    file: UploadFile = File(...),
    mask: UploadFile = File(...),
    current_user: User = Depends(get_current_user)
):
    """
    使用 Stable Diffusion Inpainting 对上传的图像进行深度伪造。
    前端需上传原始图像和掩码图像（单通道0/255）。
    """
    # 1. 保存图片和掩码到用户工作目录
    uid = current_user.uid
    workfolder = os.path.join('media', f'{uid}_workfolder')
    os.makedirs(workfolder, exist_ok=True)

    # 保存原图
    contents = await file.read()
    file_hash = hashlib.md5(contents).hexdigest()
    input_path = os.path.join(workfolder, f"sdinpaint_input_{file_hash}.png")
    with open(input_path, "wb") as f:
        f.write(contents)

    # 保存掩码
    mask_contents = await mask.read()
    mask_hash = hashlib.md5(mask_contents).hexdigest()
    mask_path = os.path.join(workfolder, f"sdinpaint_mask_{mask_hash}.png")
    with open(mask_path, "wb") as f:
        f.write(mask_contents) 
        print(f"掩码图像保存到：{mask_path}") 

    # 2. 调用 deepfake_sdinpaint
    try:
        img_cv2 = cv2.imread(input_path)
        mask_cv2 = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)  # 保证单通道
        output_path = deepfake_sdinpaint([img_cv2], [mask_cv2], save_folder=workfolder)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"深度伪造处理失败: {e}")

    # 3. 检查输出文件是否存在并返回
    if not output_path or not os.path.exists(output_path):
        raise HTTPException(status_code=500, detail="深度伪造图像生成失败")
    
    return FileResponse(output_path, media_type="image/png", filename="deepfake_result.png")


