from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, EmailStr, field_validator, ValidationInfo
from app.models.user import User
from app.utils.jwt import create_access_token

router = APIRouter()

class RegisterRequest(BaseModel):
    email: EmailStr
    username: str
    password: str
    password2: str

    @field_validator('password2')
    @classmethod
    def passwords_match(cls, v, info: ValidationInfo):
        if 'password' in info.data and v != info.data['password']:
            raise ValueError('两次输入的密码不一致')
        return v

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

@router.post("/register")
async def register(data: RegisterRequest):
    # 检查用户名或邮箱是否已存在
    if await User.get_or_none(username=data.username):
        raise HTTPException(status_code=400, detail="用户名已存在")
    if await User.get_or_none(email=data.email):
        raise HTTPException(status_code=400, detail="邮箱已存在")
    # 创建用户
    await User.create_user(
        email=data.email,
        username=data.username,
        password=data.password
    )
    return {"msg": "注册成功"}

@router.post("/login")
async def login(data: LoginRequest):
    user = await User.get_or_none(email=data.email)
    if not user:
        raise HTTPException(status_code=400, detail="邮箱或密码错误")
    if not User.verify_password(data.password, user.password):
        raise HTTPException(status_code=400, detail="邮箱或密码错误")
    token = create_access_token({"uid": user.uid, "username": user.username})
    return {"access_token": token, "token_type": "bearer"} 