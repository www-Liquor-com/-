# 深度水印系统后端

本项目基于 FastAPI 实现人脸深度伪造主动取证系统的后端服务。

## 启动方式

```bash
uvicorn main:app --reload
```

# 初始化数据库
python -m app.scripts.init_db

# 启动命令
uvicorn main:app --reload 