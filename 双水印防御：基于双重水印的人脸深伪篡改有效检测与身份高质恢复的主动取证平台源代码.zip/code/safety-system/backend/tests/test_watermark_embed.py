import requests

url = "http://localhost:8000/api/v1/watermark/embed"
token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOiJIM0xNcEZYTE11cnIyOEY2MjRlUkRVIiwidXNlcm5hbWUiOiJhaGFhIiwiZXhwIjoxNzUxODE0ODUzfQ.61U96jWqiYdCpBoHowRE-6Kiy9ewf3_t7cuAhh_4agU"
headers = {"Authorization": f"Bearer {token}"} 
files = {"file": open(r"E:\train_program\ISC_Project\backEnd\00768.png", "rb")}
data = {"mode": 3} 

response = requests.post(url, headers=headers, files=files, data=data)
with open("result.png", "wb") as f:
    f.write(response.content) 
    
    
    