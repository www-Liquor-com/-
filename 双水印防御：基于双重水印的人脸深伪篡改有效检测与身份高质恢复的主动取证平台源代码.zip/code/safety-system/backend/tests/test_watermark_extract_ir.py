import requests

API_URL_EXTRACT_IR = "http://localhost:8000/api/v1/watermark/extract-ir" 
TEST_IMAGE_PATH_IR = r"E:\train_program\ISC_Project\backEnd\deepfake_test_result.png" 
# 请将token替换为有效的JWT
TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOiJIM0xNcEZYTE11cnIyOEY2MjRlUkRVIiwidXNlcm5hbWUiOiJhaGFhIiwiZXhwIjoxNzUxODE0ODUzfQ.61U96jWqiYdCpBoHowRE-6Kiy9ewf3_t7cuAhh_4agU"

def test_extract_ir():
    print("\n--- 测试身份恢复接口 ---")
    headers = {"Authorization": f"Bearer {TOKEN}"}
    try:
        with open(TEST_IMAGE_PATH_IR, "rb") as f:
            files = {"file": f}
            response = requests.post(API_URL_EXTRACT_IR, headers=headers, files=files)
        
        print(f"Status code: {response.status_code}")
        if response.status_code == 200:
            with open("test_recovered_id.png", "wb") as f:
                f.write(response.content) 
            print("身份恢复图像已保存为 test_recovered_id.png") 
        else:
            print(f"错误: {response.text}")
    except FileNotFoundError:
        print(f"测试图片未找到: {TEST_IMAGE_PATH_IR}")
    except Exception as e:
        print(f"发生未知错误: {e}")

if __name__ == "__main__": 
    test_extract_ir()  
    
    
    