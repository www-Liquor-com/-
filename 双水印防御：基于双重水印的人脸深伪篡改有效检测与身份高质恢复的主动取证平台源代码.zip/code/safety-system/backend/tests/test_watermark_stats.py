import requests
import json

# --- 配置 ---
API_URL = "http://localhost:8000/api/v1/watermark/stats"
TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOiJIM0xNcEZYTE11cnIyOEY2MjRlUkRVIiwidXNlcm5hbWUiOiJhaGFhIiwiZXhwIjoxNzUxODE0ODUzfQ.61U96jWqiYdCpBoHowRE-6Kiy9ewf3_t7cuAhh_4agU"

# ---------

def test_get_stats():
    """
    测试获取水印操作统计数据的接口。
    """
    print("\n---  开始测试 /watermark/stats 接口 ---")

    if TOKEN == "YOUR_JWT_TOKEN_HERE":
        print("错误：请先将 TOKEN 变量替换为有效的JWT令牌！")
        return

    headers = {
        "Authorization": f"Bearer {TOKEN}"
    }

    try:
        response = requests.get(API_URL, headers=headers)

        print(f"状态码 (Status Code): {response.status_code}")

        if response.status_code == 200:
            try:
                stats_data = response.json()
                print("接口返回数据:")
                print(json.dumps(stats_data, indent=4, ensure_ascii=False))
                
                # 基本断言，确保返回了正确的字段
                assert "total" in stats_data
                assert "embed" in stats_data
                assert "extract" in stats_data
                print("\n测试通过：接口成功返回了预期的统计字段。")

            except json.JSONDecodeError:
                print("测试失败：无法解析返回的JSON数据。")
            except AssertionError:
                print("测试失败：返回的数据中缺少必要的统计字段。")
        else:
            print(f"测试失败：接口返回了非200的状态码。")
            print(f"错误详情: {response.text}")

    except requests.exceptions.RequestException as e:
        print(f"测试失败：请求过程中发生错误 - {e}")


if __name__ == "__main__":
    test_get_stats()  
    
    
    
