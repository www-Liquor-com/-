import requests

url = "http://localhost:8000/api/v1/watermark/records"
token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOiJIM0xNcEZYTE11cnIyOEY2MjRlUkRVIiwidXNlcm5hbWUiOiJhaGFhIiwiZXhwIjoxNzUxODE0ODUzfQ.61U96jWqiYdCpBoHowRE-6Kiy9ewf3_t7cuAhh_4agU"
headers = {"Authorization": f"Bearer {token}"}

response = requests.get(url, headers=headers)
print("Status Code:", response.status_code)
print("Response JSON:", response.json())

# 可选：断言检查
assert response.status_code == 200
for record in response.json().get("records", []):
    assert record["operation"] in ["嵌入", "提取"] 
    
    
