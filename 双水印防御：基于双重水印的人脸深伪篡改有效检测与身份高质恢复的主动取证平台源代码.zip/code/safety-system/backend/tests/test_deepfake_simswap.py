import requests
import json
import os

# --- 配置 ---
API_URL = "http://localhost:8000/api/v1/deepfake/simswap"
# 请将下面的TOKEN替换为你从登录接口获取的有效JWT
TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOiJIM0xNcEZYTE11cnIyOEY2MjRlUkRVIiwidXNlcm5hbWUiOiJhaGFhIiwiZXhwIjoxNzUxODE0ODUzfQ.61U96jWqiYdCpBoHowRE-6Kiy9ewf3_t7cuAhh_4agU"

# 请将此路径替换为你想要用来测试的本地图片路径
TEST_IMAGE_PATH = r"E:\train_program\ISC_Project\backEnd\result.png" 
# ---------

def test_simswap_endpoint():
    """
    测试 /deepfake/simswap 深度伪造接口。
    """
    print("\n---  开始测试 /deepfake/simswap 接口 ---")

    if TOKEN == "YOUR_JWT_TOKEN_HERE":
        print("错误：请先将 TOKEN 变量替换为有效的JWT令牌！")
        return
        
    if not TEST_IMAGE_PATH or TEST_IMAGE_PATH == "path/to/your/test_image.png":
        print("错误：请先将 TEST_IMAGE_PATH 变量设置为一个有效的本地图片路径！")
        return

    headers = {
        "Authorization": f"Bearer {TOKEN}"
    }

    try:
        with open(TEST_IMAGE_PATH, "rb") as f:
            files = {
                "file": (os.path.basename(TEST_IMAGE_PATH), f, "image/png")
            }
            
            print(f"正在上传图片 '{TEST_IMAGE_PATH}' 进行处理，请稍候...")
            response = requests.post(API_URL, headers=headers, files=files, timeout=300) # 设置较长的超时时间

        print(f"状态码 (Status Code): {response.status_code}")

        if response.status_code == 200:
            # 尝试将返回的内容作为图片保存
            output_filename = "deepfake_test_result.png"
            with open(output_filename, "wb") as f:
                f.write(response.content)
            print(f"\n测试通过：接口成功返回图像，并已保存为 '{output_filename}'。")

        else:
            print(f"测试失败：接口返回了非200的状态码。")
            try:
                # 尝试解析JSON错误信息
                error_details = response.json()
                print(f"错误详情: {json.dumps(error_details, indent=4, ensure_ascii=False)}")
            except json.JSONDecodeError:
                # 如果不是JSON，直接打印文本
                print(f"错误详情: {response.text}")

    except FileNotFoundError:
        print(f"测试失败：测试图片未找到 - {TEST_IMAGE_PATH}")
    except requests.exceptions.RequestException as e:
        print(f"测试失败：请求过程中发生错误 - {e}")


if __name__ == "__main__":
    test_simswap_endpoint() 
    
