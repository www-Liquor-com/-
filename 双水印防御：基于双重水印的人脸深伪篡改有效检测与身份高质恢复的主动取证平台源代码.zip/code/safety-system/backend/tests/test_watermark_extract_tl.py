import requests
def test_tl():
    url = "http://localhost:8000/api/v1/watermark/extract-tl"
    token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOiJIM0xNcEZYTE11cnIyOEY2MjRlUkRVIiwidXNlcm5hbWUiOiJhaGFhIiwiZXhwIjoxNzUxODE0ODUzfQ.61U96jWqiYdCpBoHowRE-6Kiy9ewf3_t7cuAhh_4agU"
    headers = {"Authorization": f"Bearer {token}"} 
    files = {"file": open(r"E:\train_program\ISC_Project\backEnd\deepfake_test_result.png", "rb")} 

    response = requests.post(url, headers=headers, files=files) 
    with open("mask.png", "wb") as f:
        f.write(response.content) 

test_tl()

