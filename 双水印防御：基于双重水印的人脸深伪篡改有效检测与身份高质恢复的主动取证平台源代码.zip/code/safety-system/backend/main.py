from fastapi import FastAPI
from tortoise.contrib.fastapi import register_tortoise
from app.core.config import settings
from app.api.v1 import watermark, user, deepfake, evaluate
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 生产环境建议替换为前端实际域名
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(watermark.router, prefix="/api/v1/watermark", tags=["Watermark"])
app.include_router(user.router, prefix="/api/v1/auth", tags=["Auth"])
app.include_router(deepfake.router, prefix="/api/v1/deepfake", tags=["Deepfake"])
app.include_router(evaluate.router, prefix="/api/v1/evaluate", tags=["Evaluate"])

register_tortoise(
    app,
    db_url=settings.TORTOISE_ORM_DB_URI,
    modules={"models": ["app.models"]},
    generate_schemas=True,
    add_exception_handlers=True, 
)

@app.get("/")
async def root():
    return {"message": "Hello World"}

# 启动命令：uvicorn main:app --reload