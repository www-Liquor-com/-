import os
import torch
import numpy as np
from PIL import Image
from torchvision import transforms
from torch.utils.data import Dataset, DataLoader
import lpips
from skimage.metrics import peak_signal_noise_ratio, structural_similarity
from .IdFMark.network.IdFMark import Network
from .IR.models.IRNet  import IRNet 
import torch.nn.functional as F
from .utils.img_fea_loader import ImgFeaDataset
import pickle 
import sys
from .insightface_func.face_detect_crop_single import Face_detect_crop
import cv2 
import argparse 
import concurrent.futures 
import time,hashlib
def set_seed(seed=42):
    """
    固定全局随机种子，确保实验可重复性
    """
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    os.environ['PYTHONHASHSEED'] = str(seed)

# 设置随机种子，保证实验结果可复现
set_seed(42) 


# # 添加项目根目录到 Python 路径
# project_root = os.path.dirname(os.path.abspath(__file__))
# sys.path.append(project_root)

os.environ["TORCH_HOME"] = "E:/torch_cache"  # 设置PyTorch模型缓存路径

def save_image(tensor, path):
    """保存图像"""
    # 输入图像[-1,1]
    image = tensor.squeeze(0).permute(1, 2, 0).cpu().numpy()
    image = ((image + 1) / 2 * 255).astype(np.uint8)
    Image.fromarray(image).save(path)



import lpips  # pip install lpips

lpips_model = lpips.LPIPS().eval()
if torch.cuda.is_available():
    lpips_model = lpips_model.cuda()

def evaluate_quality(original, encoded):
    """评估图像质量，返回 PSNR, SSIM, LPIPS"""
    batch_size = original.size(0)
    psnrs = []
    ssims = []
    lpips_scores = []

    for i in range(batch_size):
        # 单个图像 (C, H, W) -> (H, W, C)
        orig_img = original[i].detach().cpu()
        enc_img = encoded[i].detach().cpu()

        orig_np = orig_img.permute(1, 2, 0).numpy()
        enc_np = enc_img.permute(1, 2, 0).numpy()

        # 裁剪数值，确保在 [-1, 1]
        orig_np = np.clip(orig_np, -1, 1)
        enc_np = np.clip(enc_np, -1, 1)

        # PSNR
        psnr = peak_signal_noise_ratio(orig_np, enc_np, data_range=2.0)
        psnrs.append(psnr)

        # SSIM
        if orig_np.ndim == 3 and orig_np.shape[2] == 1:
            ssim = structural_similarity(orig_np.squeeze(), enc_np.squeeze(), data_range=2.0)
        else:
            ssim = structural_similarity(orig_np, enc_np, channel_axis=2, data_range=2.0)
        ssims.append(ssim)

        # LPIPS 需要输入 shape: (1, 3, H, W)，float32，范围 [-1, 1]
        orig_lpips = orig_img.unsqueeze(0)
        enc_lpips = enc_img.unsqueeze(0)
        if torch.cuda.is_available():
            orig_lpips = orig_lpips.cuda()
            enc_lpips = enc_lpips.cuda()
        lpips_score = lpips_model(orig_lpips, enc_lpips).item()
        lpips_scores.append(lpips_score)

    return np.mean(psnrs), np.mean(ssims), np.mean(lpips_scores)

def cosine_similarity(message1, message2):
    """计算两个消息之间的余弦相似度"""
    # 确保两个消息都是二维张量 [batch_size, message_length]
    if len(message1.shape) == 1:
        message1 = message1.unsqueeze(0)
    if len(message2.shape) == 1:
        message2 = message2.unsqueeze(0)
    
    # 使用与训练时相同的余弦相似度计算方式
    similarity = torch.nn.functional.cosine_similarity(message1, message2, dim=1)
    return similarity


def save_feature_vector(feature, path):
    """保存特征向量到文本文件"""
    # 将特征向量转换为numpy数组
    feature_np = feature.squeeze().cpu().numpy()
    # 保存到文本文件
    np.savetxt(path, feature_np, fmt='%.6f')


def str2bool(v):
    if isinstance(v, bool):
        return v
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')


class IR_TestOptions:
    """测试参数配置类"""
    def __init__(self):
        self.parser = argparse.ArgumentParser()
        self.initialized = False 
        
    def initialize(self):
        """初始化测试参数"""
        self.parser.add_argument('--name', type=str, default='IRNet', help='实验名称，决定存储样本的位置') 
        self.parser.add_argument('--gpu_ids', default='0', help='使用的GPU ID')
        self.parser.add_argument('--checkpoints_dir',default='./checkpoints',help='训练时模型保存位置')
        self.parser.add_argument('--test_result_dir', type=str, default='./test_result4', help='测试结果位置') 
        self.parser.add_argument('--isTrain', type=str2bool, default='False', help='是否为训练模式') 
        self.parser.add_argument('--continue_train', type=str2bool, default='False', help='是否继续训练')  

        # 输入/输出大小配置
        self.parser.add_argument('--batchSize', type=int, default=8, help='输入批次大小')       

        # 模型配置 
        self.parser.add_argument('--pretrained_path', type=str, default=r"ISC_Net\IR\checkpoints\1_1000_net_G.pth", help='预训练模型位置') 
        self.parser.add_argument('--Gdeep', type=str2bool, default='False', help='是否使用深度生成器')  

        # 噪声池配置 
        self.parser.add_argument('--noise_layers', type=list, default=[], help='噪声层')  

        # 其他配置  
        self.parser.add_argument("--Arc_path", type=str, default=r'ISC_Net\arcface_model\arcface_checkpoint.tar', help="ArcFace模型路径")  


    def parse(self):
        """解析参数并保存配置"""
        if not self.initialized:
            self.initialize()
        
        # 使用默认值，避免与Uvicorn冲突
        self.opt, _ = self.parser.parse_known_args([]) 

        # 打印配置信息
        args = vars(self.opt) 
        print('------------ Options -------------') 
        for k, v in sorted(args.items()): 
            print('%s: %s' % (str(k), str(v))) 
        print('-------------- End ----------------') 
        
        return self.opt



def reverse2wholeimage(swaped_imgs, mats, crop_size, oriimgs):
    """
    将裁剪和对齐后的人脸图像恢复到原始图像中:使用alpha混合 
    """
    batch_size = swaped_imgs.shape[0]  # 获取批次大小 
    target_images = []  # 存储处理后的图像列表 
    
    for i in range(batch_size):
        # 将张量转换为numpy数组并调整维度顺序 [C,H,W] -> [H,W,C]
        swaped_img = swaped_imgs[i].cpu().detach().numpy().transpose((1, 2, 0))
        mat = mats[i]  # 获取当前图像的变换矩阵
        oriimg = oriimgs[i].cpu().detach().numpy().transpose((1, 2, 0))
        
        # 创建白色图像作为掩码的基础
        img_white = np.full((crop_size, crop_size), 255, dtype=float)
        
        # 计算仿射变换矩阵的逆矩阵
        # 用于将处理后的图像映射回原始图像空间
        mat_rev = np.zeros([2,3])
        # 计算行列式
        div1 = mat[0][0]*mat[1][1]-mat[0][1]*mat[1][0]
        # 计算逆矩阵的第一行
        mat_rev[0][0] = mat[1][1]/div1
        mat_rev[0][1] = -mat[0][1]/div1
        mat_rev[0][2] = -(mat[0][2]*mat[1][1]-mat[0][1]*mat[1][2])/div1
        # 计算逆矩阵的第二行
        div2 = mat[0][1]*mat[1][0]-mat[0][0]*mat[1][1]
        mat_rev[1][0] = mat[1][0]/div2
        mat_rev[1][1] = -mat[0][0]/div2
        mat_rev[1][2] = -(mat[0][2]*mat[1][0]-mat[0][0]*mat[1][2])/div2
        
        # 获取原始图像尺寸
        orisize = (oriimg.shape[1], oriimg.shape[0])
        
        # 使用逆变换矩阵将处理后的图像映射回原始图像空间
        target_image = cv2.warpAffine(swaped_img, mat_rev, orisize)
        
        # 创建和处理掩码
        # 将白色图像映射到原始图像空间
        img_white = cv2.warpAffine(img_white, mat_rev, orisize)
        # 二值化掩码
        img_white[img_white>20] = 255
        img_mask = img_white
        
        # 使用腐蚀操作缩小掩码区域
        kernel = np.ones((40,40),np.uint8)
        img_mask = cv2.erode(img_mask,kernel,iterations = 1)
        
        # 使用高斯模糊平滑掩码边缘
        kernel_size = (20, 20)
        blur_size = tuple(2*i+1 for i in kernel_size)
        img_mask = cv2.GaussianBlur(img_mask, blur_size, 0)
        
        # 归一化掩码到[0,1]范围
        img_mask = img_mask / 255
        # 调整掩码维度以匹配图像通道
        img_mask = np.reshape(img_mask, [img_mask.shape[0],img_mask.shape[1],1])
        
        # 使用掩码混合处理后的图像和原始图像
        # 在掩码区域使用处理后的图像，其他区域保持原始图像
        target_image = target_image * img_mask + oriimg * (1 - img_mask)
        target_images.append(target_image)
    
    # 将处理后的图像列表堆叠成批次
    target_images = np.stack(target_images, axis=0)
    # 转换为张量并调整维度顺序 [B,H,W,C] -> [B,C,H,W]
    target_images = torch.from_numpy(target_images.transpose((0, 3, 1, 2))).float()
    
    return target_images



# 对img_tensor进行批量身份恢复 
def id_recover(ir_model, facecrop_model, img_tensor, latend_ids): 
    """
    对输入图像进行批量身份恢复
    
    Args:
        ir_model: 身份恢复模型
        facecrop_model: 人脸检测和对齐模型
        img_tensor: 输入图像张量，数据类型为torch.Tensor，范围[-1,1]，维度为[B,C,H,W] 
                   B: 批量大小，C: 通道数(3)，H: 图像高度，W: 图像宽度 
        latend_ids: 身份特征向量，数据类型为torch.Tensor，范围[-1,1]，维度为[B,512] 
                   B: 批量大小，512: 身份特征维度
    """

    B = img_tensor.shape[0]  # 获取批量大小 
    
    # 转换为OpenCV格式 (BGR，范围0-255) 
    img_np_batch = img_tensor.permute(0, 2, 3, 1).cpu().numpy()  # [B,H,W,C] -> [B,H,W,C], tensor -> numpy
    img_np_batch = ((img_np_batch + 1) / 2 * 255).astype(np.uint8) # [-1,1] -> [0,255]
    img_np_list = [cv2.cvtColor(img, cv2.COLOR_RGB2BGR) for img in img_np_batch] # RGB -> BGR 
    
    # 批量进行人脸检测和对齐
    def process_single_image(img_np):
        b_align_crop_list, mat_list = facecrop_model.get(img_np, crop_size=224)
        if not b_align_crop_list:
            print("！！！未检测到人脸！！！")
            return None, None 
        return b_align_crop_list[0], mat_list[0]
    # 使用线程池并行处理 
    with concurrent.futures.ThreadPoolExecutor() as executor:
        results = list(executor.map(process_single_image, img_np_list)) 

    # 处理结果
    img_b_align_crop_list = [] 
    b_mat_list = [] 
    for crop, mat in results:
        if crop is None:  # 如果某张图片未检测到人脸 
            return img_tensor  # 返回原图 
        img_b_align_crop_list.append(crop) 
        b_mat_list.append(mat) 
        
    
    def batch_to_tensor(batch):
        # 方法1：使用 .contiguous() 确保 Tensor 连续
        tensor = torch.from_numpy(batch.transpose(0, 3, 1, 2)).float() / 255.0 
        return tensor.contiguous() 
        
    # 将所有图像堆叠成一个批量数组
    b_align_crop_batch = np.stack([cv2.cvtColor(img, cv2.COLOR_BGR2RGB) for img in img_b_align_crop_list])
    # 一次性转换为tensor并移至GPU 
    b_align_crop_tensors = batch_to_tensor(b_align_crop_batch).cuda() # [B, C, H, W]
    
    # 批量调用模型 ir_model输入是[0,1]，输出是[0,1]
    swap_result = ir_model(b_align_crop_tensors, latend_ids)  
    
    # [-1,1] -> [0,1] 
    ori_imgs = (img_tensor + 1) / 2 
    
    # 批量融合 
    final_imgs = reverse2wholeimage( 
        swap_result,  # [B, C, H, W]
        b_mat_list,   # List of 2x3 matrices 
        224,          # crop_size
        ori_imgs       # [B, C, H, W]
    )

    # 应用transforms将[0,1]范围转换到[-1,1]
    transform = transforms.Compose([ 
        transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])  # 归一化到[-1,1]
    ])
    final_imgs = transform(final_imgs)
    final_imgs = final_imgs.clamp(-1, 1)
    
    return final_imgs, swap_result, b_align_crop_tensors 
    # final_imgs 是恢复后的完整图像，[-1,1] ,cpu 
    # swap_result 是恢复后的人脸部分，[0,1]  ,gpu 
    # b_align_crop_tensors 是恢复前的伪造人脸部分，[0,1]  ,gpu 


def recover_id(img_list,latend_ids_list,save_folder=None):
    # 设置设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    
    # 加载预训练模型 :身份恢复模块 (包含arcface模型) 
    print('正在初始化身份恢复模块...') 
    opt = IR_TestOptions().parse()  
    print(opt)
    ir_model = IRNet() 
    ir_model.initialize(opt)  
    print('身份恢复模块初始化完成...') 
    
    # 加载人脸分割模型
    print("正在初始化人脸检测器...") 
    facecrop_model = Face_detect_crop(name='antelope', root='ISC_Net/insightface_func/models')  
    facecrop_model.prepare(ctx_id=0, det_thresh=0.1, det_size=(256,256))  
    print("人脸检测器初始化完成")  
    
    # 预处理img_list和latend_ids_list 
    # 处理图像列表 
    img_tensors = [] 
    for img in img_list: 
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB) 
        pil_img = Image.fromarray(img_rgb)   
        # 定义图像变换：调整大小, 转换为张量  
        transform = transforms.Compose([  
            transforms.Resize((256, 256)),  
            transforms.ToTensor(),  
            transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])  # 归一化到[-1, 1]   
        ])   
        # 应用变换 
        img_tensor = transform(pil_img) 
        img_tensors.append(img_tensor) 
    
    # 将图像列表堆叠成批次张量 [B, C, H, W] 
    img_tensor = torch.stack(img_tensors, dim=0).to(device) 
    
    # 处理latend_ids_list 
    latend_ids_tensor = torch.from_numpy(np.stack(latend_ids_list, axis=0)).float().to(device)  # [B, 512]  


    
    with torch.no_grad():
        recover_images, recover_images_faces, noise_images_faces = id_recover(ir_model.netG,facecrop_model,img_tensor,latend_ids_tensor)   
        
        timestamp = str(int(time.time() * 1000))  # 毫秒级时间戳
        image_hash = hashlib.md5(recover_images.cpu().numpy().tobytes()).hexdigest()[:8]  # 图像内容的MD5哈希前8位
        unique_id = f"{timestamp}_{image_hash}" 
        if not save_folder:
            save_folder="temp_results"
        save_path = f"{save_folder}/{unique_id}_ir_image.png" 
        
        # 保存身份恢复图像 
        save_image(recover_images[0], save_path) 
        
        return save_path 

        
        
        
