import os
import pickle
from PIL import Image
from torchvision import transforms
from torch.utils.data import Dataset
import torch
import numpy as np

class ImgFeaDataset(Dataset):
    """
    用于加载图像和对应特征向量的数据集类
    
    参数:
        img_path (str): 图像文件所在目录
        fea_path (str): 特征向量文件路径（.pkl文件）
        image_size (int): 图像的目标大小
    """
    def __init__(self, img_path, fea_path, image_size):
        super(ImgFeaDataset, self).__init__()
        self.image_size = image_size 
        self.img_path = img_path 
        
        # 获取图像文件列表
        self.img_list = [f for f in os.listdir(img_path) if f.endswith(('.png', '.jpg', '.jpeg'))]
        
        # 确保特征文件路径是.pkl文件
        if not fea_path.endswith('.pkl'):
            fea_path = os.path.join(fea_path, 'train_256_features.pkl')
        
        # 加载特征字典
        try:
            with open(fea_path, 'rb') as f:
                self.features_dict = pickle.load(f)
        except Exception as e:
            print(f"Error loading feature file {fea_path}: {str(e)}")
            raise
        
        # 定义图像预处理转换
        self.transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
        ])

    def __getitem__(self, index):
        """
        获取数据集中的一个样本 
        返回的图像数据：[-1,1]
        
        参数:
            index (int): 样本索引
            
        返回:
            tuple: (图像张量, 特征向量张量)
        """
        # 获取图像文件名
        img_name = self.img_list[index]
        
        # 加载图像
        img = Image.open(os.path.join(self.img_path, img_name)).convert("RGB")
        img = self.transform(img)
        
        # 从特征字典中获取特征
        if img_name in self.features_dict:
            feature = torch.from_numpy(self.features_dict[img_name]).float()
            # 确保特征维度正确
            if len(feature.shape) > 1:
                feature = feature.squeeze()  # 从 [1, 512] 变成 [512]
        else:
            # 如果特征不存在，返回全零向量
            print(f"！！！警告：图像 {img_name} 的特征在字典中未找到，将使用零向量代替")
            feature = torch.zeros(512)  # 使用正确的特征维度 [512]
        
        return img, feature 

    def __len__(self):
        """
        返回数据集的大小
        
        返回:
            int: 数据集中的样本数量
        """
        return len(self.img_list) 
    
    