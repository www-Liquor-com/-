from . import *
from .Encoder_U import Encoder
from .Decoder_U import Decoder
# from .Noise import Noise
from .Random_Noise import Random_Noise
import torch.nn as nn
import torch
import torch.nn.functional as F


class IdFMark_EncoderDecoder(nn.Module):
	"""水印编码器+噪声池+解码器
	
	实现水印的编码、噪声添加和解码的完整流程。
	包含编码器、噪声层和解码器三个主要组件。
	"""

	def __init__(self, message_length, noise_layers, attention_encoder, attention_decoder):
		"""
		初始化水印编码解码器
		
		参数:
			message_length: 水印消息长度
			noise_layers: 噪声层列表
			attention_encoder: 编码器注意力机制类型
			attention_decoder: 解码器注意力机制类型 
		"""
		super(IdFMark_EncoderDecoder, self).__init__()
		
		# 初始化编码器
		self.encoder = Encoder(message_length, attention=attention_encoder)
		
		# 初始化噪声层
		self.noise = Random_Noise(noise_layers)
		
		# 初始化解码器
		self.decoder = Decoder(message_length, attention=attention_decoder)
  
		self.output_norm = StrictFeatureNormalization()
  
  
		


	def forward(self, images, features):
		"""
		前向传播函数
		
		参数:
			images: 输入图像
			features: 输入特征
		
		返回:
			encoded_images: 编码后的图像
			noised_images: 添加噪声后的图像
			decoded_features: 解码后的特征
		"""
		
		# 编码
		encoded_image = self.encoder(images, features)
		
		# 添加噪声
		if self.noise is not None:
			# 如果没有mask，创建一个全1的mask
			mask = torch.ones_like(images)
			noised_image = self.noise([encoded_image, images, mask])
		else:
			noised_image = encoded_image
		
		# 解码
		decoded_features = self.decoder(noised_image)
		normalized_features = self.output_norm(decoded_features)
		
		# return encoded_image, noised_image, decoded_features
		return encoded_image, noised_image, normalized_features



class StrictFeatureNormalization(nn.Module):
    """严格的特征归一化层（无学习参数）"""
    def __init__(self, eps=1e-8):
        super().__init__()
        self.eps = eps 
        
    def forward(self, x):
        # L2归一化（沿特征维度）
        return F.normalize(x, p=2, dim=1, eps=self.eps) 
    