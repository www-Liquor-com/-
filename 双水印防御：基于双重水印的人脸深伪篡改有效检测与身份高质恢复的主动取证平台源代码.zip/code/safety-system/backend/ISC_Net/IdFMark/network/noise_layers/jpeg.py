# -*- coding: utf-8 -*-
"""
此模块定义了一个模拟 JPEG 压缩的噪声层。
它将输入图像保存为 JPEG 文件，然后再读回，以此引入压缩失真。
"""
import os
import numpy as np
import torch
import torch.nn as nn
from torchvision import transforms
from PIL import Image
import random
import string


class JpegTest(nn.Module):
    """
    JPEG 压缩模拟噪声层。

    通过将图像保存为 JPEG 格式再重新加载，模拟 JPEG 压缩引入的噪声。

    Attributes:
        Q (int): JPEG 压缩质量因子 (0-100)，值越低压缩率越高，失真越严重。
        subsample (int): 色度子采样设置 (0, 1, or 2)。
                         0: 4:4:4 (无子采样)
                         1: 4:2:2
                         2: 4:2:0 (常用)
        path (str): 用于保存临时 JPEG 文件的目录路径。
        transform (transforms.Compose): 将加载的 JPEG 图像转换回 Tensor 并进行归一化的变换。
    """
    def __init__(self, Q: int = 50, subsample: int = 2, path: str = "temp/"):
        """
        初始化 JpegTest 层。

        Args:
            Q (int): JPEG 压缩质量，默认为 50。
            subsample (int): 色度子采样级别，默认为 2 (4:2:0)。
            path (str): 临时文件存储路径，默认为 "temp/"。
        """
        super(JpegTest, self).__init__()
        self.Q = Q
        self.subsample = subsample
        self.path = path
        # 如果临时目录不存在，则创建
        if not os.path.exists(path):
            os.makedirs(path) # 使用 makedirs 以支持创建多级目录
        # 定义图像转换流程：转为 Tensor -> 归一化到 [-1, 1]
        self.transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
        ])

    def get_path(self) -> str:
        """
        生成一个随机的临时 JPEG 文件路径。

        Returns:
            str: 唯一的临时文件路径。
        """
        # 生成一个包含16位随机字母和数字的文件名
        random_name = ''.join(random.sample(string.ascii_letters + string.digits, 16))
        return os.path.join(self.path, random_name + ".jpg") # 使用 os.path.join 保证路径分隔符正确

    def forward(self, image_cover_mask: tuple) -> torch.Tensor:
        """
        前向传播函数。

        对批次中的每个图像执行 JPEG 压缩和解压缩。

        Args:
            image_cover_mask (tuple): 包含 image, cover_image, mask 的元组。
                                      image (torch.Tensor): 输入图像张量 (B, C, H, W)，范围 [-1, 1]。
                                      cover_image (torch.Tensor): 覆盖图像张量（未使用）。
                                      mask (torch.Tensor): 人脸掩码张量（未使用）。

        Returns:
            torch.Tensor: 经过 JPEG 压缩模拟处理后的图像张量。
        """
        image, _ = image_cover_mask[0], image_cover_mask[1] # 忽略 cover_image 和 mask

        # 创建一个与输入图像形状相同的零张量，用于存储处理后的图像
        noised_image = torch.zeros_like(image)

        # 遍历批次中的每一张图像
        for i in range(image.shape[0]):
            # --- 将 Tensor 图像转换为 PIL Image ---
            # 1. 取出单张图像
            # 2. 将像素值范围从 [-1, 1] 转换到 [0, 1]
            # 3. 调整维度顺序从 (C, H, W) 到 (H, W, C) 以符合 PIL 格式
            # 4. 将像素值范围从 [0, 1] 转换到 [0, 255]
            # 5. 添加 0.5 并裁剪到 [0, 255] 范围（此步骤目的可能为了四舍五入，但 clamp 操作已足够）
            # 6. 转移到 CPU 并转换为 uint8 NumPy 数组
            single_image_np = ((image[i].clamp(-1, 1).permute(1, 2, 0) + 1) / 2 * 255).add(0.5).clamp(0, 255).to('cpu', torch.uint8).numpy()
            # 从 NumPy 数组创建 PIL Image 对象
            im = Image.fromarray(single_image_np)

            # --- 保存为 JPEG 并重新加载 ---
            # 生成唯一的临时文件路径
            file_path = self.get_path()
            # 确保文件名不重复（虽然概率极低，但增加鲁棒性）
            while os.path.exists(file_path):
                file_path = self.get_path()
            # 保存为 JPEG 格式
            im.save(file_path, format="JPEG", quality=self.Q, subsampling=self.subsample)
            # 重新加载 JPEG 图像为 PIL Image 对象，然后转为 NumPy 数组
            jpeg_np = np.array(Image.open(file_path), dtype=np.uint8)
            # 删除临时文件
            os.remove(file_path)

            # --- 将加载的 JPEG 图像转换回 Tensor ---
            # 应用预定义的 transform (ToTensor 和 Normalize)
            # unsqueeze(0) 在第 0 维添加批次维度
            # to(image.device) 将 Tensor 移回原始设备 (GPU 或 CPU)
            noised_image[i] = self.transform(jpeg_np).unsqueeze(0).to(image.device)
        
        return noised_image
