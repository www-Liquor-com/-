# -*- coding: utf-8 -*-
"""
此模块定义了一个添加椒盐噪声（Salt and Pepper Noise）的层。
椒盐噪声会随机将图像中的一些像素设置为最大值（盐）或最小值（椒）。
"""
import torch
import torch.nn as nn
import numpy as np


class SaltPepper(nn.Module):
    """
    椒盐噪声层。

    以指定的概率随机将图像像素替换为盐（最大值，通常为 1 或 255）或椒（最小值，通常为 -1 或 0）。

    Attributes:
        prob (float): 像素被噪声（盐或椒）污染的总概率。
                      盐噪声和椒噪声各占 prob / 2 的概率。
    """

    def __init__(self, prob: float = 0.1):
        """
        初始化 SaltPepper 层。

        Args:
            prob (float): 像素被椒盐噪声污染的总概率，默认为 0.1。
                          实际盐噪声概率为 prob / 2，椒噪声概率为 prob / 2。
        """
        super(SaltPepper, self).__init__()
        assert 0 <= prob <= 1, "Probability must be between 0 and 1."
        self.prob = prob

    def sp_noise(self, image: torch.Tensor, prob: float) -> torch.Tensor:
        """
        向图像添加椒盐噪声。

        Args:
            image (torch.Tensor): 输入图像张量 (B, C, H, W)，预期范围 [-1, 1]。
            prob (float): 像素被噪声污染的总概率。

        Returns:
            torch.Tensor: 添加了椒盐噪声的图像张量。
        """
        # 计算盐、椒和保持不变的概率
        salt_prob = prob / 2.0
        pepper_prob = prob / 2.0
        keep_prob = 1.0 - prob

        # 为每个像素生成一个随机选择：0 (保持), 1 (盐), 2 (椒)
        # 使用图像的空间维度 (H, W) 生成掩码
        noise_mask = torch.from_numpy(np.random.choice(
            (0, 1, 2),
            size=image.shape[2:], # 只需 H, W 维度
            p=[keep_prob, salt_prob, pepper_prob]
        )).to(image.device) # 将掩码移到与图像相同的设备

        # 将掩码扩展到与图像相同的形状 (B, C, H, W)
        # unsqueeze 添加 C 和 B 维度，expand 复制
        noise_mask = noise_mask.unsqueeze(0).unsqueeze(0).expand_as(image)

        # 创建图像的副本以避免原地修改输入张量
        noised_image = image.clone()

        # 根据掩码应用噪声
        # 假设图像范围是 [-1, 1]
        noised_image[noise_mask == 1] = 1.0  # 盐噪声 (最大值)
        noised_image[noise_mask == 2] = -1.0 # 椒噪声 (最小值)

        return noised_image

    def forward(self, image_cover_mask: tuple) -> torch.Tensor:
        """
        前向传播函数。

        Args:
            image_cover_mask (tuple): 包含 image, cover_mask, mask 的元组。
                                      image (torch.Tensor): 输入图像张量。
                                      cover_image (torch.Tensor): 覆盖图像（未使用）。
                                      mask (torch.Tensor): 掩码（未使用，原始代码注释掉了相关逻辑）。

        Returns:
            torch.Tensor: 添加了椒盐噪声后的图像张量。
        """
        image, _, mask = image_cover_mask[0], image_cover_mask[1], image_cover_mask[2]

        return self.sp_noise(image, self.prob) 
