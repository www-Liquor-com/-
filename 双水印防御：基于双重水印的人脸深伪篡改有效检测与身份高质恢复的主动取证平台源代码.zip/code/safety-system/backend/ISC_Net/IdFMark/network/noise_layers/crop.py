# -*- coding: utf-8 -*-
"""
此模块包含用于图像裁剪、裁切、丢弃和擦除操作的噪声层。
"""
import torch
import torch.nn as nn
import numpy as np


class FaceCrop(nn.Module):
    """
    人脸裁剪噪声层。

    在图像中随机裁剪出一块区域，保留该区域，其余部分置零。

    Attributes:
        height_ratio (float): 裁剪区域的高度占原图高度的比例。
        width_ratio (float): 裁剪区域的宽度占原图宽度的比例。
    """
    def __init__(self, prob: float = 0.035):
        """
        初始化 FaceCrop 层。

        Args:
            prob (float): 裁剪区域面积占原图面积的比例，默认为 0.035。
                          实际裁剪比例会基于此概率的平方根计算。
        """
        super(FaceCrop, self).__init__()
        # 计算高度和宽度比例，保留两位小数
        self.height_ratio = int(np.sqrt(prob) * 100) / 100
        self.width_ratio = int(np.sqrt(prob) * 100) / 100

    def forward(self, image_cover_mask: tuple) -> torch.Tensor:
        """
        前向传播函数。

        Args:
            image_cover_mask (tuple): 包含 image, cover_image, mask 的元组。
                                      image (torch.Tensor): 输入图像张量。
                                      cover_image (torch.Tensor): 覆盖图像张量（未使用）。
                                      mask (torch.Tensor): 人脸掩码张量。

        Returns:
            torch.Tensor: 经过人脸裁剪处理后的图像张量。
        """
        image, _, mask = image_cover_mask[0], image_cover_mask[1], image_cover_mask[2]

        # 仅使用前三个通道的掩码
        mask = mask[:, 0: 3, :, :]

        # 获取随机裁剪区域的坐标
        h_start, h_end, w_start, w_end = get_random_rectangle_inside(image.shape, self.height_ratio,
                                                                     self.width_ratio)
        # 创建一个与图像形状相同的零张量作为裁剪掩码
        crop_mask = torch.zeros_like(image)
        # 将裁剪区域置为 1
        crop_mask[:, :, h_start: h_end, w_start: w_end] = 1

        # 应用裁剪掩码，保留裁剪区域，其余部分置零
        # 注意：原始代码的注释部分提供了另一种可能的实现方式
        return image * mask # image * mask + image * crop_mask * (1 - mask)


class FaceCropout(nn.Module):
    """
    人脸裁切噪声层。

    从 cover_image 中随机裁剪出一块区域，用该区域替换 image 中的对应区域。
    主要用于模拟将一部分区域替换为背景或其他图像。

    Attributes:
        height_ratio (float): 裁切区域的高度占原图高度的比例。
        width_ratio (float): 裁切区域的宽度占原图宽度的比例。
    """
    def __init__(self, prob: float = 0.3):
        """
        初始化 FaceCropout 层。

        Args:
            prob (float): 裁切区域面积占原图面积的比例，默认为 0.3。
                          实际裁切比例会基于此概率的平方根计算。
        """
        super(FaceCropout, self).__init__()
        # 计算高度和宽度比例，保留两位小数
        self.height_ratio = int(np.sqrt(prob) * 100) / 100
        self.width_ratio = int(np.sqrt(prob) * 100) / 100

    def forward(self, image_cover_mask: tuple) -> torch.Tensor:
        """
        前向传播函数。

        Args:
            image_cover_mask (tuple): 包含 image, cover_image, mask 的元组。
                                      image (torch.Tensor): 输入图像张量。
                                      cover_image (torch.Tensor): 覆盖图像张量，用于替换。
                                      mask (torch.Tensor): 人脸掩码张量。

        Returns:
            torch.Tensor: 经过人脸裁切处理后的图像张量。
        """
        image, cover_image, mask = image_cover_mask[0], image_cover_mask[1], image_cover_mask[2]

        # 仅使用前三个通道的掩码
        mask = mask[:, 0: 3, :, :]

        # 获取随机裁切区域的坐标
        h_start, h_end, w_start, w_end = get_random_rectangle_inside(image.shape, self.height_ratio,
                                                                     self.width_ratio)
        # 复制 cover_image 作为输出的基础
        output = cover_image.clone()
        # 将 image 中对应裁切区域的内容复制到 output 中
        output[:, :, h_start: h_end, w_start: w_end] = image[:, :, h_start: h_end, w_start: w_end]

        # 结合人脸掩码，保留人脸区域的原始图像，非人脸区域使用裁切后的图像
        # 注意：原始代码的注释部分提供了另一种可能的实现方式
        return image * mask + cover_image * (1 - mask) # image * mask + output * (1 - mask)


class Dropout(nn.Module):
    """
    Dropout 噪声层。

    以一定概率将图像中的像素替换为 cover_image 中的对应像素。

    Attributes:
        prob (float): 像素被丢弃（替换为 cover_image 像素）的概率。
    """
    def __init__(self, prob: float = 0.3):
        """
        初始化 Dropout 层。

        Args:
            prob (float): 像素被丢弃的概率，默认为 0.3。
        """
        super(Dropout, self).__init__()
        self.prob = prob

    def forward(self, image_cover_mask: tuple) -> torch.Tensor:
        """
        前向传播函数。

        Args:
            image_cover_mask (tuple): 包含 image, cover_image, mask 的元组。
                                      image (torch.Tensor): 输入图像张量。
                                      cover_image (torch.Tensor): 覆盖图像张量，用于替换。
                                      mask (torch.Tensor): 人脸掩码张量（未使用）。

        Returns:
            torch.Tensor: 经过 Dropout 处理后的图像张量。
        """
        image, cover_image, _ = image_cover_mask[0], image_cover_mask[1], image_cover_mask[2]

        # mask = mask[:, 0: 3, :, :] # 原始代码中注释掉了掩码的使用

        # 生成 Dropout 掩码，值为 0 或 1
        # 值为 1 的概率为 1 - prob，值为 0 的概率为 prob
        dropout_mask = torch.Tensor(np.random.choice([0.0, 1.0], image.shape[2:], p=[self.prob, 1 - self.prob])).to(image.device)
        # 将掩码扩展到与图像相同的形状
        dropout_mask = dropout_mask.expand_as(image)
        # 应用 Dropout：保留值为 1 的像素，替换值为 0 的像素
        output = image * dropout_mask + cover_image * (1 - dropout_mask)

        # 注意：原始代码的注释部分提供了另一种可能的实现方式
        return output # output * mask + image * (1 - mask)


class FaceErase(nn.Module):
    """
    人脸擦除噪声层。

    根据人脸掩码将图像中的人脸区域置零。
    """
    def __init__(self):
        """初始化 FaceErase 层。"""
        super(FaceErase, self).__init__()

    def forward(self, image_cover_mask: tuple) -> torch.Tensor:
        """
        前向传播函数。

        Args:
            image_cover_mask (tuple): 包含 image, cover_image, mask 的元组。
                                      image (torch.Tensor): 输入图像张量。
                                      cover_image (torch.Tensor): 覆盖图像张量（未使用）。
                                      mask (torch.Tensor): 人脸掩码张量。

        Returns:
            torch.Tensor: 经过人脸擦除处理后的图像张量。
        """
        image, _, mask = image_cover_mask[0], image_cover_mask[1], image_cover_mask[2]

        # 仅使用前三个通道的掩码
        mask = mask[:, 0: 3, :, :]

        # 将人脸区域置零 (1 - mask)
        return image * (1 - mask)


class FaceEraseout(nn.Module):
    """
    人脸擦除并替换噪声层。

    根据人脸掩码将图像中的人脸区域替换为 cover_image 中的对应区域。
    """
    def __init__(self):
        """初始化 FaceEraseout 层。"""
        super(FaceEraseout, self).__init__()

    def forward(self, image_cover_mask: tuple) -> torch.Tensor:
        """
        前向传播函数。

        Args:
            image_cover_mask (tuple): 包含 image, cover_image, mask 的元组。
                                      image (torch.Tensor): 输入图像张量。
                                      cover_image (torch.Tensor): 覆盖图像张量，用于替换。
                                      mask (torch.Tensor): 人脸掩码张量。

        Returns:
            torch.Tensor: 经过人脸擦除并替换处理后的图像张量。
        """
        image, cover_image, mask = image_cover_mask[0], image_cover_mask[1], image_cover_mask[2]

        # 使用掩码的后三个通道 (索引 3 到 5)
        mask = mask[:, 3: 6, :, :]

        # 保留非人脸区域 (1 - mask)，并将人脸区域替换为 cover_image (mask)
        output = image * (1 - mask) + cover_image * mask
        return output


def get_random_rectangle_inside(image_shape: tuple, height_ratio: float, width_ratio: float) -> tuple:
    """
    在给定图像尺寸内生成一个随机矩形区域的坐标。

    Args:
        image_shape (tuple): 图像的形状 (batch_size, channels, height, width)。
        height_ratio (float): 矩形高度占图像高度的比例。
        width_ratio (float): 矩形宽度占图像宽度的比例。

    Returns:
        tuple: 包含矩形左上角和右下角坐标的元组 (h_start, h_end, w_start, w_end)。
    """
    image_height = image_shape[2]
    image_width = image_shape[3]

    # 计算矩形的实际高度和宽度
    remaining_height = int(height_ratio * image_height)
    remaining_width = int(width_ratio * image_width)

    # 随机确定矩形的起始高度
    if remaining_height == image_height:
        height_start = 0
    else:
        height_start = np.random.randint(0, image_height - remaining_height + 1) # 修正：确保上界包含

    # 随机确定矩形的起始宽度
    if remaining_width == image_width:
        width_start = 0
    else:
        width_start = np.random.randint(0, image_width - remaining_width + 1) # 修正：确保上界包含

    # 返回矩形的起始和结束坐标
    return height_start, height_start + remaining_height, width_start, width_start + remaining_width
