# -*- coding: utf-8 -*-
"""
此模块利用 Kornia 库实现了一系列基于图像强度和几何变换的噪声层。
包括高斯模糊、高斯噪声、中值滤波、亮度、对比度、饱和度、色相调整以及旋转和仿射变换。
"""
import torch.nn as nn
import kornia
import numpy as np # 虽然导入了但未使用，可以考虑移除


# --- Intensity-based Noises ---

class GaussianBlur(nn.Module):
    """
    高斯模糊噪声层。

    使用 Kornia 的 RandomGaussianBlur 对图像应用随机高斯模糊。

    Attributes:
        transform (kornia.augmentation.RandomGaussianBlur): Kornia 的高斯模糊变换实例。
    """
    def __init__(self, kernel_size: tuple = (3, 3), sigma: tuple = (2, 2), p: float = 1.0):
        """
        初始化 GaussianBlur 层。

        Args:
            kernel_size (tuple): 高斯核的大小，默认为 (3, 3)。
            sigma (tuple): 高斯核的标准差，默认为 (2, 2)。
            p (float): 应用此变换的概率，默认为 1.0 (总是应用)。
        """
        super(GaussianBlur, self).__init__()
        self.transform = kornia.augmentation.RandomGaussianBlur(kernel_size=kernel_size, sigma=sigma, p=p)

    def forward(self, image_cover_mask: tuple) -> nn.Module:
        """
        前向传播函数。

        Args:
            image_cover_mask (tuple): 包含 image, cover_mask, mask 的元组。
                                      image (torch.Tensor): 输入图像张量。
                                      cover_image (torch.Tensor): 覆盖图像（未使用）。
                                      mask (torch.Tensor): 掩码（未使用）。

        Returns:
            torch.Tensor: 经过高斯模糊处理后的图像张量。
        """
        image = image_cover_mask[0]
        return self.transform(image)


class GaussianNoise(nn.Module):
    """
    高斯噪声层。

    使用 Kornia 的 RandomGaussianNoise 向图像添加随机高斯噪声。

    Attributes:
        transform (kornia.augmentation.RandomGaussianNoise): Kornia 的高斯噪声变换实例。
    """
    def __init__(self, mean: float = 0.0, std: float = 0.1, p: float = 1.0):
        """
        初始化 GaussianNoise 层。

        Args:
            mean (float): 高斯噪声的均值，默认为 0.0。
            std (float): 高斯噪声的标准差，默认为 0.1。
            p (float): 应用此变换的概率，默认为 1.0 (总是应用)。
        """
        super(GaussianNoise, self).__init__()
        self.transform = kornia.augmentation.RandomGaussianNoise(mean=mean, std=std, p=p)

    def forward(self, image_cover_mask: tuple) -> nn.Module:
        """
        前向传播函数。

        Args:
            image_cover_mask (tuple): 包含 image, cover_mask, mask 的元组。
                                      image (torch.Tensor): 输入图像张量。
                                      cover_image (torch.Tensor): 覆盖图像（未使用）。
                                      mask (torch.Tensor): 掩码（未使用，原始代码注释掉了相关逻辑）。

        Returns:
            torch.Tensor: 添加了高斯噪声后的图像张量。
        """
        image, _, mask = image_cover_mask[0], image_cover_mask[1], image_cover_mask[2]
        # mask = mask[:, 0: 3, :, :] # 原始代码注释掉了掩码的应用
        # 注意：原始代码注释掉了只在非掩码区域应用噪声的逻辑
        return self.transform(image) # image * mask + self.transform(image) * (1 - mask)


class MedianBlur(nn.Module):
    """
    中值滤波噪声层。

    使用 Kornia 的 MedianBlur 对图像应用中值滤波。

    Attributes:
        transform (kornia.filters.MedianBlur): Kornia 的中值滤波实例。
    """
    def __init__(self, kernel_size: tuple = (3, 3)):
        """
        初始化 MedianBlur 层。

        Args:
            kernel_size (tuple): 中值滤波核的大小，必须是奇数元组，默认为 (3, 3)。
        """
        super(MedianBlur, self).__init__()
        # 注意：Kornia 的 MedianBlur 要求 kernel_size 是 int 或 tuple of ints
        # 如果是 tuple，其长度必须与输入图像的维度匹配（通常是 H, W）
        # 且每个值必须是奇数。
        if isinstance(kernel_size, int):
             kernel_size = (kernel_size, kernel_size) # 转为元组
        assert all(k % 2 == 1 for k in kernel_size), "Kernel size must be odd integers."
        self.transform = kornia.filters.MedianBlur(kernel_size=kernel_size)

    def forward(self, image_cover_mask: tuple) -> nn.Module:
        """
        前向传播函数。

        Args:
            image_cover_mask (tuple): 包含 image, cover_mask, mask 的元组。
                                      image (torch.Tensor): 输入图像张量。
                                      cover_image (torch.Tensor): 覆盖图像（未使用）。
                                      mask (torch.Tensor): 掩码（未使用）。

        Returns:
            torch.Tensor: 经过中值滤波处理后的图像张量。
        """
        image = image_cover_mask[0]
        return self.transform(image)


class Brightness(nn.Module):
    """
    亮度调整层。

    使用 Kornia 的 ColorJitter 随机调整图像的亮度。

    Attributes:
        transform (kornia.augmentation.ColorJitter): Kornia 的颜色抖动变换实例（仅调整亮度）。
    """
    def __init__(self, brightness: float = 0.5, p: float = 1.0):
        """
        初始化 Brightness 层。

        Args:
            brightness (float): 亮度调整因子。最终亮度在 [max(0, 1 - brightness), 1 + brightness] 范围内随机选择。
                              默认为 0.5。
            p (float): 应用此变换的概率，默认为 1.0 (总是应用)。
        """
        super(Brightness, self).__init__()
        # ColorJitter 需要输入范围在 [0, 1]，而我们的输入是 [-1, 1]
        self.transform = kornia.augmentation.ColorJitter(brightness=brightness, p=p)

    def forward(self, image_cover_mask: tuple) -> nn.Module:
        """
        前向传播函数。

        Args:
            image_cover_mask (tuple): 包含 image, cover_mask, mask 的元组。
                                      image (torch.Tensor): 输入图像张量，范围 [-1, 1]。
                                      cover_image (torch.Tensor): 覆盖图像（未使用）。
                                      mask (torch.Tensor): 掩码（未使用）。

        Returns:
            torch.Tensor: 调整亮度后的图像张量，范围 [-1, 1]。
        """
        image = image_cover_mask[0]
        # 将图像范围从 [-1, 1] 转换到 [0, 1] 以适应 ColorJitter
        image_0_1 = (image + 1) / 2
        # 应用亮度调整
        adjusted_image_0_1 = self.transform(image_0_1)
        # 将图像范围从 [0, 1] 转换回 [-1, 1]
        adjusted_image_neg1_1 = (adjusted_image_0_1 * 2) - 1
        return adjusted_image_neg1_1


class Contrast(nn.Module):
    """
    对比度调整层。

    使用 Kornia 的 ColorJitter 随机调整图像的对比度。

    Attributes:
        transform (kornia.augmentation.ColorJitter): Kornia 的颜色抖动变换实例（仅调整对比度）。
    """
    def __init__(self, contrast: float = 0.5, p: float = 1.0):
        """
        初始化 Contrast 层。

        Args:
            contrast (float): 对比度调整因子。最终对比度在 [max(0, 1 - contrast), 1 + contrast] 范围内随机选择。
                            默认为 0.5。
            p (float): 应用此变换的概率，默认为 1.0 (总是应用)。
        """
        super(Contrast, self).__init__()
        self.transform = kornia.augmentation.ColorJitter(contrast=contrast, p=p)

    def forward(self, image_cover_mask: tuple) -> nn.Module:
        """
        前向传播函数。

        Args:
            image_cover_mask (tuple): 包含 image, cover_mask, mask 的元组。
                                      image (torch.Tensor): 输入图像张量，范围 [-1, 1]。
                                      cover_image (torch.Tensor): 覆盖图像（未使用）。
                                      mask (torch.Tensor): 掩码（未使用）。

        Returns:
            torch.Tensor: 调整对比度后的图像张量，范围 [-1, 1]。
        """
        image = image_cover_mask[0]
        # 将图像范围从 [-1, 1] 转换到 [0, 1]
        image_0_1 = (image + 1) / 2
        # 应用对比度调整
        adjusted_image_0_1 = self.transform(image_0_1)
        # 将图像范围从 [0, 1] 转换回 [-1, 1]
        adjusted_image_neg1_1 = (adjusted_image_0_1 * 2) - 1
        return adjusted_image_neg1_1


class Saturation(nn.Module):
    """
    饱和度调整层。

    使用 Kornia 的 ColorJitter 随机调整图像的饱和度。

    Attributes:
        transform (kornia.augmentation.ColorJitter): Kornia 的颜色抖动变换实例（仅调整饱和度）。
    """
    def __init__(self, saturation: float = 0.5, p: float = 1.0):
        """
        初始化 Saturation 层。

        Args:
            saturation (float): 饱和度调整因子。最终饱和度在 [max(0, 1 - saturation), 1 + saturation] 范围内随机选择。
                              默认为 0.5。
            p (float): 应用此变换的概率，默认为 1.0 (总是应用)。
        """
        super(Saturation, self).__init__()
        self.transform = kornia.augmentation.ColorJitter(saturation=saturation, p=p)

    def forward(self, image_cover_mask: tuple) -> nn.Module:
        """
        前向传播函数。

        Args:
            image_cover_mask (tuple): 包含 image, cover_mask, mask 的元组。
                                      image (torch.Tensor): 输入图像张量，范围 [-1, 1]。
                                      cover_image (torch.Tensor): 覆盖图像（未使用）。
                                      mask (torch.Tensor): 掩码（未使用）。

        Returns:
            torch.Tensor: 调整饱和度后的图像张量，范围 [-1, 1]。
        """
        image = image_cover_mask[0]
        # 将图像范围从 [-1, 1] 转换到 [0, 1]
        image_0_1 = (image + 1) / 2
        # 应用饱和度调整
        adjusted_image_0_1 = self.transform(image_0_1)
        # 将图像范围从 [0, 1] 转换回 [-1, 1]
        adjusted_image_neg1_1 = (adjusted_image_0_1 * 2) - 1
        return adjusted_image_neg1_1


class Hue(nn.Module):
    """
    色相调整层。

    使用 Kornia 的 ColorJitter 随机调整图像的色相。

    Attributes:
        transform (kornia.augmentation.ColorJitter): Kornia 的颜色抖动变换实例（仅调整色相）。
    """
    def __init__(self, hue: float = 0.1, p: float = 1.0):
        """
        初始化 Hue 层。

        Args:
            hue (float): 色相调整因子。最终色相在 [-hue, hue] 范围内随机选择。
                       注意 Kornia 的范围是 [-0.5, 0.5]。输入值应在 [0, 0.5] 之间。
                       默认为 0.1。
            p (float): 应用此变换的概率，默认为 1.0 (总是应用)。
        """
        super(Hue, self).__init__()
        assert 0 <= hue <= 0.5, "Hue factor must be between 0 and 0.5"
        self.transform = kornia.augmentation.ColorJitter(hue=hue, p=p)

    def forward(self, image_cover_mask: tuple) -> nn.Module:
        """
        前向传播函数。

        Args:
            image_cover_mask (tuple): 包含 image, cover_mask, mask 的元组。
                                      image (torch.Tensor): 输入图像张量，范围 [-1, 1]。
                                      cover_image (torch.Tensor): 覆盖图像（未使用）。
                                      mask (torch.Tensor): 掩码（未使用）。

        Returns:
            torch.Tensor: 调整色相后的图像张量，范围 [-1, 1]。
        """
        image = image_cover_mask[0]
        # 将图像范围从 [-1, 1] 转换到 [0, 1]
        image_0_1 = (image + 1) / 2
        # 应用色相调整
        adjusted_image_0_1 = self.transform(image_0_1)
        # 将图像范围从 [0, 1] 转换回 [-1, 1]
        adjusted_image_neg1_1 = (adjusted_image_0_1 * 2) - 1
        return adjusted_image_neg1_1


# --- Geometric Transformations ---

class Rotation(nn.Module):
    """
    随机旋转层。

    使用 Kornia 的 RandomRotation 对图像进行随机旋转。

    Attributes:
        transform (kornia.augmentation.RandomRotation): Kornia 的随机旋转变换实例。
    """
    def __init__(self, degrees: float = 180.0, p: float = 1.0):
        """
        初始化 Rotation 层。

        Args:
            degrees (float or tuple): 旋转角度范围。如果是浮点数，则范围是 [-degrees, degrees]。
                                    如果是元组 (min, max)，则范围是 [min, max]。默认为 180.0。
            p (float): 应用此变换的概率，默认为 1.0 (总是应用)。
        """
        super(Rotation, self).__init__()
        self.transform = kornia.augmentation.RandomRotation(degrees=degrees, p=p)

    def forward(self, image_cover_mask: tuple) -> nn.Module:
        """
        前向传播函数。

        Args:
            image_cover_mask (tuple): 包含 image, cover_mask, mask 的元组。
                                      image (torch.Tensor): 输入图像张量。
                                      cover_image (torch.Tensor): 覆盖图像（未使用）。
                                      mask (torch.Tensor): 掩码（未使用）。

        Returns:
            torch.Tensor: 经过随机旋转处理后的图像张量。
        """
        image = image_cover_mask[0]
        return self.transform(image)


class Affine(nn.Module):
    """
    随机仿射变换层。

    使用 Kornia 的 RandomAffine 对图像应用随机仿射变换，包括旋转、平移、缩放和剪切。

    Attributes:
        transform (kornia.augmentation.RandomAffine): Kornia 的随机仿射变换实例。
    """
    def __init__(self, degrees: float = 0.0, translate: float = 0.1, scale: list = None, shear: float = 30.0, p: float = 1.0):
        """
        初始化 Affine 层。

        Args:
            degrees (float or tuple): 旋转角度范围，默认为 0.0 (不旋转)。
            translate (float or tuple): 水平和垂直平移的最大绝对分数，默认为 0.1。
            scale (list or tuple, optional): 缩放因子范围 [min, max]，默认为 None (不缩放)。
                                             原始代码默认为 [0.7, 0.7]，表示固定缩放 0.7 倍。
                                             若要随机缩放，可设为例如 [0.7, 1.3]。
            shear (float or tuple): 剪切角度范围，默认为 30.0。
            p (float): 应用此变换的概率，默认为 1.0 (总是应用)。
        """
        super(Affine, self).__init__()
        # 处理原始代码的默认 scale=[0.7, 0.7]，这在 Kornia 中通常表示范围
        # 如果意图是固定缩放，应设为 scale=(0.7, 0.7) 或 scale=[0.7, 0.7] 且 Kornia 版本支持
        # 这里保留原始默认值，但添加注释说明
        if scale is None:
            scale = [0.7, 0.7] # 保持原始默认值
        self.transform = kornia.augmentation.RandomAffine(degrees=degrees, translate=translate, scale=scale, shear=shear, p=p)

    def forward(self, image_cover_mask: tuple) -> nn.Module:
        """
        前向传播函数。

        Args:
            image_cover_mask (tuple): 包含 image, cover_mask, mask 的元组。
                                      image (torch.Tensor): 输入图像张量。
                                      cover_image (torch.Tensor): 覆盖图像（未使用）。
                                      mask (torch.Tensor): 掩码（未使用）。

        Returns:
            torch.Tensor: 经过随机仿射变换处理后的图像张量。
        """
        image = image_cover_mask[0]
        return self.transform(image)
