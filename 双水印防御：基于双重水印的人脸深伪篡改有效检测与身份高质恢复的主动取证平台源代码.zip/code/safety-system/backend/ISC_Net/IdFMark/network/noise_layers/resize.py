# -*- coding: utf-8 -*-
"""
此模块定义了一个通过调整图像大小来引入噪声的层。
它首先将图像缩小，然后再放大回原始尺寸，利用插值过程引入失真。
"""
import torch.nn as nn
import torch.nn.functional as F


class Resize(nn.Module):
    """
    图像缩放噪声层。

    通过先下采样再上采样的方式模拟图像在传输或处理中因分辨率变化引入的噪声。

    Attributes:
        down_scale (float): 图像下采样的比例因子。例如，0.5 表示将图像缩小到原始尺寸的一半。
    """
    def __init__(self, down_scale: float = 0.5):
        """
        初始化 Resize 层。

        Args:
            down_scale (float): 下采样比例因子，默认为 0.5。值应在 (0, 1] 范围内。
        """
        super(Resize, self).__init__()
        assert 0 < down_scale <= 1, "down_scale factor must be between 0 and 1 (exclusive of 0)"
        self.down_scale = down_scale

    def forward(self, image_cover_mask: tuple) -> nn.Module:
        """
        前向传播函数。

        Args:
            image_cover_mask (tuple): 包含 image, cover_mask, mask 的元组。
                                      image (torch.Tensor): 输入图像张量 (B, C, H, W)。
                                      cover_image (torch.Tensor): 覆盖图像（未使用）。
                                      mask (torch.Tensor): 掩码（未使用）。

        Returns:
            torch.Tensor: 经过缩放处理后的图像张量，尺寸与输入图像相同。
        """
        image = image_cover_mask[0]
        original_height, original_width = image.shape[2], image.shape[3]

        # 计算缩小后的尺寸
        down_height = int(self.down_scale * original_height)
        down_width = int(self.down_scale * original_width)

        # 确保缩小后的尺寸至少为 1x1
        down_height = max(1, down_height)
        down_width = max(1, down_width)

        # 1. 将图像缩小 (下采样)
        # 使用 F.interpolate 进行插值，'nearest' 模式速度快，但可能引入块状效应
        noised_down = F.interpolate(
                                    image,
                                    size=(down_height, down_width),
                                    mode='nearest' # 可以考虑 'bilinear' 或 'bicubic' 以获得更平滑效果，但计算量更大
                                    )

        # 2. 将图像放大回原始尺寸 (上采样)
        # 同样使用 'nearest' 插值
        noised_up = F.interpolate(
                                    noised_down,
                                    size=(original_height, original_width),
                                    mode='nearest' # 同样可以考虑其他插值模式
                                    )

        return noised_up
