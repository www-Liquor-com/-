# -*- coding: utf-8 -*-
"""
此模块定义了一个恒等映射（Identity Mapping）的噪声层。
该层不对输入图像做任何修改，直接返回原图像。
"""
import torch
import torch.nn as nn


class Identity(nn.Module):
    """
    恒等映射噪声层。

    该层不改变输入图像，实现了一个直通（pass-through）操作。
    通常用作基线或在不需要添加噪声时的占位符。
    """

    def __init__(self):
        """
        初始化 Identity 层。
        """
        super(Identity, self).__init__()

    def forward(self, image_cover_mask: tuple) -> torch.Tensor:
        """
        前向传播函数。

        Args:
            image_cover_mask (tuple): 包含 image, cover_image, mask 的元组。
                                      image (torch.Tensor): 输入图像张量。
                                      cover_image (torch.Tensor): 覆盖图像张量（未使用）。
                                      mask (torch.Tensor): 人脸掩码张量（未使用）。

        Returns:
            torch.Tensor: 未经修改的原始输入图像张量。
        """
        image = image_cover_mask[0]
        return image
