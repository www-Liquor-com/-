from .IdFMark_EncoderDecoder import IdFMark_EncoderDecoder
from .Patch_Discriminator import Patch_Discriminator
import torch
import kornia.losses
import lpips
import torch.nn as nn
from skimage.metrics import peak_signal_noise_ratio
import torch.nn.functional as F
from lpips import LPIPS  # 添加LPIPS导入
from pytorch_msssim import SSIM  # 添加SSIM损失函数

class Network:
    """水印网络模型
    
    包含编码器-解码器和判别器的完整水印网络。
    实现了水印的嵌入、提取和对抗训练功能。
    """

    def __init__(self, message_length: int, noise_layers: list, device: torch.device, 
                 batch_size: int, lr: float, beta1: float, 
                 attention_encoder: str, attention_decoder: str, weight: list):
        """
        初始化水印网络
        
        参数:
            message_length: 水印消息长度
            noise_layers: 噪声层列表
            device: 计算设备（CPU/GPU）
            batch_size: 批次大小
            lr: 学习率
            beta1: Adam优化器的beta1参数
            attention_encoder: 编码器注意力机制类型
            attention_decoder: 解码器注意力机制类型
            weight: 各损失函数的权重列表 [encoder_weight, decoder_weight, discriminator_weight]
        """
        self.message_length = message_length
        self.noise_layers = noise_layers
        self.device = device
        self.batch_size = batch_size
        self.lr = lr
        self.beta1 = beta1
        self.attention_encoder = attention_encoder
        self.attention_decoder = attention_decoder
        self.weight = weight 

        # 设置设备（CPU或GPU）
        self.device = device 

        # 导入LPIPS损失函数 
        self.criterion_LPIPS = lpips.LPIPS().to(device)  # 感知损失

        # 设置各个损失函数的权重 
        self.encoder_weight = weight[0]  # 编码器损失权重 
        self.decoder_weight = weight[1]  # 解码器损失权重 
        self.discriminator_weight = weight[2]  # 判别器损失权重 

        # 初始化网络组件
        self.encoder_decoder = IdFMark_EncoderDecoder(
            message_length, noise_layers, attention_encoder, attention_decoder
        ).to(device)
        self.discriminator = Patch_Discriminator().to(device)

        # 使用DataParallel进行多GPU训练
        self.encoder_decoder = torch.nn.DataParallel(self.encoder_decoder)
        self.discriminator = torch.nn.DataParallel(self.discriminator)

        # 设置标签值：原始图像为1，编码后的图像为-1
        self.label_original = 1.0 
        self.label_encoded = -1.0 

        # 冻结噪声层的参数，不进行训练 
        for p in self.encoder_decoder.module.noise.parameters():
            p.requires_grad = False

        # 初始化优化器 
        self.opt_encoder_decoder = torch.optim.Adam(
            filter(lambda p: p.requires_grad, self.encoder_decoder.parameters()), 
            lr=lr, betas=(beta1, 0.999)
        )
        self.opt_discriminator = torch.optim.Adam(
            self.discriminator.parameters(), lr=lr, betas=(beta1, 0.999)
        )

        self.lpips_loss = LPIPS(net='vgg').to('cuda' if torch.cuda.is_available() else 'cpu')
        self.ssim_loss = SSIM(data_range=1.0, size_average=True, channel=3).to('cuda' if torch.cuda.is_available() else 'cpu')
        self.mse_loss = nn.MSELoss()  # 添加MSE损失函数实例
        
        # 添加解码器权重自适应调整相关参数
        self.decoder_loss_history = []  # 记录解码器损失历史 
        self.decoder_weight_decay = 0.95  # 权重衰减系数 
        self.min_decoder_weight = 0.01  # 最小解码器权重 
        self.patience = 5  # 观察窗口大小 
        self.current_decoder_weight = self.decoder_weight  # 当前解码器权重 


    def train(self, images, features):
        """
        训练网络
        
        参数:
            images: 输入图像 
            features: 输入特征 
            
        返回:
            result: 训练结果字典 
        """
        # 将模型设置为训练模式 
        self.encoder_decoder.train() 
        self.discriminator.train() 

        # 将数据移到指定设备
        images = images.to(self.device)
        features = features.to(self.device) 
            
        # 前向传播 
        encoded_images, noised_images, decoded_features = self.encoder_decoder(images, features) 

        # 计算编码器损失 
        g_loss_on_encoder_MSE = self.mse_loss(encoded_images, images)  # 使用实例化的MSE损失函数
        g_loss_on_encoder_LPIPS = self.lpips_loss(encoded_images, images).mean() 

        # 动态调整LPIPS权重:
        # 初始值为0.1倍的encoder_weight，然后根据MSE和LPIPS的比值进行调整
        base_lpips_weight = 0.1 * self.encoder_weight  # 提高基础值 
        current_lpips_weight = base_lpips_weight * torch.sigmoid(
            g_loss_on_encoder_MSE.detach() / g_loss_on_encoder_LPIPS.detach() - 1.5
        ) * 2  # 范围控制在0.05-0.15 
        
        g_loss_on_encoder = g_loss_on_encoder_MSE + current_lpips_weight * g_loss_on_encoder_LPIPS 

        # 解码器损失 
        # 余弦相似度 
        cos_sim = torch.nn.functional.cosine_similarity(decoded_features, features, dim=1) 
        # 角度间隔损失（提升区分度）
        margin = 0.3  # ArcFace常用间隔值 
        theta = torch.acos(cos_sim.clamp(-1+1e-7, 1-1e-7)) 
        g_loss_on_decoder = torch.mean(1 - (torch.cos(theta + margin) - 0.1))  # 带衰减的间隔损失  
        
        # 更新解码器损失历史
        self.decoder_loss_history.append(g_loss_on_decoder.item())
        if len(self.decoder_loss_history) > self.patience:
            self.decoder_loss_history.pop(0)

        # 检查解码器损失是否趋于稳定 
        if len(self.decoder_loss_history) == self.patience:
            loss_change = abs(self.decoder_loss_history[-1] - self.decoder_loss_history[0])
            if loss_change < 0.01:  # 如果损失变化很小
                # 降低解码器权重
                self.current_decoder_weight = max(
                    self.current_decoder_weight * self.decoder_weight_decay,
                    self.min_decoder_weight
                )

        # 计算判别器损失
        # d_loss = self.discriminator.module.loss(encoded_images, images)
        
        # 暂时关闭判别器损失
        # g_loss_on_discriminator = self.discriminator.module.loss(encoded_images, images, is_real=True) 
        
        # 总损失
        g_loss = (
            1.0 * g_loss_on_encoder 
            + self.current_decoder_weight * g_loss_on_decoder 
            # 3.0 * g_loss_on_decoder 
            # + 0.01 * g_loss_on_discriminator  # 保持较小的对抗损失权重
        ) 
        
        # 计算评估指标 
        cosine_similarity = torch.mean(cos_sim) 
        ssim = self.ssim_loss(encoded_images, images) 
        psnr = self.psnr(encoded_images, images) 
        
        
        # 更新生成器参数 
        self.opt_encoder_decoder.zero_grad() 
        g_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.encoder_decoder.parameters(), max_norm=1.0) 
        self.opt_encoder_decoder.step()

        # 只在判别器参数需要梯度时更新判别器 
        # if any(p.requires_grad for p in self.discriminator.parameters()):
        #     self.opt_discriminator.zero_grad()
        #     d_loss.backward()
        #     self.opt_discriminator.step()

        # 返回训练结果
        result = {
            "g_loss": g_loss.item(),
            "cosine_similarity": cosine_similarity.item(),
            "psnr": psnr.item(),
            "ssim": ssim.item(),
            # "g_loss_on_discriminator": g_loss_on_discriminator.item(),
            "g_loss_on_encoder_MSE": g_loss_on_encoder_MSE.item(),
            "g_loss_on_encoder_LPIPS": g_loss_on_encoder_LPIPS.item(),
            "g_loss_on_decoder": g_loss_on_decoder.item(),
            # d_loss
            "current_lpips_weight": current_lpips_weight.item(),
            "current_decoder_weight": self.current_decoder_weight,
        } 
        
        return result


    def validation(self, images: torch.Tensor, features: torch.Tensor) -> tuple:
        """
        验证网络
        
        参数:
            images: 原始图像
            features: 特征向量（作为水印消息）
            
        返回:
            tuple: (结果字典, (原始图像, 编码图像, 噪声图像))
        """
        self.encoder_decoder.eval()
        self.discriminator.eval()

        with torch.no_grad():
            # 将数据移到指定设备
            images = images.to(self.device)
            features = features.to(self.device)
            
            # 前向传播
            encoded_images, noised_images, decoded_features = self.encoder_decoder(images, features)

            # 计算编码器损失
            g_loss_on_encoder_MSE = self.mse_loss(encoded_images, images)  # 使用Network类的mse_loss
            g_loss_on_encoder_LPIPS = self.lpips_loss(encoded_images, images).mean()

            # 动态调整LPIPS权重
            base_lpips_weight = 0.1 * self.encoder_weight
            current_lpips_weight = base_lpips_weight * torch.sigmoid(
                g_loss_on_encoder_MSE.detach() / g_loss_on_encoder_LPIPS.detach() - 1.5
            ) * 2 
            
            g_loss_on_encoder = g_loss_on_encoder_MSE + current_lpips_weight * g_loss_on_encoder_LPIPS
            
            # 解码器损失
            cos_sim = torch.nn.functional.cosine_similarity(decoded_features, features, dim=1)
            margin = 0.3
            theta = torch.acos(cos_sim.clamp(-1+1e-7, 1-1e-7))
            g_loss_on_decoder = torch.mean(1 - (torch.cos(theta + margin) - 0.1))
            
            # 计算总损失
            g_loss = (
                1.0 * g_loss_on_encoder +
                self.current_decoder_weight * g_loss_on_decoder 
            )
            
            # 计算评估指标
            cosine_similarity = torch.mean(cos_sim)
            ssim = self.ssim_loss(encoded_images, images)
            psnr = self.psnr(encoded_images, images)
            
            result = {
                "g_loss": g_loss.item(),
                "cosine_similarity": cosine_similarity.item(),
                "psnr": psnr.item(),
                "ssim": ssim.item(),
                "g_loss_on_encoder_MSE": g_loss_on_encoder_MSE.item(),
                "g_loss_on_encoder_LPIPS": g_loss_on_encoder_LPIPS.item(),
                "g_loss_on_decoder": g_loss_on_decoder.item(),
                "current_lpips_weight": current_lpips_weight.item(),
                "current_decoder_weight": self.current_decoder_weight,
        }

        return result, (images, encoded_images, noised_images)


    def decoded_message_cosine_similarity(self, message: torch.Tensor, decoded_message: torch.Tensor) -> float:
        """ 
        计算单个消息的余弦相似度 
        
        参数:
            message: 原始消息
            decoded_message: 解码后的消息
            
        返回:
            float: 余弦相似度 
        """
        return torch.nn.functional.cosine_similarity(message, decoded_message, dim=0).item()


    def decoded_message_cosine_similarity_batch(self, messages: torch.Tensor, decoded_messages: torch.Tensor) -> float:
        """
        计算批次消息的平均余弦相似度
        
        参数:
            messages: 原始消息批次 
            decoded_messages: 解码后的消息批次 
            
        返回: 
            float: 平均余弦相似度 
        """
        return torch.mean(torch.nn.functional.cosine_similarity(decoded_messages, messages, dim=1)).item()


    def save_model(self, path_encoder_decoder: str, path_discriminator: str):
        """
        保存模型参数
        
        参数:
            path_encoder_decoder: 编码器-解码器模型保存路径 
            path_discriminator: 判别器模型保存路径 
        """
        torch.save(self.encoder_decoder.module.state_dict(), path_encoder_decoder) 
        torch.save(self.discriminator.module.state_dict(), path_discriminator) 


    def load_model(self, path_encoder_decoder: str, path_discriminator: str):
        """
        加载模型参数 
        
        参数:
            path_encoder_decoder: 编码器-解码器模型路径
            path_discriminator: 判别器模型路径
        """
        self.load_model_ed(path_encoder_decoder)
        self.load_model_d(path_discriminator)


    def load_model_ed(self, path_encoder_decoder: str):
        """
        加载编码器-解码器模型参数
        
        参数:
            path_encoder_decoder: 编码器-解码器模型路径
        """
        self.encoder_decoder.module.load_state_dict(torch.load(path_encoder_decoder), strict=False)


    def load_model_d(self, path_discriminator: str):
        """
        加载判别器模型参数
        
        参数:
            path_discriminator: 判别器模型路径
        """
        self.discriminator.module.load_state_dict(torch.load(path_discriminator))


    def load_partial_weights(self, path_encoder_decoder: str, path_discriminator: str):
        """
        部分加载模型权重，支持权重名称映射
        
        参数:
            path_encoder_decoder: 编码器-解码器模型路径
            path_discriminator: 判别器模型路径
        """
        # 加载预训练权重
        pretrained_ed = torch.load(path_encoder_decoder)  
        pretrained_dis = torch.load(path_discriminator)  
        
        # 获取当前模型的状态字典 
        current_ed = self.encoder_decoder.module.state_dict() 
        current_dis = self.discriminator.module.state_dict() 
        
        # 创建名称映射字典
        name_mapping = {
            'decoder_C': 'decoder'  # 将旧的decoder_C映射到新的decoder
        }
        
        # 处理编码器-解码器权重 
        new_pretrained_ed = {} 
        for k, v in pretrained_ed.items():
            # 跳过decoder_RF相关的权重
            if 'decoder_RF' in k:
                continue
            
            # 应用名称映射
            new_k = k
            for old_name, new_name in name_mapping.items():
                if old_name in k:
                    new_k = k.replace(old_name, new_name)
                    break
                
            # 只保留形状匹配的权重
            if new_k in current_ed and current_ed[new_k].shape == v.shape:
                new_pretrained_ed[new_k] = v
        
        # 更新当前模型的状态字典
        current_ed.update(new_pretrained_ed)
        
        # 加载更新后的状态字典
        self.encoder_decoder.module.load_state_dict(current_ed, strict=False)
        
        # 加载判别器权重
        self.discriminator.module.load_state_dict(pretrained_dis, strict=False)
        
        # 打印加载信息
        print(f"Loaded {len(new_pretrained_ed)}/{len(current_ed)} encoder-decoder parameters")
        print(f"Loaded {len(pretrained_dis)}/{len(current_dis)} discriminator parameters")

    def psnr(self, img1, img2):
        """
        计算峰值信噪比
        
        参数:
            img1: 第一张图像
            img2: 第二张图像
            
        返回:
            psnr: 峰值信噪比
        """
        # 确保图像值在[0,1]范围内
        img1 = torch.clamp(img1, 0, 1)
        img2 = torch.clamp(img2, 0, 1)
        
        # 计算MSE
        mse = torch.mean((img1 - img2) ** 2)
        if mse == 0:
            return torch.tensor(float('inf'), device=img1.device)
        
        # 使用标准PSNR公式，确保所有操作都在张量上进行
        max_pixel = torch.tensor(1.0, device=img1.device)  # 创建张量而不是使用浮点数
        psnr = 20 * torch.log10(max_pixel) - 10 * torch.log10(mse)
        return psnr
    

