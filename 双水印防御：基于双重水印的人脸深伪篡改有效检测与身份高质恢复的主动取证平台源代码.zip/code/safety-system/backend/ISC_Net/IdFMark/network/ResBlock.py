"""
残差块实现，包含多种注意力机制。

本模块提供了不同类型的残差块（BasicBlock和BottleneckBlock），
支持可选的注意力机制（SE、CBAM、Coord）用于深度神经网络。
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from .Attention import SEAttention, CBAMAttention, CoordAttention

# 对应ResNet-18/34中的基础残差块
class BasicBlock(nn.Module):
    """基础残差块实现。
    
    该块由两个3x3卷积层和可选的注意力机制组成。
    适用于较浅层的网络。
    
    属性:
        change (nn.Sequential): 用于维度匹配的可选1x1卷积
        left (nn.Sequential): 包含两个3x3卷积的主路径
        attention (nn.Module): 可选的注意力机制
    """
    
    def __init__(self, in_channels, out_channels, reduction, stride, attention=None):
        """初始化BasicBlock。
        
        参数:
            in_channels (int): 输入通道数
            out_channels (int): 输出通道数
            reduction (int): 注意力机制的缩减比例
            stride (int): 第一个卷积的步长
            attention (str, optional): 注意力机制类型 ('se', 'cbam', 'coord')
        """
        super(BasicBlock, self).__init__()

        self.change = None
        if (in_channels != out_channels or stride != 1):
            self.change = nn.Sequential(
                nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=1, padding=0,
                          stride=stride, bias=False),
                nn.InstanceNorm2d(out_channels)
            )

        self.left = nn.Sequential(
            nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=3, padding=1,
                      stride=stride, bias=False),
            nn.InstanceNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels=out_channels, out_channels=out_channels, kernel_size=3, padding=1, bias=False),
            nn.InstanceNorm2d(out_channels)
        )

        if attention == 'se':
            print('基础残差块使用SEAttention')
            self.attention = SEAttention(in_channels=out_channels, out_channels=out_channels, reduction=reduction)
        elif attention == 'cbam':
            print('基础残差块使用CBAMAttention')
            self.attention = CBAMAttention(in_channels=out_channels, out_channels=out_channels, reduction=reduction)
        elif attention == 'coord':
            print('基础残差块使用CoordAttention')
            self.attention = CoordAttention(in_channels=out_channels, out_channels=out_channels, reduction=reduction)
        else:
            print('基础残差块使用Identity')
            self.attention = nn.Identity()

    def forward(self, x):
        """BasicBlock的前向传播。
        
        参数:
            x (torch.Tensor): 输入张量
            
        返回:
            torch.Tensor: 经过残差连接和激活后的输出张量
        """
        identity = x
        x = self.left(x)
        x = self.attention(x)

        if self.change is not None:
            identity = self.change(identity)

        x += identity
        return F.relu(x)

# 对应ResNet-50/101/152中的瓶颈残差块
class BottleneckBlock(nn.Module):
    """瓶颈残差块实现。
    
    该块由三个卷积层（1x1、3x3、1x1）和可选的注意力机制组成。
    适用于深层网络，可以降低计算复杂度。
    
    属性:
        change (nn.Sequential): 用于维度匹配的可选1x1卷积
        left (nn.Sequential): 包含三个卷积的主路径
        attention (nn.Module): 可选的注意力机制
    """
    
    def __init__(self, in_channels, out_channels, reduction, stride, attention=None):
        """初始化BottleneckBlock。
        
        参数:
            in_channels (int): 输入通道数
            out_channels (int): 输出通道数
            reduction (int): 注意力机制的缩减比例
            stride (int): 第一个卷积的步长
            attention (str, optional): 注意力机制类型 ('se', 'cbam', 'coord')
        """
        super(BottleneckBlock, self).__init__()

        self.change = None
        if (in_channels != out_channels or stride != 1):
            self.change = nn.Sequential(
                nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=1, padding=0,
                          stride=stride, bias=False),
                nn.InstanceNorm2d(out_channels)
            )

        self.left = nn.Sequential(
            nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=1,
                      stride=stride, padding=0, bias=False),
            nn.InstanceNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels=out_channels, out_channels=out_channels, kernel_size=3, padding=1, bias=False),
            nn.InstanceNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels=out_channels, out_channels=out_channels, kernel_size=1, padding=0, bias=False),
            nn.InstanceNorm2d(out_channels)
        )

        if attention == 'se':
            print('瓶颈残差块使用SEAttention')
            self.attention = SEAttention(in_channels=out_channels, out_channels=out_channels, reduction=reduction)
        elif attention == 'cbam':
            print('瓶颈残差块使用CBAMAttention')
            self.attention = CBAMAttention(in_channels=out_channels, out_channels=out_channels, reduction=reduction)
        elif attention == 'coord':
            print('瓶颈残差块使用CoordAttention')
            self.attention = CoordAttention(in_channels=out_channels, out_channels=out_channels, reduction=reduction)
        else:
            print('瓶颈残差块使用Identity')
            self.attention = nn.Identity()

    def forward(self, x):
        """BottleneckBlock的前向传播。
        
        参数:
            x (torch.Tensor): 输入张量
            
        返回:
            torch.Tensor: 经过残差连接和激活后的输出张量
        """
        identity = x
        x = self.left(x)
        x = self.attention(x)

        if self.change is not None:
            identity = self.change(identity)

        x += identity
        return F.relu(x)


class ResBlock(nn.Module):
    """残差块容器，用于构建深层网络。
    
    该类创建一系列残差块（BasicBlock或BottleneckBlock），
    支持可选的注意力机制。
    
    属性:
        layers (nn.Sequential): 残差块序列
    """
    
    def __init__(self, in_channels, out_channels, blocks=1, block_type="BottleneckBlock", reduction=8, stride=1, attention=None):
        """初始化ResBlock。
        
        参数:
            in_channels (int): 输入通道数
            out_channels (int): 输出通道数
            blocks (int): 要创建的残差块数量
            block_type (str): 残差块类型 ('BasicBlock' 或 'BottleneckBlock')
            reduction (int): 注意力机制的缩减比例
            stride (int): 第一个块的步长
            attention (str, optional): 注意力机制类型 ('se', 'cbam', 'coord')
        """
        super(ResBlock, self).__init__()

        layers = [eval(block_type)(in_channels, out_channels, reduction, stride, attention=attention)] if blocks != 0 else []
        for _ in range(blocks - 1):
            layer = eval(block_type)(out_channels, out_channels, reduction, 1, attention=attention)
            layers.append(layer)

        self.layers = nn.Sequential(*layers)

    def forward(self, x):
        """ResBlock的前向传播。
        
        参数:
            x (torch.Tensor): 输入张量
            
        返回:
            torch.Tensor: 经过所有残差块后的输出张量
        """
        return self.layers(x)

