import torch
from .ConvBlock import ConvBlock
import torch.nn as nn
import torch.nn.functional as F

class Down(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, blocks: int):
        """
        初始化 Down 模块（下采样块）。

        Args:
            in_channels (int): 输入通道数。
            out_channels (int): 输出通道数。
            blocks (int): ConvBlock 中的块数。
        """
        super(Down, self).__init__()
        self.layer = torch.nn.Sequential(
            ConvBlock(in_channels, in_channels, stride=2),
            ConvBlock(in_channels, out_channels, blocks=blocks)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Down 模块的前向传播。

        Args:
            x (torch.Tensor): 输入张量。

        Returns:
            torch.Tensor: 输出张量。
        """
        return self.layer(x)


class UP(nn.Module):
    def __init__(self, in_channels: int, out_channels: int):
           """
           初始化 UP 模块（上采样块）。
   
           Args:
               in_channels (int): 输入通道数。
               out_channels (int): 输出通道数。
           """
           super(UP, self).__init__()
           self.conv = ConvBlock(in_channels, out_channels)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
           """
           UP 模块的前向传播。
   
           Args:
               x (torch.Tensor): 输入张量。
   
           Returns:
               torch.Tensor: 输出张量。
           """
           x = F.interpolate(x, scale_factor=2, mode='nearest')
           return self.conv(x)
