import torch.nn as nn
import torch

class ConvINRelu(nn.Module):
	"""
	序列模块：卷积 + 实例归一化 + ReLU激活 
	"""

	def __init__(self, channels_in: int, channels_out: int, stride: int):
		"""
	       初始化 ConvINRelu 模块。

	       Args:
	           channels_in (int): 输入通道数。
	           channels_out (int): 输出通道数。
	           stride (int): 卷积步长。
	       """
		super(ConvINRelu, self).__init__()

		self.layers = nn.Sequential(
			nn.Conv2d(channels_in, channels_out, 3, stride, padding=1),
			nn.InstanceNorm2d(channels_out),
			nn.ReLU(inplace=True)
		)

	def forward(self, x: torch.Tensor) -> torch.Tensor:
		"""
	       ConvINRelu 模块的前向传播。

	       Args:
	           x (torch.Tensor): 输入张量。

	       Returns:
	           torch.Tensor: 输出张量。
	       """
		return self.layers(x)


class ConvBlock(nn.Module):
	"""
 	堆叠多个ConvINRelu：
    第一个改变通道数，其余不改变通道数
    """
	def __init__(self, in_channels, out_channels, blocks=1, stride=1):
		"""
		初始化 ConvBlock 模块。

		Args:
			in_channels (int): 输入通道数。
			out_channels (int): 输出通道数。
			blocks (int, optional): 卷积序列模块数量。默认为 1。
			stride (int, optional): 卷积步长。默认为 1。
		"""
		super(ConvBlock, self).__init__()

		layers = [ConvINRelu(in_channels, out_channels, stride)] if blocks != 0 else []
		for _ in range(blocks - 1):
			layer = ConvINRelu(out_channels, out_channels, 1)
			layers.append(layer)

		self.layers = nn.Sequential(*layers)

	def forward(self, x: torch.Tensor) -> torch.Tensor:
		"""
	       ConvBlock 模块的前向传播。

	       Args:
	           x (torch.Tensor): 输入张量。

	       Returns:
	           torch.Tensor: 输出张量。
	       """
		return self.layers(x)
