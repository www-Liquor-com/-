from . import *
import torch.nn as nn


class Patch_Discriminator(nn.Module):
    """PatchGAN判别器网络
    
    基于PatchGAN架构的判别器，用于判断图像局部区域的真伪。
    通过卷积层逐步提取特征，最终输出每个patch的真伪判断。
    
    属性:
        model (nn.Sequential): 判别器网络模型
    """

    def __init__(self, in_channels=3, ndf=64, n_layers=3):
        """
        初始化PatchGAN判别器
        
        参数:
            in_channels (int): 输入图像的通道数，默认为3（RGB图像）
            ndf (int): 第一层卷积的通道数，默认为64
            n_layers (int): 中间卷积层的数量，默认为3
        """
        super(Patch_Discriminator, self).__init__()

        # 构建判别器网络
        layers = []

        # 第一层：输入层
        # 使用4x4卷积核，步长为2，padding为1，进行下采样
        layers.append(nn.Conv2d(in_channels, ndf, kernel_size=4, stride=2, padding=1))
        layers.append(nn.LeakyReLU(0.2, inplace=True))

        # 中间层：特征提取层 
        # 每层通道数翻倍，但最大不超过8倍 
        nf_mult = 1
        for n in range(1, n_layers):
            nf_mult_prev = nf_mult
            nf_mult = min(2 ** n, 8)
            layers.append(nn.Conv2d(ndf * nf_mult_prev, ndf * nf_mult, kernel_size=4, stride=2, padding=1))
            layers.append(nn.BatchNorm2d(ndf * nf_mult))
            layers.append(nn.LeakyReLU(0.2, inplace=True))

        # 最后一层：特征映射层 
        # 保持特征图大小不变，继续增加通道数 
        nf_mult_prev = nf_mult
        nf_mult = min(2 ** n_layers, 8)
        layers.append(nn.Conv2d(ndf * nf_mult_prev, ndf * nf_mult, kernel_size=4, stride=1, padding=1))
        layers.append(nn.BatchNorm2d(ndf * nf_mult))
        layers.append(nn.LeakyReLU(0.2, inplace=True))

        # 输出层：判别层 
        # 输出每个patch的真伪判断（1表示真，0表示假）
        layers.append(nn.Conv2d(ndf * nf_mult, 1, kernel_size=4, stride=1, padding=1))

        # 将所有层组合成序列
        self.model = nn.Sequential(*layers)

    def forward(self, x):
        """
        前向传播函数
        
        参数:
            x (torch.Tensor): 输入图像张量
            
        返回:
            torch.Tensor: 每个patch的真伪判断结果
        """
        return self.model(x)

    def loss(self, fake_images, real_images, is_real=False):
        """
        计算判别器损失
        
        参数:
            fake_images: 生成的图像
            real_images: 真实图像
            is_real: 是否为真实图像
            
        返回:
            loss: 判别器损失
        """
        if is_real:
            # 生成器希望判别器将生成的图像判断为真实
            fake_pred = self.forward(fake_images)
            loss = torch.mean((fake_pred - 1) ** 2)
        else:
            # 判别器希望将真实图像判断为真实，生成的图像判断为假
            real_pred = self.forward(real_images)
            fake_pred = self.forward(fake_images.detach())
            real_loss = torch.mean((real_pred - 1) ** 2)
            fake_loss = torch.mean(fake_pred ** 2)
            loss = (real_loss + fake_loss) / 2
        return loss


