import torch
import torch.nn as nn

class SEAttention(nn.Module):
    """
    Squeeze-and-Excitation注意力机制模块。

    该模块通过自适应池化和全连接层学习通道间的依赖关系，
    增强重要通道的特征表示，抑制不重要通道的特征表示。

    Attributes:
        se (nn.Sequential): 包含池化、卷积和激活函数的序列模块。
    """

    def __init__(self, in_channels, out_channels, reduction=8):
        """
        初始化SE注意力模块。

        Args:
            in_channels (int): 输入通道数。
            out_channels (int): 输出通道数。
            reduction (int, optional): 通道压缩比例。默认为8。
        """
        super(SEAttention, self).__init__()
        self.se = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Conv2d(in_channels=in_channels, out_channels=out_channels // reduction, kernel_size=1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels=out_channels // reduction, out_channels=out_channels, kernel_size=1, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        """
        前向传播函数。

        Args:
            x (torch.Tensor): 输入特征图，形状为 [B, C, H, W]。

        Returns:
            torch.Tensor: 经过通道注意力加权后的特征图。
        """
        x = self.se(x) * x
        return x


class ChannelAttention(nn.Module):
    """
    通道注意力机制模块。

    该模块通过最大池化和平均池化提取通道特征，
    然后通过共享MLP学习通道间的依赖关系。

    Attributes:
        avg_pool (nn.AdaptiveAvgPool2d): 平均池化层。
        max_pool (nn.AdaptiveMaxPool2d): 最大池化层。
        fc (nn.Sequential): 共享MLP网络。
        sigmoid (nn.Sigmoid): Sigmoid激活函数。
    """

    def __init__(self, in_channels, out_channels, reduction=8):
        """
        初始化通道注意力模块。

        Args:
            in_channels (int): 输入通道数。
            out_channels (int): 输出通道数。
            reduction (int, optional): 通道压缩比例。默认为8。
        """
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d((1, 1))
        self.max_pool = nn.AdaptiveMaxPool2d((1, 1))

        self.fc = nn.Sequential(nn.Conv2d(in_channels=in_channels, out_channels=out_channels // reduction, kernel_size=1, bias=False),
                                nn.ReLU(inplace=True),
                                nn.Conv2d(in_channels=out_channels // reduction, out_channels=out_channels, kernel_size=1, bias=False))
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        """
        前向传播函数。

        Args:
            x (torch.Tensor): 输入特征图，形状为 [B, C, H, W]。

        Returns:
            torch.Tensor: 通道注意力权重。
        """
        avg_out = self.fc(self.avg_pool(x))
        max_out = self.fc(self.max_pool(x))
        out = avg_out + max_out
        return self.sigmoid(out)


class SpatialAttention(nn.Module):
    """
    空间注意力机制模块。

    该模块通过通道维度的最大池化和平均池化提取空间特征，
    然后通过卷积层学习空间位置的依赖关系。

    Attributes:
        conv1 (nn.Conv2d): 空间特征提取卷积层。
        sigmoid (nn.Sigmoid): Sigmoid激活函数。
    """

    def __init__(self, kernel_size=7):
        """
        初始化空间注意力模块。

        Args:
            kernel_size (int, optional): 卷积核大小。默认为7。
        """
        super(SpatialAttention, self).__init__()

        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=kernel_size // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        """
        前向传播函数。

        Args:
            x (torch.Tensor): 输入特征图，形状为 [B, C, H, W]。

        Returns:
            torch.Tensor: 空间注意力权重。
        """
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = torch.cat([avg_out, max_out], dim=1)
        x = self.conv1(x)
        return self.sigmoid(x)


class CBAMAttention(nn.Module):
    """
    卷积块注意力模块(Convolutional Block Attention Module)。

    该模块结合了通道注意力和空间注意力机制，
    通过两个注意力模块的级联增强特征表示。

    Attributes:
        ca (ChannelAttention): 通道注意力模块。
        sa (SpatialAttention): 空间注意力模块。
    """

    def __init__(self, in_channels, out_channels, reduction=8):
        """
        初始化CBAM注意力模块。

        Args:
            in_channels (int): 输入通道数。
            out_channels (int): 输出通道数。
            reduction (int, optional): 通道压缩比例。默认为8。
        """
        super(CBAMAttention, self).__init__()
        self.ca = ChannelAttention(in_channels=in_channels, out_channels=out_channels, reduction=reduction)
        self.sa = SpatialAttention()

    def forward(self, x):
        """
        前向传播函数。

        Args:
            x (torch.Tensor): 输入特征图，形状为 [B, C, H, W]。

        Returns:
            torch.Tensor: 经过通道和空间注意力加权后的特征图。
        """
        x = self.ca(x) * x
        x = self.sa(x) * x
        return x


class h_sigmoid(nn.Module):
    """
    改进的Sigmoid激活函数。

    该激活函数通过ReLU6实现，输出范围在[0,1]之间。
    """

    def __init__(self, inplace=True):
        """
        初始化h_sigmoid模块。

        Args:
            inplace (bool, optional): 是否原地操作。默认为True。
        """
        super(h_sigmoid, self).__init__()
        self.relu = nn.ReLU6(inplace=inplace)

    def forward(self, x):
        """
        前向传播函数。

        Args:
            x (torch.Tensor): 输入张量。

        Returns:
            torch.Tensor: 激活后的张量。
        """
        return self.relu(x + 3) / 6


class h_swish(nn.Module):
    """
    改进的Swish激活函数。

    该激活函数结合了线性变换和Sigmoid激活。
    """

    def __init__(self, inplace=True):
        """
        初始化h_swish模块。

        Args:
            inplace (bool, optional): 是否原地操作。默认为True。
        """
        super(h_swish, self).__init__()
        self.sigmoid = h_sigmoid(inplace=inplace)

    def forward(self, x):
        """
        前向传播函数。

        Args:
            x (torch.Tensor): 输入张量。

        Returns:
            torch.Tensor: 激活后的张量。
        """
        return x * self.sigmoid(x)


class CoordAttention(nn.Module):
    """
    坐标注意力机制模块。

    该模块通过水平和垂直方向的池化操作提取位置信息，
    然后通过卷积层学习位置间的依赖关系。

    Attributes:
        pool_w (nn.AdaptiveAvgPool2d): 宽度方向的池化层。
        pool_h (nn.AdaptiveAvgPool2d): 高度方向的池化层。
        conv1 (nn.Conv2d): 特征提取卷积层。
        bn1 (nn.InstanceNorm2d): 实例归一化层。
        act1 (h_swish): 激活函数。
        conv2 (nn.Conv2d): 水平方向注意力卷积层。
        conv3 (nn.Conv2d): 垂直方向注意力卷积层。
    """

    def __init__(self, in_channels, out_channels, reduction=8):
        """
        初始化坐标注意力模块。

        Args:
            in_channels (int): 输入通道数。
            out_channels (int): 输出通道数。
            reduction (int, optional): 通道压缩比例。默认为8。
        """
        super(CoordAttention, self).__init__()
        self.pool_w, self.pool_h = nn.AdaptiveAvgPool2d((1, None)), nn.AdaptiveAvgPool2d((None, 1))
        temp_c = max(8, in_channels // reduction)
        self.conv1 = nn.Conv2d(in_channels, temp_c, kernel_size=1, stride=1, padding=0)

        self.bn1 = nn.InstanceNorm2d(temp_c)
        self.act1 = h_swish()

        self.conv2 = nn.Conv2d(temp_c, out_channels, kernel_size=1, stride=1, padding=0)
        self.conv3 = nn.Conv2d(temp_c, out_channels, kernel_size=1, stride=1, padding=0)

    def forward(self, x):
        """
        前向传播函数。

        Args:
            x (torch.Tensor): 输入特征图，形状为 [B, C, H, W]。

        Returns:
            torch.Tensor: 经过坐标注意力加权后的特征图。
        """
        short = x
        n, c, H, W = x.shape
        x_h, x_w = self.pool_h(x), self.pool_w(x).permute(0, 1, 3, 2)
        x_cat = torch.cat([x_h, x_w], dim=2)
        out = self.act1(self.bn1(self.conv1(x_cat)))
        x_h, x_w = torch.split(out, [H, W], dim=2)
        x_w = x_w.permute(0, 1, 3, 2)
        out_h = torch.sigmoid(self.conv2(x_h))
        out_w = torch.sigmoid(self.conv3(x_w))
        return short * out_w * out_h 