from . import *
import torch.nn as nn
from .ConvBlock import ConvBlock
from .Sampling_Layer import Down, UP

class Decoder(nn.Module):
    """U-Net风格的解码器网络"""

    def __init__(self, message_length: int, blocks: int = 2, channels: int = 64, attention: str = 'none'):
           """
           初始化 DW_Decoder 模块。
    
           Args:
               message_length (int): 消息的长度。
               blocks (int, optional): 每个 ResBlock 中的块数。默认为 2。
               channels (int, optional): 基础通道数。默认为 64。
               attention (str, optional): 使用的注意力机制类型 ('se', 'cbam', 'coord', 'none')。默认为 'none'。
           """
           super(Decoder, self).__init__()
           self.expand_size = 128 # 从512维度扩展到128*128维
           self.attention = attention
           
           self.conv1 = ConvBlock(3, 16, blocks=blocks)
           self.down1 = Down(16, 32, blocks=blocks)
           self.down2 = Down(32, 64, blocks=blocks)
           self.down3 = Down(64, 128, blocks=blocks)
   
           self.down4 = Down(128, 256, blocks=blocks)
    
           self.up3 = UP(256, 128) 
           self.att3 = ResBlock(128 * 2, 128, blocks=blocks, attention=attention) 
    
           self.up2 = UP(128, 64) 
           self.att2 = ResBlock(64 * 2, 64, blocks=blocks, attention=attention) 
   
           self.up1 = UP(64, 32) 
           self.att1 = ResBlock(32 * 2, 32, blocks=blocks, attention=attention) 
   
           self.up0 = UP(32, 16)
           self.att0 = ResBlock(16 * 2, 16, blocks=blocks, attention=attention)

           self.Conv_1x1 = nn.Conv2d(16, 1, kernel_size=1, stride=1, padding=0, bias=False)
   
           self.message_layer = nn.Linear(self.expand_size * self.expand_size, message_length)
           self.message_length = message_length
    
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
           """
           DW_Decoder 模块的前向传播。
   
           Args:
               x (torch.Tensor): 输入的含水印图像张量。
   
           Returns:
               torch.Tensor: 解码后的消息张量。
           """
           d0 = self.conv1(x)
           d1 = self.down1(d0)
           d2 = self.down2(d1)
           d3 = self.down3(d2)
   
           d4 = self.down4(d3)
   
           u3 = self.up3(d4)
           u3 = torch.cat((d3, u3), dim=1)
           u3 = self.att3(u3)
   
           u2 = self.up2(u3)
           u2 = torch.cat((d2, u2), dim=1)
           u2 = self.att2(u2)
   
           u1 = self.up1(u2)
           u1 = torch.cat((d1, u1), dim=1)
           u1 = self.att1(u1)
   
           u0 = self.up0(u1)
           u0 = torch.cat((d0, u0), dim=1)
           u0 = self.att0(u0)
   
           residual = self.Conv_1x1(u0)
   
           message = F.interpolate(residual, size=(self.expand_size, self.expand_size), 
                                                              mode='nearest')
           message = message.view(message.shape[0], -1)
           message = self.message_layer(message)
   
           return message 


