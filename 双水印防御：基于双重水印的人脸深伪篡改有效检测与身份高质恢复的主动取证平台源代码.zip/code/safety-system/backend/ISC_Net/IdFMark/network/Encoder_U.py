from . import *
from .Sampling_Layer import Down, UP

class Encoder(nn.Module):
    """
    U-Net风格的编码器网络，用于将水印信息嵌入到图像中。

    该编码器采用U-Net结构，包含下采样和上采样路径，并在上采样过程中融合水印信息。
    通过多级特征融合和注意力机制，实现水印的鲁棒嵌入。

    Attributes:
        conv1 (ConvBlock): 初始卷积块，用于提取基础特征。
        down1-4 (Down): 下采样模块，逐步提取深层特征。
        up0-3 (UP): 上采样模块，用于特征重建。
        linear0-3 (nn.Linear): 线性层，用于水印信息的维度变换。
        Conv_message0-3 (ConvBlock): 水印信息处理模块。
        att0-3 (ResBlock): 注意力模块，用于特征融合。
        Conv_1x1 (nn.Conv2d): 1x1卷积，用于最终特征融合。
        message_length (int): 水印信息的长度。
        transform (transforms.Compose): 图像预处理转换。
    """

    def __init__(self, message_length, blocks=2, channels=64, attention=None):
        """
        初始化编码器网络。

        Args:
            message_length (int): 水印信息的长度。
            blocks (int, optional): 每个卷积块中的卷积层数量。默认为2。
            channels (int, optional): 水印信息处理通道数。默认为64。
            attention (str, optional): 注意力机制类型。默认为None。
        """
        super(Encoder, self).__init__()
        self.expand_size = 128 # 从512维度扩展到128*128维
        # 下采样路径
        self.conv1 = ConvBlock(3, 16, blocks=blocks)
        self.down1 = Down(16, 32, blocks=blocks)
        self.down2 = Down(32, 64, blocks=blocks)
        self.down3 = Down(64, 128, blocks=blocks)
        self.down4 = Down(128, 256, blocks=blocks)

        # 上采样路径
        self.up3 = UP(256, 128)
        self.linear3 = nn.Linear(message_length, self.expand_size * self.expand_size)
        self.Conv_message3 = ConvBlock(1, channels, blocks=blocks)
        self.att3 = ResBlock(128 * 2 + channels, 128, blocks=blocks, attention=attention)

        self.up2 = UP(128, 64)
        self.linear2 = nn.Linear(message_length, self.expand_size * self.expand_size)
        self.Conv_message2 = ConvBlock(1, channels, blocks=blocks)
        self.att2 = ResBlock(64 * 2 + channels, 64, blocks=blocks, attention=attention)

        self.up1 = UP(64, 32)
        self.linear1 = nn.Linear(message_length, self.expand_size * self.expand_size)
        self.Conv_message1 = ConvBlock(1, channels, blocks=blocks)
        self.att1 = ResBlock(32 * 2 + channels, 32, blocks=blocks, attention=attention)

        self.up0 = UP(32, 16)
        self.linear0 = nn.Linear(message_length, self.expand_size * self.expand_size)
        self.Conv_message0 = ConvBlock(1, channels, blocks=blocks)
        self.att0 = ResBlock(16 * 2 + channels, 16, blocks=blocks, attention=attention)

        # 最终特征融合
        self.Conv_1x1 = nn.Conv2d(16 + 3, 3, kernel_size=1, stride=1, padding=0)

        self.message_length = message_length

        # 图像预处理
        self.transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
        ])

    def forward(self, x, watermark):
        """
        前向传播函数，将水印信息嵌入到图像中。

        Args:
            x (torch.Tensor): 输入图像，形状为 [B, 3, H, W]。
            watermark (torch.Tensor): 水印信息，形状为 [B, message_length]。

        Returns:
            torch.Tensor: 嵌入水印后的图像，形状为 [B, 3, H, W]。
        """
        # 下采样路径
        d0 = self.conv1(x)
        d1 = self.down1(d0)
        d2 = self.down2(d1)
        d3 = self.down3(d2)
        d4 = self.down4(d3)

        # 上采样路径，融合水印信息
        u3 = self.up3(d4)
        expanded_message = self.linear3(watermark)
        expanded_message = expanded_message.view(-1, 1, self.expand_size, self.expand_size)
        expanded_message = F.interpolate(expanded_message, size=(d3.shape[2], d3.shape[3]),
                                                           mode='nearest')
        expanded_message = self.Conv_message3(expanded_message)
        u3 = torch.cat((d3, u3, expanded_message), dim=1)
        u3 = self.att3(u3)

        u2 = self.up2(u3)
        expanded_message = self.linear2(watermark)
        expanded_message = expanded_message.view(-1, 1, self.expand_size, self.expand_size)
        expanded_message = F.interpolate(expanded_message, size=(d2.shape[2], d2.shape[3]),
                                                           mode='nearest')
        expanded_message = self.Conv_message2(expanded_message)
        u2 = torch.cat((d2, u2, expanded_message), dim=1)
        u2 = self.att2(u2)

        u1 = self.up1(u2)
        expanded_message = self.linear1(watermark)
        expanded_message = expanded_message.view(-1, 1, self.expand_size, self.expand_size)
        expanded_message = F.interpolate(expanded_message, size=(d1.shape[2], d1.shape[3]),
                                                           mode='nearest')
        expanded_message = self.Conv_message1(expanded_message)
        u1 = torch.cat((d1, u1, expanded_message), dim=1)
        u1 = self.att1(u1)

        u0 = self.up0(u1)
        expanded_message = self.linear0(watermark)
        expanded_message = expanded_message.view(-1, 1, self.expand_size, self.expand_size)
        expanded_message = F.interpolate(expanded_message, size=(d0.shape[2], d0.shape[3]),
                                                           mode='nearest')
        expanded_message = self.Conv_message0(expanded_message)
        u0 = torch.cat((d0, u0, expanded_message), dim=1)
        u0 = self.att0(u0)

        # 最终特征融合和输出
        image = self.Conv_1x1(torch.cat((x, u0), dim=1))

        # 处理图像范围，确保输出在[-1, 1]范围内
        forward_image = image.clone().detach()
        gap = forward_image.clamp(-1, 1) - forward_image

        return image + gap

