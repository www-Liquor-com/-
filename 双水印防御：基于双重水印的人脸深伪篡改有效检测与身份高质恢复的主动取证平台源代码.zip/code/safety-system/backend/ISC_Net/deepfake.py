import os
import torch
import numpy as np
from PIL import Image
from torchvision import transforms
import lpips
from skimage.metrics import peak_signal_noise_ratio, structural_similarity
import torch.nn.functional as F
import pickle 
import sys
# from .insightface_func.face_detect_crop_single import Face_detect_crop
from .Noise import *
import cv2
import argparse
import concurrent.futures
import hashlib,time
def set_seed(seed=42):
    """
    固定全局随机种子，确保实验可重复性
    """
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    os.environ['PYTHONHASHSEED'] = str(seed)

# 设置随机种子，保证实验结果可复现
set_seed(42) 


# # 添加项目根目录到 Python 路径
# project_root = os.path.dirname(os.path.abspath(__file__))
# sys.path.append(project_root)

os.environ["TORCH_HOME"] = "E:/torch_cache"  # 设置PyTorch模型缓存路径

def save_image(tensor, path):
    """保存图像"""
    # 输入图像[-1,1]
    image = tensor.squeeze(0).permute(1, 2, 0).cpu().numpy()
    image = ((image + 1) / 2 * 255).astype(np.uint8)
    Image.fromarray(image).save(path)



import lpips  # pip install lpips

lpips_model = lpips.LPIPS().eval()
if torch.cuda.is_available():
    lpips_model = lpips_model.cuda()



def deepfake_simswap(img_list, save_folder):
    """
    对图像列表进行SimSwap深度伪造.
    :param img_list: 使用OpenCV读取的图像列表 (BGR格式).
    :param save_folder: 保存伪造图像的文件夹.
    :return: 保存的伪造图像路径列表.
    """
    # 设置设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # 初始化SimSwap模型
    model = SimSwap(mode='test').to(device)
    model.eval()

    # 定义图像变换
    transform = transforms.Compose([
        transforms.ToTensor(),  # 将PIL图像或numpy数组(H,W,C)从[0,255]转为(C,H,W)的[0,1]张量
        transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])  # 归一化到[-1,1]
    ])

    # 预处理图像并创建批次
    batch_tensors = []
    for img_cv2 in img_list:
        # OpenCV读取的是BGR, 转换为RGB
        img_rgb = cv2.cvtColor(img_cv2, cv2.COLOR_BGR2RGB)
        # 转换为PIL图像以应用变换
        img_pil = Image.fromarray(img_rgb)
        # 应用变换
        tensor = transform(img_pil)
        batch_tensors.append(tensor)

    if not batch_tensors:
        return []

    batch = torch.stack(batch_tensors, dim=0).to(device)

    # 执行换脸
    with torch.no_grad():
        results = model(batch)

    # 保存结果并收集路径
    saved_paths = []
    os.makedirs(save_folder, exist_ok=True)
    for i in range(results.size(0)):
        timestamp = str(int(time.time() * 1000))  # 毫秒级时间戳
        image_hash = hashlib.md5(results[i].cpu().numpy().tobytes()).hexdigest()[:8]  # 图像内容的MD5哈希前8位
        unique_id = f"{timestamp}_{image_hash}" 

        
        save_path = os.path.join(save_folder, f"{unique_id}_simswap_image.png")
        # save_image需要一个4D张量(B,C,H,W), 我们切片以保持维度 
        save_image(results[i:i+1], save_path)
        saved_paths.append(save_path) 
        
    return saved_paths[0]
    


def deepfake_infoswap(img_list, save_folder):
    # 设置设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # 初始化InfoSwap模型
    model = InfoSwap(mode='test').to(device)
    model.eval() 

    # 定义图像变换
    transform = transforms.Compose([
        transforms.ToTensor(),  # 将PIL图像或numpy数组(H,W,C)从[0,255]转为(C,H,W)的[0,1]张量
        transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])  # 归一化到[-1,1]
    ])

    # 预处理图像并创建批次
    batch_tensors = []
    for img_cv2 in img_list:
        # OpenCV读取的是BGR, 转换为RGB
        img_rgb = cv2.cvtColor(img_cv2, cv2.COLOR_BGR2RGB)
        # 转换为PIL图像以应用变换
        img_pil = Image.fromarray(img_rgb)
        # 应用变换
        tensor = transform(img_pil)
        batch_tensors.append(tensor)

    if not batch_tensors:
        return []

    batch = torch.stack(batch_tensors, dim=0).to(device)

    # 执行换脸
    with torch.no_grad():
        results = model(batch)

    # 保存结果并收集路径
    saved_paths = []
    os.makedirs(save_folder, exist_ok=True)
    for i in range(results.size(0)):
        timestamp = str(int(time.time() * 1000))  # 毫秒级时间戳
        image_hash = hashlib.md5(results[i].cpu().numpy().tobytes()).hexdigest()[:8]  # 图像内容的MD5哈希前8位
        unique_id = f"{timestamp}_{image_hash}" 

        
        save_path = os.path.join(save_folder, f"{unique_id}_infoswap_image.png")
        # save_image需要一个4D张量(B,C,H,W), 我们切片以保持维度 
        save_image(results[i:i+1], save_path)
        saved_paths.append(save_path) 
        
    return saved_paths[0]
       
    
    
def deepfake_faceshifter(img_list, save_folder): 
    # 设置设备 
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    # 初始化FaceShifter模型
    model = FaceShifter(mode='test').to(device)
    model.eval() 
    # 定义图像变换
    transform = transforms.Compose([
        transforms.ToTensor(),  # 将PIL图像或numpy数组(H,W,C)从[0,255]转为(C,H,W)的[0,1]张量
        transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])  # 归一化到[-1,1]
    ])

    # 预处理图像并创建批次
    batch_tensors = []
    for img_cv2 in img_list:
        # OpenCV读取的是BGR, 转换为RGB
        img_rgb = cv2.cvtColor(img_cv2, cv2.COLOR_BGR2RGB)
        # 转换为PIL图像以应用变换
        img_pil = Image.fromarray(img_rgb)
        # 应用变换
        tensor = transform(img_pil)
        batch_tensors.append(tensor)

    if not batch_tensors:
        return []

    batch = torch.stack(batch_tensors, dim=0).to(device)
    # 执行换脸
    with torch.no_grad():
        results = model(batch)
    # 保存结果并收集路径
    saved_paths = []
    os.makedirs(save_folder, exist_ok=True)
    for i in range(results.size(0)):
        timestamp = str(int(time.time() * 1000))  # 毫秒级时间戳
        image_hash = hashlib.md5(results[i].cpu().numpy().tobytes()).hexdigest()[:8]  # 图像内容的MD5哈希前8位
        unique_id = f"{timestamp}_{image_hash}" 
        
        save_path = os.path.join(save_folder, f"{unique_id}_faceshifter_image.png")
        # save_image需要一个4D张量(B,C,H,W), 我们切片以保持维度 
        save_image(results[i:i+1], save_path)
        saved_paths.append(save_path) 
    return saved_paths[0]



def deepfake_sdinpaint(img_list, mask_list, save_folder, prompt=None): 
    """
    对图像列表进行Stable Diffusion Inpainting人脸篡改。
    :param img_list: 使用OpenCV读取的图像列表 (BGR格式)。
    :param mask_list: 掩码图像列表 (单通道，uint8，0/255)。
    :param save_folder: 保存伪造图像的文件夹。
    :param prompt: 可选，统一的提示词（为None时每张图像自动随机）。
    :return: 保存的伪造图像路径列表。
    """
    os.makedirs(save_folder, exist_ok=True)
    sd_inpainter = SDInpaint()
    saved_paths = []
    for idx, (img_cv2, mask_cv2) in enumerate(zip(img_list, mask_list)):
        # OpenCV读取的是BGR, 转换为RGB
        img_rgb = cv2.cvtColor(img_cv2, cv2.COLOR_BGR2RGB)
        # 保证掩码为单通道uint8 
        if len(mask_cv2.shape) == 3: 
            mask_gray = cv2.cvtColor(mask_cv2, cv2.COLOR_BGR2GRAY)
        else:
            mask_gray = mask_cv2
        # 调用inpaint
        result = sd_inpainter.inpaint_face(img_rgb, mask_gray, prompt)
        if result is not None:
            result_pil = Image.fromarray((result * 255).astype(np.uint8))
            timestamp = str(int(time.time() * 1000))
            image_hash = hashlib.md5(result.tobytes()).hexdigest()[:8]
            unique_id = f"{timestamp}_{image_hash}"
            save_path = os.path.join(save_folder, f"{unique_id}_sdinpaint_image.png")
            result_pil.save(save_path)
            saved_paths.append(save_path) 
            
    return saved_paths[0] if saved_paths else None



