'''
Author: Naiyuan liu
Github: https://github.com/NNNNAI
Date: 2021-11-23 17:03:58
LastEditors: Naiyuan liu
LastEditTime: 2021-11-24 16:46:04
Description: 人脸检测和裁剪的类，用于检测图片中的人脸并进行对齐裁剪
'''
from __future__ import division
import collections
import numpy as np
import glob
import os
import os.path as osp
import cv2
from insightface.model_zoo import model_zoo
from .utils import face_align_ffhqandnewarc as face_align

__all__ = ['Face_detect_crop', 'Face']

# 定义Face命名元组，用于存储人脸相关的属性
Face = collections.namedtuple('Face', [
    'bbox', 'kps', 'det_score', 'embedding', 'gender', 'age',
    'embedding_norm', 'normed_embedding',
    'landmark'
])

# 设置Face元组所有字段的默认值为None
Face.__new__.__defaults__ = (None, ) * len(Face._fields)


class Face_detect_crop:
    """
    人脸检测和裁剪类，用于加载模型、检测人脸并进行对齐裁剪
    """
    def __init__(self, name, root='~/.insightface_func/models'):
        """
        初始化函数
        Args:
            name: 模型名称
            root: 模型文件根目录，默认为'~/.insightface_func/models'
        """
        self.models = {}  # 存储加载的模型
        root = os.path.expanduser(root)  # 展开用户目录路径
        # 获取指定目录下所有的onnx模型文件
        onnx_files = glob.glob(osp.join(root, name, '*.onnx'))
        onnx_files = sorted(onnx_files)
        
        # 遍历并加载所有onnx模型文件
        for onnx_file in onnx_files:
            # 跳过自生成的模型文件
            if onnx_file.find('_selfgen_')>0:
                continue
            # 加载模型
            model = model_zoo.get_model(onnx_file)
            # 如果该类型的模型还未加载，则保存
            if model.taskname not in self.models:
                print('find model:', onnx_file, model.taskname)
                self.models[model.taskname] = model
            # 如果已存在同类型模型，则忽略并删除
            else:
                print('duplicated model task type, ignore:', onnx_file, model.taskname)
                del model
        # 确保检测模型存在
        assert 'detection' in self.models
        self.det_model = self.models['detection']

    def prepare(self, ctx_id, det_thresh=0.5, det_size=(640, 640), mode ='None'):
        """
        准备模型，设置检测参数
        Args:
            ctx_id: 设备ID
            det_thresh: 检测阈值，默认0.5
            det_size: 检测图片大小，默认(640, 640)
            mode: 对齐模式，默认'None'
        """
        self.det_thresh = det_thresh
        self.mode = mode
        assert det_size is not None
        print('set det-size:', det_size)
        self.det_size = det_size
        # 准备所有模型
        for taskname, model in self.models.items():
            if taskname=='detection':
                model.prepare(ctx_id, input_size=det_size)
            else:
                model.prepare(ctx_id)

    def get(self, img, crop_size, max_num=0):
        """
        检测图片中的人脸并进行对齐裁剪
        Args:
            img: 输入图片
            crop_size: 裁剪后的人脸图片大小
            max_num: 最大检测人脸数量，默认0表示不限制
        Returns:
            对齐后的人脸图片列表和对应的变换矩阵列表
        """
        # 如果图片尺寸太小，进行放大处理
        if img.shape[0] < 256 or img.shape[1] < 256:
            scale = 256 / min(img.shape[0], img.shape[1])
            new_size = (int(img.shape[1] * scale), int(img.shape[0] * scale))
            img = cv2.resize(img, new_size, interpolation=cv2.INTER_LANCZOS4)
        
        # 检测人脸
        bboxes, kpss = self.det_model.detect(img, max_num=max_num)
        if bboxes.shape[0] == 0:
            return None
            
        # 获取置信度最高的人脸
        det_score = bboxes[..., 4]
        best_index = np.argmax(det_score) 
        
        # 获取人脸坐标 (x1, y1, x2, y2, score)
        face_bbox = bboxes[best_index]

        # 获取关键点
        kps = None
        if kpss is not None:
            kps = kpss[best_index]
            
        # 计算对齐变换矩阵并进行人脸对齐
        M, _ = face_align.estimate_norm(kps, crop_size, mode=self.mode)
        align_img = cv2.warpAffine(img, M, (crop_size, crop_size), borderValue=0.0)
        
        # return [align_img], [M], [face_bbox] 
        return [align_img], [M]
