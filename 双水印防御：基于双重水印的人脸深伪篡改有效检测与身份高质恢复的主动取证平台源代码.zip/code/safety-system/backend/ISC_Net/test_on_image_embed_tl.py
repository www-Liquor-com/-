import torch 
import ISC_Net.TL.options.options as option  # 配置选项

from .TL.network.model import Tamper_Loc
import math
from .TL.network.subnet import subnet 
import numpy as np
import random
from .TL.utils.load_image import load_image 
import cv2
from .TL.network.common import DWT  # 导入DWT
from .TL.utils.preprocess import preprocess_bit,preprocess_img  
from .TL.utils.save_tensor import save_tensor  
from .TL.utils.create_model import define_G  
import hashlib  
import time 

def rand(num_bits=64):
    """
    生成随机比特序列
    Args:
        num_bits: 比特序列长度，默认64位
    Returns:
        随机生成的比特序列字符串
    """
    random_str = ''.join([str(random.randint(0, 1)) for _ in range(num_bits)])
    return random_str







def embed_wm(image_input, image_input_h=None, message_input=None, save_folder=None): 
    # # 统计image_input张量的大小
    # size_list = []
    # for i in range(len(image_input)):
    #     # 获取图像的长和宽（二维尺寸）
    #     height, width = image_input[i].shape[:2]
    #     size_list.append((height, width))
    
    # 清理GPU内存
    if torch.cuda.is_available(): 
        torch.cuda.empty_cache() 

    # 加载配置选项  
    opt = option.parse("ISC_Net/TL/options/test_tl.yml", is_train=True) 
    # 分布式训练设置  
    opt['dist'] = False 
    rank = -1 
    print('Disabled distributed training.') 

    # 如果存在恢复状态，则加载 
    if opt['path'].get('resume_state', None): 
        device_id = torch.cuda.current_device() 
        resume_state = torch.load(opt['path']['resume_state'], 
                                    map_location=lambda storage, loc: storage.cuda(device_id)) 
        option.check_resume(opt, resume_state['iter']) 
    else:  
        resume_state = None  

    # 转换为NoneDict，对缺失的键返回None   
    opt = option.dict_to_nonedict(opt)   
    
    torch.backends.cudnn.benchmark = True  
    print(f"开始加载模型")  
    model = define_G(opt) 
    print(f"模型已创建: {model is not None}") 

    # 1. 选择 device
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = model.to(device)  # 2. 模型放到 device

    # 设置推理模式
    model.eval() 
    
    # 加载模型权重
    checkpoint_path = opt['path'].get('pretrain_model_G') 
    if torch.cuda.is_available():
        print("cuda可用")
        checkpoint = torch.load(checkpoint_path, map_location='cuda')
    else:
        print("cuda不可用")
        checkpoint = torch.load(checkpoint_path, map_location='cpu')
    if 'params' in checkpoint:
        print("加载params")
        model.load_state_dict(checkpoint['params'], strict=opt['path'].get('strict_load', True))
    else:
        model.load_state_dict(checkpoint, strict=opt['path'].get('strict_load', True))
    print(f"模型权重已从 {checkpoint_path} 加载")
    
    
    # 嵌入水印 ，保存图片 
    # message = preprocess_bit(message_input).to(device) 
    x_tensor, x_h_tensor = preprocess_img(image_input, image_input_h,size=256) 
    x0 = x_tensor.to(device) 
    x1 = x_h_tensor.to(device) 
    
    # 使用推理模式，禁用梯度计算
    with torch.no_grad(): 
        dwt = DWT()  # 实例化DWT 
        wm_img, out_y_h = model(dwt(x0), dwt(x1)) 

        # 使用当前时间戳和图像内容生成唯一ID
        timestamp = str(int(time.time() * 1000))  # 毫秒级时间戳
        image_hash = hashlib.md5(wm_img.cpu().numpy().tobytes()).hexdigest()[:8]  # 图像内容的MD5哈希前8位
        unique_id = f"{timestamp}_{image_hash}"
        
        print(f"生成的图像唯一编号: {unique_id}") 
        if save_folder: 
            save_path = f"{save_folder}/{unique_id}_image_wm_img.png" 
        else:
            save_path = f"temp_result/{unique_id}_image_wm_img.png" 
        save_tensor(wm_img,save_path=save_path)   

        return save_path 




if __name__ == "__main__":
    # 构建输入（只处理一张图片以减少显存压力）
    # image_input = [cv2.imread(r"E:\DataSets\IdFMark\images\test_256\00002.png")]
    # image_input_h = [cv2.imread(r"E:\DataSets\IdFMark\images\test_256\00133.png")]
    # image_input = [cv2.imread(r"E:\train_program\Tamper_Localization\temp_results\test.png")] 
    # image_input = [cv2.imread(r"E:\train_program\Tamper_Localization\temp_results\test3.png")] 
    image_input = [cv2.imread(r"E:\DataSets\IdFMark\images\test_256\00768.png")]  
    
    image_input_h = None 
    
    path = embed_wm(image_input, image_input_h)
    print(f"水印嵌入已经完成，path为{path}")


