# 导入必要的库
import os
import cv2
import torch
import numpy as np
from PIL import Image
import torch.nn.functional as F
import torchvision.transforms as transforms
import matplotlib.pyplot as plt
import random

# 导入自定义模块
from .modules.encoder128 import Backbone128  # 128x128 分辨率的编码器
from .modules.iib import IIB  # 信息隔离模块
from .modules.aii_generator import AII512  # 512x512 分辨率的生成器
from .modules.decoder512 import UnetDecoder512  # 512x512 分辨率的解码器
import onnxruntime

from ISC_Net.insightface_func.face_detect_crop_single import Face_detect_crop 
import concurrent.futures 

onnxruntime.set_default_logger_severity(3) 


def save_image_tensor(tensor: torch.Tensor, path: str):
    """ 保存单张 tensor 图像
    Args:
        tensor: 输入tensor，范围在[-1,1]之间
        path: 保存路径
    """
    img = tensor.clone().cpu()
    img = (img * 0.5 + 0.5).clamp(0, 1)  # 将[-1,1]范围转换为[0,1]
    arr = (img.numpy().transpose(1, 2, 0) * 255).astype(np.uint8)  # 转换为uint8格式
    Image.fromarray(arr).save(path)


def reverse2wholeimage(swaped_imgs, mats, crop_size, oriimgs):
    """
    Args:
        swaped_imgs: torch.Tensor, shape [B,C,H,W], range [-1,1], RGB
        mats: List[np.ndarray], length B, each is 2x3 affine transform matrix
        crop_size: int, size of cropped face
        oriimgs: torch.Tensor, shape [B,C,H,W], range [-1,1], RGB
    Returns:
        torch.Tensor, shape [B,C,H,W], range [-1,1], RGB
    """
    batch_size = swaped_imgs.shape[0]
    target_images = []
    
    for i in range(batch_size):
        # Convert from [-1,1] to [0,1] for OpenCV operations
        swaped_img = ((swaped_imgs[i].cpu().detach().numpy() + 1) / 2).transpose((1, 2, 0))
        mat = mats[i]
        oriimg = ((oriimgs[i].cpu().detach().numpy() + 1) / 2).transpose((1, 2, 0))
        
        # Create white image for mask
        img_white = np.full((crop_size, crop_size), 255, dtype=float)
        
        # Inverse the Affine transformation matrix
        mat_rev = np.zeros([2,3])
        div1 = mat[0][0]*mat[1][1]-mat[0][1]*mat[1][0]
        mat_rev[0][0] = mat[1][1]/div1
        mat_rev[0][1] = -mat[0][1]/div1
        mat_rev[0][2] = -(mat[0][2]*mat[1][1]-mat[0][1]*mat[1][2])/div1
        div2 = mat[0][1]*mat[1][0]-mat[0][0]*mat[1][1]
        mat_rev[1][0] = mat[1][0]/div2
        mat_rev[1][1] = -mat[0][0]/div2
        mat_rev[1][2] = -(mat[0][2]*mat[1][0]-mat[0][0]*mat[1][2])/div2
        
        orisize = (oriimg.shape[1], oriimg.shape[0])
        
        # Warp the swapped image
        target_image = cv2.warpAffine(swaped_img, mat_rev, orisize)
        
        # Create and process mask
        img_white = cv2.warpAffine(img_white, mat_rev, orisize)
        img_white[img_white>20] = 255
        img_mask = img_white
        
        kernel = np.ones((40,40),np.uint8)
        img_mask = cv2.erode(img_mask,kernel,iterations = 1)
        kernel_size = (20, 20)
        blur_size = tuple(2*i+1 for i in kernel_size)
        img_mask = cv2.GaussianBlur(img_mask, blur_size, 0)
        img_mask = img_mask / 255
        img_mask = np.reshape(img_mask, [img_mask.shape[0],img_mask.shape[1],1])
        
        # Blend images using mask
        target_image = target_image * img_mask + oriimg * (1 - img_mask)
        target_images.append(target_image)
    
    # Convert to tensor and normalize back to [-1,1]
    target_images = np.stack(target_images, axis=0)
    target_images = torch.from_numpy(target_images.transpose((0, 3, 1, 2))).float()
    target_images = target_images * 2 - 1  # Convert from [0,1] back to [-1,1]
    
    return target_images



class InfoSwap(torch.nn.Module):
    """InfoSwap模型类，用于人脸交换
    
    该模型使用编码器-解码器架构，通过信息隔离模块(IIB)实现身份信息和属性信息的分离
    """
    def __init__(self, source_path=r"deepfake_dataset\faces", mode='train'): # source_path为用于随机换脸的源人脸图像路径
        """初始化InfoSwap模型 
        Args:
            mode: 运行模式，'train'或'val'或'test' 
        """ 
        super(InfoSwap, self).__init__() 
        
        # 源人脸图像路径 
        if mode == 'train':
            self.src_img_path = source_path + r"\train_256" 
        elif mode == 'val':
            self.src_img_path = source_path + r"\val_256" 
        elif mode == 'test':
            self.src_img_path = source_path + r"\test_256" 
        self.mode = mode  
        
        # 设置所有预训练权重文件的路径（全部放在checkpoints_512/wo_kernel_smooth文件夹下）
        self.root_path = os.path.dirname(os.path.abspath(__file__))
        ckpt_dir = os.path.join(self.root_path, 'checkpoints_512', 'wo_kernel_smooth')
        encoder_path = os.path.join(ckpt_dir, 'model_128_ir_se50.pth')
        generator_path = os.path.join(ckpt_dir, 'ckpt_G.pth')
        decoder_path = os.path.join(ckpt_dir, 'ckpt_E.pth')
        iib_path = os.path.join(ckpt_dir, 'ckpt_I.pth')
        
        self.mode = mode  
        # 设置设备(GPU/CPU)  
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")  

        # 定义图像预处理转换 
        self.transform = transforms.Compose([  
            transforms.Resize((512, 512), interpolation=2),  # 调整图像大小
            transforms.ToTensor(),  # 转换为tensor
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))  # 标准化，像素值范围转为[-1,1]
        ])  
        
        # 初始化并加载编码器 
        self.encoder = Backbone128(50, 0.6, 'ir_se').eval().to(self.device)  
        state_dict_encoder = torch.load(encoder_path, map_location=self.device, weights_only=False)  
        self.encoder.load_state_dict(state_dict_encoder, strict=True)  
        
        # 初始化并加载生成器  
        self.G = AII512().eval().to(self.device)  
        state_dict_G = torch.load(generator_path, map_location=self.device, weights_only=False)  
        self.G.load_state_dict(state_dict_G, strict=True)  
        
        # 初始化并加载解码器  
        self.decoder = UnetDecoder512().eval().to(self.device)  
        state_dict_decoder = torch.load(decoder_path, map_location=self.device, weights_only=False)  
        self.decoder.load_state_dict(state_dict_decoder, strict=True)  

        # 初始化并加载信息隔离模块(IIB)  
        N = 10  # 特征层数  
        _ = self.encoder(torch.rand(1, 3, 128, 128).to(self.device), cache_feats=True) 
        _readout_feats = self.encoder.features[:(N + 1)] 
        in_c = sum(map(lambda f: f.shape[-3], _readout_feats))  # 计算输入通道数 
        out_c_list = [_readout_feats[i].shape[-3] for i in range(N)]  # 计算输出通道列表 
        self.iib = IIB(in_c, out_c_list, self.device, smooth='smooth', kernel_size=1).eval()  
        state_dict_iib = torch.load(iib_path, map_location=self.device, weights_only=False)  
        self.iib.load_state_dict(state_dict_iib, strict=False)  

        # 加载特征统计参数 
        self.param_dict = [] 
        for i in range(N+1):
            # readout_layer*.pth 也全部放在 checkpoints_512/wo_kernel_smooth 下
            param_path = os.path.join(ckpt_dir, f'readout_layer{i}.pth')
            state = torch.load(param_path, map_location=self.device, weights_only=False)
            n_samples = state['n_samples'].float()
            std = torch.sqrt(state['s']/(n_samples-1)).to(self.device)  # 计算标准差 
            neuron_nonzero = state['neuron_nonzero'].float()
            active_neurons = (neuron_nonzero / n_samples) > 0.01
            self.param_dict.append([state['m'].to(self.device), std, active_neurons]) 
        
        # 初始化人脸检测器 (直接使用BGR)
        # current_dir = os.path.dirname(os.path.abspath(__file__))  
        self.detector = Face_detect_crop(name='antelope', root=f'ISC_Net/insightface_func/models') 
        self.detector.prepare(ctx_id=0, det_thresh=0.1, det_size=(256,256)) 
    
    def _process_image(self, img_tensor):
        """
        批量处理图像
        img_tensor: 输入的图像tensor，形状为[B, C, H, W]，像素值范围为[-1,1]
        """
        B = img_tensor.shape[0]  # 获取批量大小 

        # 1. 随机读取多个源图像，并将其转为[B, C, H, W]
        # 获取源图像目录下的所有图像文件 
        src_list = os.listdir(self.src_img_path)
        # src_list = [f for f in src_list if f.lower().endswith(('.png', '.jpg', '.jpeg'))] # 保证路径下只有图片 
        # 随机选择B张图像 
        selected_src = random.sample(src_list, B) 
        # 使用cv2直接读取图像  
        src_images = [] 
        for src_name in selected_src:
            src_path = os.path.join(self.src_img_path, src_name)
            try:
                img = cv2.imread(src_path) 
                img = Image.fromarray(img) # 保留BGR通道 
                src_images.append(img)
            except Exception as e:
                print(f"InfoSwap加载源图像出错：{src_path}: {e}")
                continue
        # 统一进行transform处理
        if src_images:
            src_images = [self.transform(img).unsqueeze(0) for img in src_images] # 源图像转换为tensor，[B,C,H,W]，[-1,1]
            Xs = torch.cat(src_images, dim=0).to(self.device)  # [B,C,H,W]
        else:
            return [] 
        # save_image_tensor(Xs[0], f'Xs.png') 
        
        # 2. 从输入的批量图像中提取人脸部分 
        # img_tensor转换为OpenCV格式 (BGR，范围0-255) 
        img_np = img_tensor.permute(0, 2, 3, 1).cpu().numpy()  # [B,H,W,C]
        img_np = ((img_np + 1) / 2 * 255).astype(np.uint8)
        img_np_list = [cv2.cvtColor(img, cv2.COLOR_RGB2BGR) for img in img_np]
        # 批量进行人脸检测和对齐 
        def process_single_image(img_np):
            try:
                Xt, trans_inv = self.detector.get(img_np, crop_size=256)
                if Xt is None:
                    return None, None
                # 确保Xt是numpy数组
                Xt = np.array(Xt)
                return Xt[0], trans_inv[0]  
            except Exception as e: 
                print("InfoSwap：！！！未检测到人脸！！！")   
                return None, None 

        # 使用线程池并行处理
        with concurrent.futures.ThreadPoolExecutor() as executor:
            results = list(executor.map(process_single_image, img_np_list)) 
            
        # 处理线程池返回的结果，封装为img_b_align_crop_list和b_mat_list
        img_b_align_crop_list = []
        b_mat_list = []
        for crop, mat in results:
            if crop is None:  # 如果某张图片未检测到人脸
                return img_tensor  # 返回原图 
            img_b_align_crop_list.append(crop) 
            b_mat_list.append(mat) 

        
        # 批量处理所有人脸，将 img_b_align_crop_list 转为 Xt 
        b_align_crop_tensors = [] 
        for b_align_crop in img_b_align_crop_list: 
            # 将numpy数组转换为PIL Image
            b_align_crop = Image.fromarray(b_align_crop) 
            # 应用transform并转换为tensor 
            b_align_crop_tensor = self.transform(b_align_crop)[None,...].to(self.device)  # [1, C, H, W] 
            b_align_crop_tensors.append(b_align_crop_tensor) 
        # 堆叠所有裁剪后的图像 
        Xt = torch.cat(b_align_crop_tensors, dim=0)  # [B, C, H, W] ，[-1,1] 
        # save_image_tensor(Xt[0], f'Xt.png') 
        
        # 3. 准备好Xs和Xt后，执行批量换脸 
        # 注意：这里的Xs和Xt都是 BGR 通道，不是RGB通道 
        # 使用encoder提取身份信息X_id 
        X_id = self.encoder(
                F.interpolate(torch.cat((Xs, Xt), dim=0)[:, :, 37:475, 37:475], size=[128, 128], # ？？？需要拼接吗
                              mode='bilinear', align_corners=True),
                cache_feats=True
            )

        # 获取特征统计参数
        min_std = torch.tensor(0.01, device=self.device)
        readout_feats = [(self.encoder.features[i] - self.param_dict[i][0]) / torch.max(self.param_dict[i][1], min_std)
                            for i in range(len(self.param_dict))]

        # 对X_id进行信息限制，得到了Xs_id 
        X_id_restrict = torch.zeros_like(X_id).to(self.device)
        Xt_feats, X_lambda = [], []  
        Xt_lambda = []  
        Rs_params, Rt_params = [], []   
        for i in range(len(self.param_dict)-1):  
            R = self.encoder.features[i] 
            Z, lambda_, _ = getattr(self.iib, f'iba_{i}')( 
                R, readout_feats, 
                m_r=self.param_dict[i][0], std_r=self.param_dict[i][1], 
                active_neurons=self.param_dict[i][2], 
            )  
            X_id_restrict += self.encoder.restrict_forward(Z, i)

            Rs, Rt = R[:B], R[B:]
            lambda_s, lambda_t = lambda_[:B], lambda_[B:]

            m_s = torch.mean(Rs, dim=0)
            std_s = torch.mean(Rs, dim=0)
            Rs_params.append([m_s, std_s])

            eps_s = torch.randn(size=Rt.shape).to(Rt.device) * std_s + m_s
            feat_t = Rt * (1. - lambda_t) + lambda_t * eps_s

            Xt_feats.append(feat_t)
            Xt_lambda.append(lambda_t)

        X_id_restrict /= float(len(self.param_dict)-1)
        Xs_id = X_id_restrict[:B] 
        
        
        # 使用decoder提取属性信息Xt_attr和属性权重Xt_attr_lamb 
        Xt_feats[0] = Xt 
        Xt_attr, Xt_attr_lamb = self.decoder(Xt_feats, lambs=Xt_lambda, use_lambda=True)

        # 生成换脸结果图像，同时大小调整为256x256   
        Y = self.G(Xs_id, Xt_attr, Xt_attr_lamb) 
        # save_image_tensor(Y[0], f'Y.png') 
        Y = F.interpolate(Y, size=(256, 256), mode='bilinear', align_corners=True) 
        
        # 将Y从BGR转换为RGB通道 
        Y = Y[:, [2, 1, 0], :, :]
        
        
        # 4. 将换脸结果返回到原始图像中
        final_imgs = reverse2wholeimage(
            Y,  # [B, C, H, W]
            b_mat_list,   # List of 2x3 matrices
            256,          # crop_size
            img_tensor       # [B, C, H, W]
        ) # 输入输出都是[-1,1]
    
        # 确保输出在输入设备上 
        return final_imgs.to(img_tensor.device)

    def forward(self, images): 
        """处理批量图像"""
        if isinstance(images, list):
            images = images[0]
        return self._process_image(images) 


if __name__ == '__main__':
    # 改用Image读取图片 (RGB)
    img1 = Image.open(r"E:\train_program\noise_layers\infoswap\data\src\1.png").convert('RGB')
    img2 = Image.open(r"E:\DataSets\SepMark\dual_watermark\data_256\images\train_256\00038.png").convert('RGB')
    
    transform = transforms.Compose([
        transforms.Resize((256, 256), interpolation=2),  # 调整图像大小
        transforms.ToTensor(),  # 这一步将图片从0-255的值转换为0-1的浮点数 
        transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5]) # 这一步将图片的值归一化到[-1,1]
    ]) 
    
    img1 = transform(img1)  # [C,H,W]
    img2 = transform(img2)  # [C,H,W]
    
    # 直接使用cat而不是stack，因为不需要额外的维度 
    batch = torch.cat([
        img1.unsqueeze(0),  # [1,C,H,W]
        img2.unsqueeze(0)   # [1,C,H,W]
    ], dim=0).cuda()  # [2,C,H,W]
    
    # 执行换脸 
    
    infoswap = InfoSwap().cuda() 
    with torch.no_grad(): 
        results = infoswap(batch) 
    
    # 保存结果 (确保颜色正确)
    for i, result in enumerate(results):
        save_image_tensor(result, f'result_{i}.png') 
        print(f'result_{i}.png 保存成功')         
        
        
