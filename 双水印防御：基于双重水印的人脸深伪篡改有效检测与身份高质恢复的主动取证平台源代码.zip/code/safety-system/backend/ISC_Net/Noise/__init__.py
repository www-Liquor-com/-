# -*- coding: utf-8 -*-
"""
噪声层模块的初始化文件。

此文件使得 `noise_layers` 目录可以被 Python 识别为一个包，
并方便地从中导入各种噪声层类和辅助函数。

它定义了用于生成随机数的辅助函数，并导入了模块中定义的各种噪声层。
DeepFake 相关的噪声层（如 SimSwap, FaceSwap 等）已被注释掉，
以符合不包含这些特定噪声层的要求。
"""
import random


# --- 辅助函数 ---

def get_random_float(float_range: list[float]) -> float:
    """
    生成一个指定范围内的随机浮点数。

    Args:
        float_range (list[float]): 包含两个浮点数的列表 [min, max]，定义了随机数的范围。

    Returns:
        float: 在 [min, max) 范围内的随机浮点数。
               注意：random.random() 返回 [0.0, 1.0) 范围的数。
    """
    # 生成一个 [0.0, 1.0) 范围的随机浮点数，然后缩放和平移到指定范围
    return random.random() * (float_range[1] - float_range[0]) + float_range[0]


def get_random_int(int_range: list[int]) -> int:
    """
    生成指定范围内的随机整数（包含两端）。

    Args:
        int_range (list[int]): 包含两个整数的列表 [min, max]，定义了随机数的范围。

    Returns:
        int: 在 [min, max] 范围内的随机整数。
    """
    # 使用 random.randint 函数生成指定范围内的随机整数（包含上下界）
    return random.randint(int_range[0], int_range[1])


# --- 导入定义的噪声层 ---

# 基础噪声层
from .identity import Identity
from .crop import FaceCrop, FaceCropout, Dropout, FaceErase, FaceEraseout
from .salt_pepper import SaltPepper
from .jpeg import JpegTest
from .resize import Resize

# 基于 Kornia 的噪声层
from .kornia_noises import (
    GaussianBlur, GaussianNoise, MedianBlur,
    Brightness, Contrast, Saturation, Hue,
    Rotation, Affine
)

# --- DeepFake 相关噪声层 (已注释掉) ---
# 根据要求，不导入 DeepFake 相关的噪声层
# ############################################
from .simswap.main import SimSwap 
from .faceshifter.main import FaceShifter 
from .infoswap.main import InfoSwap 
from .stablediffusion_inpaint.main import SDInpaint
# from network.noise_layers.faceswap.face_swap import FaceSwap
# from .ganimation.main import GANimation
# from .stargan.main import StarGAN
# #from .mobilefaceswap.image_test import MobileFaceSwap
# #from .roop.ROOP import ROOP
# ############################################

# 原始代码中的重复注释部分也被移除