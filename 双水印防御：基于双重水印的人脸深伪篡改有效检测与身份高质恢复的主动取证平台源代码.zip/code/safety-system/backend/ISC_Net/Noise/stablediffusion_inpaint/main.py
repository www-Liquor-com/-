import torch
import numpy as np
from PIL import Image
from diffusers import StableDiffusionInpaintPipeline
import random
import cv2 
import os
import glob 
class SDInpaint:
    """
    一个封装了Stable Diffusion Inpainting功能的类，用于图像编辑。
    """
    def __init__(self, device="cuda"):
        """
        初始化并加载Stable Diffusion Inpainting模型。

        Args:
            device (str): 模型加载的设备，默认为"cuda"。
        """
        self.device = device
        try:
            # 自动查找本地的模型下载目录
            cache_root = "dm"
            # snapshot_dirs = glob.glob(os.path.join(cache_root, "*"))
            # if not snapshot_dirs:
            #     raise FileNotFoundError("未找到本地缓存的 Stable Diffusion 2 Inpainting 模型，请先联网下载一次。")
            # local_model_path = snapshot_dirs[0]  # 如果有多个snapshot，取第一个

            self.pipe = StableDiffusionInpaintPipeline.from_pretrained(
                cache_root,
                torch_dtype=torch.float16,
                local_files_only=True
            ).to(self.device)
            print("Stable Diffusion Inpainting 本地模型加载成功。")
        except Exception as e:
            print(f"模型加载失败: {e}")
            self.pipe = None

    def get_random_prompt(self):
        """
        随机生成与人脸篡改相关的提示词。
        Returns:
            str: 随机人脸相关提示词
        """
        prompts = [
            "a smiling human face",
            "a face with sunglasses",
            "a face with a beard",
            "a face with makeup",
            "a face with a scar",
            "a face with blue eyes",
            "a face with a tattoo",
            "a face with a hat",
            "a face with glasses",
            "a face with freckles",
            "a face with different hairstyle",
            "a face with earrings",
            "a face with dramatic lighting",
            "a face with artistic paint",
            "a face with cyberpunk style",
            "a face with fantasy elements"
        ]
        return random.choice(prompts)

    def inpaint_face(self, image_numpy, mask_numpy, prompt=None):
        """
        对256x256的人脸图像根据掩码和提示词进行篡改。

        Args:
            image_numpy (np.ndarray): 输入的人脸图像，形状为(256, 256, 3)，像素值范围[0, 255]。
            mask_numpy (np.ndarray): 篡改区域的掩码，形状为(256, 256)，非零区域为篡改区，像素值范围[0, 255]。
            prompt (str or None): 用于指导篡改的文本提示。如果为None或空字符串，则自动随机生成。

        Returns:
            np.ndarray: 经过篡改和融合后的图像，形状为(256, 256, 3)，像素值范围[0, 1]。
                        如果模型未加载，返回None。
        """
        if self.pipe is None:
            print("错误：模型未成功加载，无法执行图像篡改。") 
            return None

        # 如果未提供prompt，则随机生成
        if not prompt:
            # prompt = self.get_random_prompt()
            # print(f"自动生成提示词: {prompt}") 
            prompt = " "

        # 将numpy数组转为PIL图像
        pil_image = Image.fromarray(image_numpy.astype(np.uint8))
        pil_mask = Image.fromarray(mask_numpy.astype(np.uint8)).convert("L") 

        # 模型要求输入为512x512，因此需要进行缩放 
        image_resized = pil_image.convert("RGB").resize((512, 512))
        mask_resized = pil_mask.resize((512, 512), Image.NEAREST)

        # 执行inpainting 
        inpainted_image_pil = self.pipe(
            prompt=prompt,
            image=image_resized,
            mask_image=mask_resized,
        ).images[0]

        # 将模型输出的512x512图像下采样回256x256
        inpainted_image_256_pil = inpainted_image_pil.resize((256, 256), Image.BICUBIC)
        inpainted_image_256_np = np.array(inpainted_image_256_pil) / 255.0

        # 原始图像归一化
        image_original_np = image_numpy.astype(np.float32) / 255.0

        # 掩码处理为3通道且归一化 
        mask_np = mask_numpy.astype(np.float32) / 255.0
        if mask_np.ndim == 2:
            mask_np_3d = np.stack([mask_np] * 3, axis=-1)
        else:
            mask_np_3d = mask_np
        mask_binary = (mask_np_3d > 0.5).astype(np.float32)

        # 融合：原图未掩码区域 + inpainted 掩码区域 
        fused_image = image_original_np * (1 - mask_binary) + inpainted_image_256_np * mask_binary 

        return fused_image




if __name__ == '__main__':
    # 示例用法
    # 1. 创建一个SDInpaint实例
    print("正在初始化SDInpaint...")
    sd_inpainter = SDInpaint()

    if sd_inpainter.pipe:
        # 2. 读取测试图像
        img_path = r"test_imgs\watermarked.png"
        image = cv2.imread(img_path)
        if image is None:
            print(f"无法读取测试图像: {img_path}")
            exit(1)
        # 转为RGB
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        h, w = image.shape[:2]
        # 3. 创建中心方形掩码
        mask = np.zeros((h, w), dtype=np.uint8)
        side = min(h, w) // 2
        top = (h - side) // 2
        left = (w - side) // 2
        mask[top:top+side, left:left+side] = 255

        # 4. 定义一个提示词
        prompt_text = " "

        print("正在执行图像篡改...")
        # 5. 执行篡改
        result_image = sd_inpainter.inpaint_face(image, mask, prompt_text)

        # 6. 保存结果
        if result_image is not None:
            # 将结果从[0, 1]范围转回[0, 255]并保存
            result_pil = Image.fromarray((result_image * 255).astype(np.uint8))
            save_path = "inpainted_example.png"
            result_pil.save(save_path)
            print(f"篡改完成，结果已保存至: {save_path}")
        else:
            print("篡改失败，未生成结果。")
    else:
        print("由于模型加载失败，无法运行示例。")


