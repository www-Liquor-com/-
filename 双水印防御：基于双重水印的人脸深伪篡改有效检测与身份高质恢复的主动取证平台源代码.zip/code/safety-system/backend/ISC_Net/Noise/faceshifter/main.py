import os

import cv2 
import torch 
import numpy as np 
from PIL import Image 
import torch.nn.functional as F 
import os  
import torch.nn as nn  
import random 
import sys
import pickle
from torchvision import transforms
import concurrent.futures
from ISC_Net.insightface_func.face_detect_crop_single import Face_detect_crop  
import logging
import onnxruntime
# 添加当前目录到 Python 路径
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(current_dir)

from network.AEI_Net import AEI_Net
onnxruntime.set_default_logger_severity(3)

# def reverse2wholeimage(swaped_imgs, mats, crop_size, oriimgs):
#     batch_size = swaped_imgs.shape[0]
#     target_images = []
    
#     for i in range(batch_size):
#         swaped_img = swaped_imgs[i].cpu().detach().numpy().transpose((1, 2, 0))
#         mat = mats[i]
#         oriimg = oriimgs[i].cpu().detach().numpy().transpose((1, 2, 0))
        
#         # Create circular mask
#         mask = np.zeros([crop_size, crop_size], dtype=float)
#         for i in range(crop_size):
#             for j in range(crop_size):
#                 dist = np.sqrt((i-crop_size//2)**2 + (j-crop_size//2)**2)/(crop_size//2)
#                 dist = np.minimum(dist, 1)
#                 mask[i, j] = 1-dist
#         mask = cv2.dilate(mask, None, iterations=20)
        
#         orisize = (oriimg.shape[1], oriimg.shape[0])
        
#         # Warp the swapped image
#         target_image = cv2.warpAffine(swaped_img, mat, orisize)
        
#         # Warp the mask
#         mask_ = cv2.warpAffine(mask, mat, orisize)
#         mask_ = np.expand_dims(mask_, 2)
        
#         # Blend images using mask
#         target_image = target_image * mask_ + oriimg * (1 - mask_)
#         target_images.append(target_image)
    
#     # Convert to tensor and normalize to [0,1]
#     target_images = np.stack(target_images, axis=0)
#     target_images = torch.from_numpy(target_images.transpose((0, 3, 1, 2))).float()
    
#     return target_images 



def reverse2wholeimage(swaped_imgs, mats, crop_size, oriimgs):
    """
    Args:
        swaped_imgs: torch.Tensor, shape [B,C,H,W], range [0,1], RGB
        mats: List[np.ndarray], length B, each is 2x3 affine transform matrix
        crop_size: int, size of cropped face
        oriimgs: torch.Tensor, shape [B,C,H,W], range [0,1], RGB
    Returns:
        torch.Tensor, shape [B,C,H,W], range [0,1], RGB
    """
    batch_size = swaped_imgs.shape[0]
    target_images = []
    
    for i in range(batch_size):
        swaped_img = swaped_imgs[i].cpu().detach().numpy().transpose((1, 2, 0))
        mat = mats[i]
        oriimg = oriimgs[i].cpu().detach().numpy().transpose((1, 2, 0))
        
        # Create white image for mask
        img_white = np.full((crop_size, crop_size), 255, dtype=float)
        
        # Inverse the Affine transformation matrix
        mat_rev = np.zeros([2,3])
        div1 = mat[0][0]*mat[1][1]-mat[0][1]*mat[1][0]
        mat_rev[0][0] = mat[1][1]/div1
        mat_rev[0][1] = -mat[0][1]/div1
        mat_rev[0][2] = -(mat[0][2]*mat[1][1]-mat[0][1]*mat[1][2])/div1
        div2 = mat[0][1]*mat[1][0]-mat[0][0]*mat[1][1]
        mat_rev[1][0] = mat[1][0]/div2
        mat_rev[1][1] = -mat[0][0]/div2
        mat_rev[1][2] = -(mat[0][2]*mat[1][0]-mat[0][0]*mat[1][2])/div2
        
        orisize = (oriimg.shape[1], oriimg.shape[0])
        
        # Warp the swapped image
        target_image = cv2.warpAffine(swaped_img, mat_rev, orisize)
        
        # Create and process mask
        img_white = cv2.warpAffine(img_white, mat_rev, orisize)
        img_white[img_white>20] = 255
        img_mask = img_white 
        
        kernel = np.ones((40,40),np.uint8)
        img_mask = cv2.erode(img_mask,kernel,iterations = 1)
        kernel_size = (20, 20)
        blur_size = tuple(2*i+1 for i in kernel_size)
        img_mask = cv2.GaussianBlur(img_mask, blur_size, 0)
        img_mask = img_mask / 255
        img_mask = np.reshape(img_mask, [img_mask.shape[0],img_mask.shape[1],1])
        
        # Blend images using mask
        target_image = target_image * img_mask + oriimg * (1 - img_mask)
        target_images.append(target_image) 
    
    # Convert to tensor and normalize to [0,1]
    target_images = np.stack(target_images, axis=0)
    target_images = torch.from_numpy(target_images.transpose((0, 3, 1, 2))).float()
    
    return target_images


def save_image_tensor(tensor, path):
    """保存图像， 输入张量的范围是 [-1, 1]"""
    image = tensor.squeeze(0).permute(1, 2, 0).cpu().numpy()
    image = ((image + 1) / 2 * 255).astype(np.uint8)
    Image.fromarray(image).save(path) 


class FaceShifter(nn.Module):
    def __init__(self, features_path=r"deepfake_dataset\features", mode='train'):
        super(FaceShifter, self).__init__() 
        self.mode = mode 
        
        # 初始化人脸检测器 (直接使用BGR) 
        self.detector = Face_detect_crop(name='antelope', root='ISC_Net/insightface_func/models') 

        # 设置日志级别为ERROR，抑制警告信息
        self.detector.prepare(ctx_id=0, det_thresh=0.1, det_size=(256,256))
        current_dir = os.path.dirname(os.path.abspath(__file__)) 
        
        # 初始化FaceShifter模型 
        self.G = AEI_Net(c_id=512)
        self.G.eval()
        self.G.load_state_dict(
            torch.load(os.path.join(current_dir, 'saved_models', 'G_latest.pth'), map_location='cuda', weights_only=True),
            strict=True
        )
        self.G = self.G.cuda()
        print("FaceShifer：G模型权重加载成功") 
        
        # 加载特征字典
        train_dict_path = features_path + r"\train_256\train_256_features.pkl"
        val_dict_path = features_path + r"\val_256\val_256_features.pkl"
        test_dict_path = features_path + r"\test_256\test_256_features.pkl"
        
        with open(train_dict_path, 'rb') as f:
            self.train_features_dict = pickle.load(f) 
        with open(val_dict_path, 'rb') as f: 
            self.val_features_dict = pickle.load(f) 
        with open(test_dict_path, 'rb') as f:
            self.test_features_dict = pickle.load(f) 
        
        # 初始化features_dict
        self.features_dict = getattr(self, f'{mode}_features_dict')
        
        # 标准归一化transform，保证和训练/推理一致
        self.test_transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
        ])
        
    # 将numpy数组转换为0到1之间的tensor
    def _totensor(self, array):
        tensor = torch.from_numpy(array)
        img = tensor.transpose(0, 1).transpose(0, 2).contiguous()
        return img.float().div(255)
    
    
    def _process_image(self, img_tensor):
        """处理批量图像"""
        B = img_tensor.shape[0]  # 获取批量大小 
        
        # 转换为OpenCV格式 (BGR，范围0-255) 
        img_np_list = []
        for i in range(B):
            img_np = img_tensor[i].permute(1, 2, 0).cpu().numpy()
            img_np = ((img_np + 1) / 2 * 255).astype(np.uint8)
            img_np = cv2.cvtColor(img_np, cv2.COLOR_RGB2BGR)
            img_np_list.append(img_np)
        
        # 批量进行人脸检测和对齐
        def process_single_image(img_np):
            try:
                Xt, trans_inv = self.detector.get(img_np, crop_size=256)
                if Xt is None:
                    return None, None
                # 确保Xt是numpy数组
                Xt = np.array(Xt)
                return Xt[0], trans_inv[0]  
            except Exception as e: 
                print("FaceShifer：！！！未检测到人脸！！！")   
                return None, None 

        # 使用线程池并行处理
        with concurrent.futures.ThreadPoolExecutor() as executor:
            results = list(executor.map(process_single_image, img_np_list))

        # 处理结果
        img_b_align_crop_list = [] 
        b_mat_list = [] 
        for crop, mat in results:
            if crop is None:  # 如果某张图片未检测到人脸
                return img_tensor  # 返回原图
            img_b_align_crop_list.append(crop)
            b_mat_list.append(mat)

        # 随机从特征字典中获取B个特征向量 
        keys = list(self.features_dict.keys())
        selected_indices = np.random.choice(len(keys), size=min(B, len(keys)), replace=False)
        selected_keys = [keys[i] for i in selected_indices]
        # print("本次随机选择的源图像路径/ID：", selected_keys)
        selected_features = [torch.from_numpy(self.features_dict[key]).squeeze() for key in selected_keys]
        latend_ids = torch.stack(selected_features, dim=0).cuda()
        latend_ids = F.normalize(latend_ids, p=2, dim=1)
        assert latend_ids.shape == (B, 512), f"Expected shape (B, 512), got {latend_ids.shape}"

        # 批量处理所有人脸 
        b_align_crop_tensors = []
        for b_align_crop in img_b_align_crop_list:
            b_align_crop = cv2.cvtColor(b_align_crop, cv2.COLOR_BGR2RGB) # [1, 256, 256, 3] -> [1, 3, 256, 256]
            b_align_crop_tensor = self._totensor(b_align_crop)[None,...].cuda()  # [1, C, H, W]
            b_align_crop_tensors.append(b_align_crop_tensor) 
        
        # 堆叠所有裁剪后的图像
        b_align_crop_tensor = torch.cat(b_align_crop_tensors, dim=0)  # [B, C, H, W]
        # print('b_align_crop_tensor min/max/mean:', b_align_crop_tensor.min().item(), b_align_crop_tensor.max().item(), b_align_crop_tensor.mean().item())
        b_align_crop_tensor = b_align_crop_tensor *2.0 - 1.0 # [0,1] -> [-1,1]
        # 批量调用模型  
        swap_result, _ = self.G(b_align_crop_tensor, latend_ids)  # [B, C, H, W] 
                
        # 保存未融合的换脸结果图片，便于排查融合问题 
        raw_result_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'result') 
        os.makedirs(raw_result_dir, exist_ok=True) 
        for i in range(B): 
            save_image_tensor(swap_result[i].unsqueeze(0), os.path.join(raw_result_dir, f'swap_raw_{i}.png')) 
        
        
        # # 转为[0,1]区间
        swap_result = ((swap_result + 1) / 2.0).clamp(0, 1) 
        
        # 将原始图像转换为tensor 
        oriimgs = ( img_tensor + 1 ) /2.0
        
        # print('swap_results min/max/mean:', swap_result.min().item(), swap_result.max().item(), swap_result.mean().item()) 
        # print('oriimgs min/max/mean:', oriimgs.min().item(), oriimgs.max().item(), oriimgs.mean().item()) 
        # 批量融合
        final_imgs = reverse2wholeimage(
            swap_result,  # [B, C, H, W]
            b_mat_list,   # List of 2x3 matrices
            256,          # crop_size
            oriimgs       # [B, C, H, W]
        ) # 输入输出都是[0,1]
        
        # 应用transforms将[0,1]范围转换到[-1,1]
        transform = transforms.Compose([ 
            transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])  # 归一化到[-1,1]
        ])
        final_imgs = transform(final_imgs)
        
        # 确保输出在输入设备上 
        return final_imgs.to(img_tensor.device)

    def forward(self, images, mode='train'):
        """处理批量图像"""
        # # 更新特征字典
        # self.features_dict = getattr(self, f'{mode}_features_dict')
        # 如果输入是列表，取第一个元素（编码后的图像）
        if isinstance(images, list):
            images = images[0]
        return self._process_image(images)




if __name__ == '__main__':
    # 改用Image读取图片 (RGB)
    img1 = Image.open(r"E:\DataSets\IdFMark\images\test_256\00002.png").convert('RGB')
    img2 = Image.open(r"E:\DataSets\IdFMark\images\test_256\00004.png").convert('RGB')
    
    transform = transforms.Compose([
        transforms.ToTensor(),  # 这一步将图片从0-255的值转换为0-1的浮点数 
        transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5]) # 这一步将图片的值归一化到[-1,1]
    ]) 
    
    img1 = transform(img1)  # [C,H,W]
    img2 = transform(img2)  # [C,H,W]
    
    # 直接使用cat而不是stack，因为不需要额外的维度 
    batch = torch.cat([ 
        img1.unsqueeze(0),  # [1,C,H,W]
        img2.unsqueeze(0)   # [1,C,H,W]
    ], dim=0).cuda()  # [2,C,H,W] 
    
    # 执行换脸 
    faceshifter = FaceShifter().cuda() 
    with torch.no_grad(): 
        results = faceshifter(batch) 
    
    # print('results min/max/mean:', results.min().item(), results.max().item(), results.mean().item())
    
    
    # 确保result文件夹存在 
    result_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'result') 
    os.makedirs(result_dir, exist_ok=True) 
    
    # 保存结果 (确保颜色正确)
    for i, result in enumerate(results): 
        save_image_tensor(result, os.path.join(result_dir, f'result_{i}.png'))  

