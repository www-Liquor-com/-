import os
import torch
import numpy as np
from PIL import Image
from torchvision import transforms
from torch.utils.data import Dataset, DataLoader
import lpips
from skimage.metrics import peak_signal_noise_ratio, structural_similarity
from .IdFMark.network.IdFMark import Network
from .IR.models.IRNet  import IRNet 
import torch.nn.functional as F
from .utils.img_fea_loader import ImgFeaDataset
import pickle 
import sys
from .insightface_func.face_detect_crop_single import Face_detect_crop
from .Noise import *
import cv2
import argparse
import concurrent.futures
import time,hashlib
def set_seed(seed=42):
    """
    固定全局随机种子，确保实验可重复性
    """
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    os.environ['PYTHONHASHSEED'] = str(seed)

# 设置随机种子，保证实验结果可复现
set_seed(42) 


# # 添加项目根目录到 Python 路径
# project_root = os.path.dirname(os.path.abspath(__file__))
# sys.path.append(project_root)

os.environ["TORCH_HOME"] = "E:/torch_cache"  # 设置PyTorch模型缓存路径

def save_image(tensor, path):
    """保存图像"""
    # 输入图像[-1,1]
    image = tensor.squeeze(0).permute(1, 2, 0).cpu().numpy()
    image = ((image + 1) / 2 * 255).astype(np.uint8)
    Image.fromarray(image).save(path)


def save_residual_image(original, encoded, path):
    """保存增强后的残差图像"""
    # 计算残差
    residual = encoded - original
    
    # 转换为numpy数组并保存
    residual_np = residual.squeeze(0).permute(1, 2, 0).cpu().numpy()
    residual_np = ((residual_np + 1) / 2 * 255).astype(np.uint8)
    residual_np = (residual_np) * 5 # 放大5倍  
    Image.fromarray(residual_np).save(path) 


import lpips  # pip install lpips


lpips_model = lpips.LPIPS().eval()
if torch.cuda.is_available():
    lpips_model = lpips_model.cuda()

def evaluate_quality(original, encoded):
    """评估图像质量，返回 PSNR, SSIM, LPIPS"""
    batch_size = original.size(0)
    psnrs = []
    ssims = []
    lpips_scores = []

    for i in range(batch_size):
        # 单个图像 (C, H, W) -> (H, W, C)
        orig_img = original[i].detach().cpu()
        enc_img = encoded[i].detach().cpu()

        orig_np = orig_img.permute(1, 2, 0).numpy()
        enc_np = enc_img.permute(1, 2, 0).numpy()

        # 裁剪数值，确保在 [-1, 1]
        orig_np = np.clip(orig_np, -1, 1)
        enc_np = np.clip(enc_np, -1, 1)

        # PSNR
        psnr = peak_signal_noise_ratio(orig_np, enc_np, data_range=2.0)
        psnrs.append(psnr)

        # SSIM
        if orig_np.ndim == 3 and orig_np.shape[2] == 1:
            ssim = structural_similarity(orig_np.squeeze(), enc_np.squeeze(), data_range=2.0)
        else:
            ssim = structural_similarity(orig_np, enc_np, channel_axis=2, data_range=2.0)
        ssims.append(ssim)

        # LPIPS 需要输入 shape: (1, 3, H, W)，float32，范围 [-1, 1]
        orig_lpips = orig_img.unsqueeze(0)
        enc_lpips = enc_img.unsqueeze(0)
        if torch.cuda.is_available():
            orig_lpips = orig_lpips.cuda()
            enc_lpips = enc_lpips.cuda()
        lpips_score = lpips_model(orig_lpips, enc_lpips).item()
        lpips_scores.append(lpips_score)

    return np.mean(psnrs), np.mean(ssims), np.mean(lpips_scores)

def cosine_similarity(message1, message2):
    """计算两个消息之间的余弦相似度"""
    # 确保两个消息都是二维张量 [batch_size, message_length]
    if len(message1.shape) == 1:
        message1 = message1.unsqueeze(0)
    if len(message2.shape) == 1:
        message2 = message2.unsqueeze(0)
    
    # 使用与训练时相同的余弦相似度计算方式
    similarity = torch.nn.functional.cosine_similarity(message1, message2, dim=1)
    return similarity


def save_feature_vector(feature, path):
    """保存特征向量到文本文件"""
    # 将特征向量转换为numpy数组
    feature_np = feature.squeeze().cpu().numpy()
    # 保存到文本文件
    np.savetxt(path, feature_np, fmt='%.6f')


def str2bool(v):
    if isinstance(v, bool):
        return v
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')


def reverse2wholeimage(swaped_imgs, mats, crop_size, oriimgs):
    """
    将裁剪和对齐后的人脸图像恢复到原始图像中:使用alpha混合 
    """
    batch_size = swaped_imgs.shape[0]  # 获取批次大小 
    target_images = []  # 存储处理后的图像列表 
    
    for i in range(batch_size):
        # 将张量转换为numpy数组并调整维度顺序 [C,H,W] -> [H,W,C]
        swaped_img = swaped_imgs[i].cpu().detach().numpy().transpose((1, 2, 0))
        mat = mats[i]  # 获取当前图像的变换矩阵
        oriimg = oriimgs[i].cpu().detach().numpy().transpose((1, 2, 0))
        
        # 创建白色图像作为掩码的基础
        img_white = np.full((crop_size, crop_size), 255, dtype=float)
        
        # 计算仿射变换矩阵的逆矩阵
        # 用于将处理后的图像映射回原始图像空间
        mat_rev = np.zeros([2,3])
        # 计算行列式
        div1 = mat[0][0]*mat[1][1]-mat[0][1]*mat[1][0]
        # 计算逆矩阵的第一行
        mat_rev[0][0] = mat[1][1]/div1
        mat_rev[0][1] = -mat[0][1]/div1
        mat_rev[0][2] = -(mat[0][2]*mat[1][1]-mat[0][1]*mat[1][2])/div1
        # 计算逆矩阵的第二行
        div2 = mat[0][1]*mat[1][0]-mat[0][0]*mat[1][1]
        mat_rev[1][0] = mat[1][0]/div2
        mat_rev[1][1] = -mat[0][0]/div2
        mat_rev[1][2] = -(mat[0][2]*mat[1][0]-mat[0][0]*mat[1][2])/div2
        
        # 获取原始图像尺寸
        orisize = (oriimg.shape[1], oriimg.shape[0])
        
        # 使用逆变换矩阵将处理后的图像映射回原始图像空间
        target_image = cv2.warpAffine(swaped_img, mat_rev, orisize)
        
        # 创建和处理掩码
        # 将白色图像映射到原始图像空间
        img_white = cv2.warpAffine(img_white, mat_rev, orisize)
        # 二值化掩码
        img_white[img_white>20] = 255
        img_mask = img_white
        
        # 使用腐蚀操作缩小掩码区域
        kernel = np.ones((40,40),np.uint8)
        img_mask = cv2.erode(img_mask,kernel,iterations = 1)
        
        # 使用高斯模糊平滑掩码边缘
        kernel_size = (20, 20)
        blur_size = tuple(2*i+1 for i in kernel_size)
        img_mask = cv2.GaussianBlur(img_mask, blur_size, 0)
        
        # 归一化掩码到[0,1]范围
        img_mask = img_mask / 255
        # 调整掩码维度以匹配图像通道
        img_mask = np.reshape(img_mask, [img_mask.shape[0],img_mask.shape[1],1])
        
        # 使用掩码混合处理后的图像和原始图像
        # 在掩码区域使用处理后的图像，其他区域保持原始图像
        target_image = target_image * img_mask + oriimg * (1 - img_mask)
        target_images.append(target_image)
    
    # 将处理后的图像列表堆叠成批次
    target_images = np.stack(target_images, axis=0)
    # 转换为张量并调整维度顺序 [B,H,W,C] -> [B,C,H,W]
    target_images = torch.from_numpy(target_images.transpose((0, 3, 1, 2))).float()
    
    return target_images




def extract_idfmark(img_list): 
    # 设置设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    result_dir = "temp_results/" 
    # 模型参数
    message_length = 512
    batch_size = 2  # 减小批量大小从8到4
    lr = 0.0001
    beta1 = 0.5
    attention_encoder = 'se' 
    attention_decoder = 'se' 
    weight = [1, 10, 10, 10, 0.1] 
    
    # 加载预训练模型 :水印模块 
    print('正在初始化水印模块...')
    idfmark_model = Network(
        message_length=message_length,
        noise_layers=[],
        device=device,
        batch_size=batch_size,
        lr=lr,
        beta1=beta1,
        attention_encoder=attention_encoder,
        attention_decoder=attention_decoder,
        weight=weight 
    ) 
    idfmark_model_path = "ISC_Net/IdFMark/checkpoint/EC_1.pth" 
    try: 
        idfmark_model.load_model_ed(idfmark_model_path)   
        idfmark_model.encoder_decoder.eval() 
    except RuntimeError as e: 
        print("错误：加载模型权重失败。请检查模型架构是否与预训练权重匹配。")  
        print("错误详情:", str(e))  
        return  
    print('水印模块初始化完成...') 

    decoded_features = []

    with torch.no_grad():
        
        for id, img in enumerate(img_list): 
            # 预处理img
            img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            pil_img = Image.fromarray(img_rgb)  
            # 定义图像变换：调整大小, 转换为张量 
            transform = transforms.Compose([ 
                transforms.Resize((256, 256)), 
                transforms.ToTensor(), 
                transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])  # 归一化到[-1, 1]  
            ])  
            # 应用变换
            img_tensor = transform(pil_img)
            img_tensor = img_tensor.unsqueeze(0).to(device)  # [1, 3, 256, 256] 
            
            # 解码提取水印 
            decoded_feature = idfmark_model.encoder_decoder.module.decoder(img_tensor)
            decoded_feature = idfmark_model.encoder_decoder.module.output_norm(decoded_feature) 
            # 将tensor转换为numpy向量并添加到列表中
            decoded_feature_np = decoded_feature.squeeze(0).cpu().numpy() 
            decoded_features.append(decoded_feature_np)
            
    return decoded_features
            
            
            
            
            
            