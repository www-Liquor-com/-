import torch
import numpy as np
from ..network.common import DWT

def preprocess_img(x, x_h=None, size=512):
    """
    将OpenCV读取的批量图像列表x和x_h处理为BCHW格式，归一化到[0,1]，缩放到size * size
    如果x_h为None，则自动生成纯蓝色图像作为替代。
    Args:
        x: list of np.ndarray, 每个元素为(H, W, 3)，BGR顺序，0~255
        x_h: list of np.ndarray or None, 同x
    Returns:
        x_tensor: torch.Tensor, [B, 3, 512, 512], float, [0,1]，
        x_h_tensor: torch.Tensor, [B, 3, 512, 512], float, [0,1]，
    """
    dwt = DWT()  # 实例化DWT

    B = len(x)
    processed_x = []
    processed_x_h = []

    for i in range(B):
        # 处理x
        img = x[i]
        # BGR -> RGB
        img = img[..., [2, 1, 0]]
        # HWC -> CHW
        img = np.transpose(img, (2, 0, 1))
        img = torch.from_numpy(img).float()
        # 缩放到size*size
        img = torch.nn.functional.interpolate(img.unsqueeze(0), size=(size, size), mode='bilinear', align_corners=False).squeeze(0)
        # 归一化
        img = img / 255.0 
        processed_x.append(img) 

        # 处理x_h
        if x_h is not None:
            img_h = x_h[i]
            img_h = img_h[..., [2, 1, 0]]
            img_h = np.transpose(img_h, (2, 0, 1))
            img_h = torch.from_numpy(img_h).float()
            img_h = torch.nn.functional.interpolate(img_h.unsqueeze(0), size=(512, 512), mode='bilinear', align_corners=False).squeeze(0)
            img_h = img_h / 255.0
        else:
            # 生成纯蓝色图像 (RGB: 0,0,255)
            blue_img = np.zeros((3, size, size), dtype=np.float32)
            blue_img[2, :, :] = 255.0  # R=0, G=0, B=255 (RGB)
            img_h = torch.from_numpy(blue_img).float() / 255.0
        processed_x_h.append(img_h)

    x_tensor = torch.stack(processed_x, dim=0)
    x_h_tensor = torch.stack(processed_x_h, dim=0)

    return x_tensor, x_h_tensor 



def preprocess_img2(x, x_h=None):
    """
    将OpenCV读取的批量图像列表x和x_h处理为BCHW格式，归一化到[-1,1]，缩放到512x512，
    如果x_h为None，则自动生成纯蓝色图像作为替代。
    Args:
        x: list of np.ndarray, 每个元素为(H, W, 3)，BGR顺序，0~255
        x_h: list of np.ndarray or None, 同x
    Returns:
        x_tensor: torch.Tensor, [B, 3, 512, 512], float, [-1,1]，
        x_h_tensor: torch.Tensor, [B, 3, 512, 512], float, [-1,1]，
    """

    B = len(x)
    processed_x = []
    processed_x_h = []

    for i in range(B):
        # 处理x
        img = x[i]
        # BGR -> RGB
        img = img[..., [2, 1, 0]]
        # HWC -> CHW
        img = np.transpose(img, (2, 0, 1))
        img = torch.from_numpy(img).float()
        # 缩放到512x512
        img = torch.nn.functional.interpolate(img.unsqueeze(0), size=(512, 512), mode='bilinear', align_corners=False).squeeze(0)
        # 归一化到[-1,1]
        img = img / 127.5 - 1.0
        processed_x.append(img)

        # 处理x_h
        if x_h is not None:
            img_h = x_h[i]
            img_h = img_h[..., [2, 1, 0]]
            img_h = np.transpose(img_h, (2, 0, 1))
            img_h = torch.from_numpy(img_h).float()
            img_h = torch.nn.functional.interpolate(img_h.unsqueeze(0), size=(512, 512), mode='bilinear', align_corners=False).squeeze(0)
            img_h = img_h / 127.5 - 1.0
        else:
            # 生成纯蓝色图像 (RGB: 0,0,255) 并归一化到[-1,1]
            blue_img = np.zeros((3, 512, 512), dtype=np.float32)
            blue_img[2, :, :] = 255.0  # R=0, G=0, B=255 (RGB)
            img_h = torch.from_numpy(blue_img).float()
            img_h = img_h / 127.5 - 1.0
        processed_x_h.append(img_h)

    x_tensor = torch.stack(processed_x, dim=0)
    x_h_tensor = torch.stack(processed_x_h, dim=0)

    return x_tensor, x_h_tensor 

    
def preprocess_bit(bit_input):
    """
    将01二进制比特串列表转换为BL张量，数值转为-0.5或0.5
    Args:
        bit_input: list of str，每个元素为如"010101..."的比特串
    Returns:
        torch.Tensor, shape [B, L]，元素为-0.5或0.5
    """
    # bit_input: list of str, e.g. ["010101", "111000", ...]
    bit_list = []
    for s in bit_input:
        # 将字符串转为list[int]
        arr = [0.5 if c == '1' else -0.5 for c in s]
        bit_list.append(arr)
    tensor = torch.tensor(bit_list, dtype=torch.float32)
    return tensor
