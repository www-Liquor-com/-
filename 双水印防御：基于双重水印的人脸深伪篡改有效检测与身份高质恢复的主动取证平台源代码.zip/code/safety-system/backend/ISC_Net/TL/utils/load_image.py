import torch
import numpy as np
from PIL import Image

def load_image(image, message=None):
    """
    加载并处理输入图像和消息数据，返回模型所需的字典格式数据。

    Args:
        image (np.ndarray): 输入的原始图像，形状为(H, W, 3)，像素值范围为0~255。
            注意：此处输入通常为BGR顺序。
        message (np.ndarray or None): 可选，嵌入的消息数据。

    Returns:
        dict: 包含以下键值对的数据字典：
            'LQ': 低质量图像张量（torch.Tensor），形状为(1, 1, 3, H, W)
                注意：这里的H、W顺序为高、宽，且实际为512。
            'GT': 高质量图像张量（torch.Tensor），形状为(1, 1, 3, 512, 512)
                为输入图像缩放到(512, 512)后的结果，通道顺序为RGB。
            'MES': 消息数据
    """
    # 归一化到[0, 1]
    img_GT = image / 255 

    # BGR转RGB（假设原始为BGR） 
    img_GT = img_GT[:, :, [2, 1, 0]] 

    # 转为torch张量，通道前置，(1, 3, H, W) 
    img_GT = torch.from_numpy(np.ascontiguousarray(np.transpose(img_GT, (2, 0, 1)))).float().unsqueeze(0) 
 
    # 缩放到(512, 512)，保持通道数不变 
    img_GT = torch.nn.functional.interpolate(img_GT, size=(512, 512), mode='nearest', align_corners=None) 

    # 增加一个批次维度，最终(1, 1, 3, 512, 512) 
    img_GT = img_GT.unsqueeze(0) 

    # 获取各维度大小
    _, T, C, H, W = img_GT.shape  # 注意：H为高，W为宽，实际均为512

    list_h = []

    # 构造一个纯蓝色的低质量图像（LQ），大小与GT一致
    # 这里LQ不是被隐藏的图像，仅为纯蓝色占位
    R, G, B = 0, 0, 255
    image_blue = Image.new('RGB', (W, H), (R, G, B))
    result = np.array(image_blue) / 255.
    expanded_matrix = np.expand_dims(result, axis=0)  # (1, H, W, 3)
    expanded_matrix = np.repeat(expanded_matrix, T, axis=0)  # (T, H, W, 3)
    imgs_LQ = torch.from_numpy(np.ascontiguousarray(expanded_matrix)).float()
    imgs_LQ = imgs_LQ.permute(0, 3, 1, 2)  # (T, 3, H, W)
    imgs_LQ = torch.nn.functional.interpolate(imgs_LQ, size=(H, W), mode='nearest', align_corners=None)
    imgs_LQ = imgs_LQ.unsqueeze(0)  # (1, T, 3, H, W)

    # 加入列表
    list_h.append(imgs_LQ)

    # 堆叠所有低质量图像，最终(1, 1, T, 3, H, W)，但这里只加了一个元素
    list_h = torch.stack(list_h, dim=0)

    # 返回包含LQ、GT和消息的字典
    return {
        'LQ': list_h,
        'GT': img_GT,  # 缩放到(512,512)的输入图像
        'MES': message
    }
    
    