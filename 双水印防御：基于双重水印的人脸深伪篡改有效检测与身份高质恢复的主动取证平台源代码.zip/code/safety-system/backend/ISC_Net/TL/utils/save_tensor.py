import torch
import numpy as np
import cv2
import os

def save_tensor(img_tensor,size_list=None,name=None,save_path=None):
    """
    保存张量为图片文件。
    Args:
        img_tensor: torch.Tensor, [B, C, H, W]，数值范围[0,1]，C可以是1或3
        size_list: list of [H, W] 或 None，原始尺寸列表
    """
    # 创建保存目录
    os.makedirs("temp_results", exist_ok=True)
    
    # 检查数值范围并发出警告
    min_val = img_tensor.min().item()
    max_val = img_tensor.max().item()
    if min_val < 0 or max_val > 1:
        print(f"警告: img_tensor数值范围超出[0,1]，实际范围: [{min_val:.4f}, {max_val:.4f}]")

    # 确保img_tensor在cpu上
    img_tensor = img_tensor.detach().cpu()
    B = img_tensor.shape[0]
    C = img_tensor.shape[1]  # 获取通道数
    
    for i in range(B):
        img = img_tensor[i]  # [C, H, W]
        img_np = img.numpy()
        # [C, H, W] -> [H, W, C]
        img_np = np.transpose(img_np, (1, 2, 0))
        # clip到[0,1]
        img_np = np.clip(img_np, 0, 1) 
        
        # # 自适应归一化到[0,1]
        # min_val = img_np.min()
        # max_val = img_np.max()
        # if max_val > min_val:  # 避免除零
        #     img_np = (img_np - min_val) / (max_val - min_val)
        
        # 乘255并转uint8
        img_np = (img_np * 255.0).round().astype(np.uint8)
        
        # 根据通道数处理
        if C == 3:
            # RGB->BGR
            img_np = img_np[..., [2, 1, 0]]
        elif C == 1:
            # 单通道图像，重复3次变成3通道
            img_np = np.repeat(img_np, 3, axis=2)
        else:
            print(f"警告: 不支持的通道数 {C}，跳过保存")
            continue
            
        # 如果需要resize
        if size_list is not None:
            h, w = size_list[i]
            img_np = cv2.resize(img_np, (w, h), interpolation=cv2.INTER_LINEAR)
            
        # 保存
        if not save_path:
            if not name:
                save_path = f"temp_results/output_{i}.png"
                is_success, buffer = cv2.imencode('.png', img_np)
                if is_success:
                    with open(save_path, 'wb') as f:
                        f.write(buffer.tobytes())
                print(f"Saved: {save_path}")
            else:
                save_path = f"temp_results/{name}_{i}.png"
                is_success, buffer = cv2.imencode('.png', img_np)
                if is_success:
                    with open(save_path, 'wb') as f:
                        f.write(buffer.tobytes())
                print(f"Saved: {save_path}")
        else:
            is_success, buffer = cv2.imencode('.png', img_np)
            if is_success:
                with open(save_path, 'wb') as f:
                    f.write(buffer.tobytes())
            print(f"Saved: {save_path}")







def save_tensor2(img_tensor,size_list=None,name=None):
    """
    保存张量为图片文件。
    Args:
        img_tensor: torch.Tensor, [B, 3, H, W]，数值范围[-1,1]
        size_list: list of [H, W] 或 None，原始尺寸列表
    """
    # 检查数值范围并发出警告
    min_val = img_tensor.min().item()
    max_val = img_tensor.max().item()
    if min_val < -1 or max_val > 1:
        print(f"警告: img_tensor数值范围超出[-1,1]，实际范围: [{min_val:.4f}, {max_val:.4f}]")

    # 确保img_tensor在cpu上
    img_tensor = img_tensor.detach().cpu()
    B = img_tensor.shape[0]
    for i in range(B):
        img = img_tensor[i]  # [3, H, W]
        img_np = img.numpy()
        # [3, H, W] -> [H, W, 3]
        img_np = np.transpose(img_np, (1, 2, 0))
        # clip到[-1,1]
        img_np = np.clip(img_np, -1, 1)
        # 从[-1,1]转换到[0,255]
        img_np = ((img_np + 1.0) * 127.5).round().astype(np.uint8)
        # RGB->BGR
        img_np = img_np[..., [2, 1, 0]]
        # 如果需要resize
        if size_list is not None:
            h, w = size_list[i]
            img_np = cv2.resize(img_np, (w, h), interpolation=cv2.INTER_LINEAR)
        # 保存
        if not name:
            save_path = f"output_{i}.png"
            is_success, buffer = cv2.imencode('.png', img_np)
            if is_success:
                with open(save_path, 'wb') as f:
                    f.write(buffer.tobytes())
            print(f"Saved: {save_path}")
        else:
            save_path = f"{name}_{i}.png"
            is_success, buffer = cv2.imencode('.png', img_np)
            if is_success:
                with open(save_path, 'wb') as f:
                    f.write(buffer.tobytes())
            print(f"Saved: {save_path}")
