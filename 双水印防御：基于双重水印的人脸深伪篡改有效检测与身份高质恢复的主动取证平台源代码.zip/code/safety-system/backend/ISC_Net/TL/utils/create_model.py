import math
from ..network.model import Tamper_Loc
from ..network.subnet import subnet

def define_G(opt):
	"""
	根据给定的配置opt，定义并返回生成器网络Tamper_Loc实例。
	参数:
		opt (dict): 包含网络结构、数据集、缩放比例等信息的配置字典。

	返回:
		netG: 构建好的Tamper_Loc生成器网络实例
	"""
	# 获取子网络类型（如resnet、unet等）
	subnet_type = opt['network_G']['which_model_G']['subnet_type']  # DBNet
	# # 获取数据集相关配置
	# opt_datasets = opt['datasets']
	# 计算下采样次数，scale为放大倍数，取对数后得到下采样层数,scale=2
	down_num = int(math.log(opt['network_G']['scale'], 2)) 
	# 根据输入图像数量选择不同的子网络结构 ,num_image=1 
	if opt['num_image'] == 1:  
		# 单图像模式，两个子网络均使用'xavier'初始化 
		netG = Tamper_Loc(opt, subnet(subnet_type, 'xavier'), subnet(subnet_type, 'xavier'), down_num)
	else:
		# 多图像模式，第二个子网络使用'xavier_v2'初始化
		netG = Tamper_Loc(opt, subnet(subnet_type, 'xavier'), subnet(subnet_type, 'xavier_v2'), down_num)
	return netG