import numpy as np
from PIL import Image
import cv2

def generate_blue_image(width=512, height=512, save_path="blue_image_512x512.png"):
    """
    生成纯蓝色图像并保存
    
    Args:
        width: 图像宽度，默认512
        height: 图像高度，默认512
        save_path: 保存路径，默认"blue_image_512x512.png"
    """
    # 创建纯蓝色图像 (RGB格式，蓝色通道为255，其他通道为0)
    blue_image = np.zeros((height, width, 3), dtype=np.uint8)
    blue_image[:, :, 2] = 255  # RGB格式中蓝色是第3个通道
    
    # 使用PIL保存图像
    pil_image = Image.fromarray(blue_image)
    pil_image.save(save_path)
    print(f"纯蓝色图像已保存到: {save_path}")
    print(f"图像大小: {width}x{height}")
    
    return blue_image

def generate_blue_image_rgb(width=256, height=256, save_path="blue_image_rgb.png"):
    """
    生成纯蓝色图像(RGB格式)并保存
    
    Args:
        width: 图像宽度，默认256
        height: 图像高度，默认256
        save_path: 保存路径，默认"blue_image_rgb.png"
    """
    # 创建纯蓝色图像 (RGB格式，蓝色通道为255，其他通道为0)
    blue_image = np.zeros((height, width, 3), dtype=np.uint8)
    blue_image[:, :, 2] = 255  # RGB格式中蓝色是第3个通道
    
    # 使用PIL保存图像
    pil_image = Image.fromarray(blue_image)
    pil_image.save(save_path)
    print(f"纯蓝色图像(RGB)已保存到: {save_path}")
    print(f"图像大小: {width}x{height}")
    
    return blue_image

def generate_blue_image_cv2(width=256, height=256, save_path="blue_image_cv2.png"):
    """
    使用OpenCV生成纯蓝色图像并保存
    
    Args:
        width: 图像宽度，默认256
        height: 图像高度，默认256
        save_path: 保存路径，默认"blue_image_cv2.png"
    """
    # 创建纯蓝色图像 (BGR格式)
    blue_image = np.zeros((height, width, 3), dtype=np.uint8)
    blue_image[:, :, 0] = 255  # BGR格式中蓝色是第1个通道
    
    # 使用OpenCV保存图像
    cv2.imwrite(save_path, blue_image)
    print(f"纯蓝色图像(OpenCV)已保存到: {save_path}")
    print(f"图像大小: {width}x{height}")
    
    return blue_image

def main():
    """
    主函数：生成512x512的纯蓝色图像
    """
    print("正在生成512x512纯蓝色图像...")
    
    # 生成512x512的纯蓝色图像
    generate_blue_image(512, 512, "temp_results/blue_image_512x512.png")
    
    print("纯蓝色图像生成完成！")

if __name__ == "__main__":
    main() 
    
    
    
    
    