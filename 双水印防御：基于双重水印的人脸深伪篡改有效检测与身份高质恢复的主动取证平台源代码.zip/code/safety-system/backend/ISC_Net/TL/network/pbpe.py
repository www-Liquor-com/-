import torch.nn as nn
import torch
import torch.nn.functional as F
from ..utils.model_init import initialize_weights_xavier
from .transformer_block import TransformerBlock


class PredictiveModuleMIMO_prompt(nn.Module):
    def __init__(self, channel_in, nf, prompt_len=3, block_num_rbm=8, block_num_trans=4):
        super(PredictiveModuleMIMO_prompt, self).__init__()
        self.conv_in = nn.Conv2d(channel_in, nf, 3, 1, 1, bias=True)
        res_block = []
        trans_block = []
        for i in range(block_num_rbm):
            res_block.append(ResidualBlockNoBN(nf))
        for j in range(block_num_trans):
            trans_block.append(TransformerBlock(nf))

        self.res_block = nn.Sequential(*res_block)
        self.transformer_block = nn.Sequential(*trans_block)
        self.prompt = PromptGenBlock(prompt_dim=nf,prompt_len=prompt_len,prompt_size = 36,lin_dim = nf)
        self.fuse = nn.Conv2d(nf * 2, nf, 3, 1, 1, bias=True)

    def forward(self, x):
        x = self.conv_in(x)
        x = self.res_block(x)
        res = self.transformer_block(x) + x
        prompt = self.prompt(res)

        result = self.fuse(torch.cat([res, prompt], dim=1))

        return result



class PredictiveModuleMIMO(nn.Module):
    def __init__(self, channel_in, nf, block_num_rbm=8, block_num_trans=4):
        super(PredictiveModuleMIMO, self).__init__()
        self.conv_in = nn.Conv2d(channel_in, nf, 3, 1, 1, bias=True)
        res_block = []
        trans_block = []
        for i in range(block_num_rbm):
            res_block.append(ResidualBlockNoBN(nf))
        for j in range(block_num_trans):
            trans_block.append(TransformerBlock(nf))

        self.res_block = nn.Sequential(*res_block)
        self.transformer_block = nn.Sequential(*trans_block)

    def forward(self, x):
        x = self.conv_in(x)
        x = self.res_block(x)
        res = self.transformer_block(x) + x

        return res

class PredictiveModuleBit(nn.Module):
    def __init__(self, channel_in, nf, block_num_rbm=4, block_num_trans=2):
        super(PredictiveModuleBit, self).__init__()
        self.conv_in = nn.Conv2d(channel_in, nf, 3, 1, 1, bias=True)
        res_block = []
        trans_block = []
        for i in range(block_num_rbm):
            res_block.append(ResidualBlockNoBN(nf))
        for j in range(block_num_trans):
            trans_block.append(TransformerBlock(nf))
        
        blocks = 4
        layers = [ConvRelu(nf, 1, 2)]
        for _ in range(blocks - 1):
            layer = ConvRelu(1, 1, 2)
            layers.append(layer)
        self.layers = nn.Sequential(*layers)

        self.res_block = nn.Sequential(*res_block)
        self.transformer_block = nn.Sequential(*trans_block)

    def forward(self, x):
        x = self.conv_in(x)
        x = self.res_block(x)
        res = self.transformer_block(x) + x
        res = self.layers(res)

        return res



class PromptGenBlock(nn.Module):
    def __init__(self,prompt_dim=12,prompt_len=3,prompt_size = 36,lin_dim = 12):
        super(PromptGenBlock,self).__init__()
        self.prompt_param = nn.Parameter(torch.rand(1,prompt_len,prompt_dim,prompt_size,prompt_size))
        self.linear_layer = nn.Linear(lin_dim,prompt_len)
        self.conv3x3 = nn.Conv2d(prompt_dim,prompt_dim,kernel_size=3,stride=1,padding=1,bias=False)
        

    def forward(self,x):
        B,C,H,W = x.shape
        emb = x.mean(dim=(-2,-1))
        prompt_weights = F.softmax(self.linear_layer(emb),dim=1)
        prompt = prompt_weights.unsqueeze(-1).unsqueeze(-1).unsqueeze(-1) * self.prompt_param.unsqueeze(0).repeat(B,1,1,1,1,1).squeeze(1)
        prompt = torch.sum(prompt,dim=1)
        prompt = F.interpolate(prompt,(H,W),mode="bilinear")
        prompt = self.conv3x3(prompt)

        return prompt


class ResidualBlockNoBN(nn.Module):
    def __init__(self, nf=64, model='MIMO-VRN'):
        super(ResidualBlockNoBN, self).__init__()
        self.conv1 = nn.Conv2d(nf, nf, 3, 1, 1, bias=True)
        self.conv2 = nn.Conv2d(nf, nf, 3, 1, 1, bias=True)
        # honestly, there's no significant difference between ReLU and leaky ReLU in terms of performance here
        # but this is how we trained the model in the first place and what we reported in the paper
        if model == 'LSTM-VRN':
            self.relu = nn.ReLU(inplace=True)
        elif model == 'MIMO-VRN':
            self.relu = nn.LeakyReLU(negative_slope=0.2, inplace=True)

        # initialization
        initialize_weights_xavier([self.conv1, self.conv2], 0.1)

    def forward(self, x):
        identity = x
        out = self.relu(self.conv1(x))
        out = self.conv2(out)
        return identity + out



class ConvRelu(nn.Module):
    def __init__(self, channels_in, channels_out, stride=1, init_zero=False):
        super(ConvRelu, self).__init__()
        self.init_zero = init_zero
        if self.init_zero:
            self.layers = nn.Conv2d(channels_in, channels_out, 3, stride, padding=1)

        else:
            self.layers = nn.Sequential(
                nn.Conv2d(channels_in, channels_out, 3, stride, padding=1),
                nn.LeakyReLU(inplace=True)
            )

    def forward(self, x):
        return self.layers(x)
    