import torch.nn as nn
import torch


class InvNN(nn.Module):
    """
    InvNN（Invertible Neural Network）类，实现了可逆神经网络的结构。
    该网络由多个InvBlock组成，支持前向和反向传播，并可选计算雅可比行列式。

    输入数据格式为NCHW（Batch, Channel, Height, Width）。
    在前向传播过程中，输入x和x_h分别代表高阶分支和低阶分支的特征，维度通常为：
        x:   [N, channel_in_ho, H, W]
        x_h: [N, channel_in_hi, H, W]
    每经过一个InvBlock，通道数保持不变（除非InvBlock内部有通道变换），空间尺寸H, W通常保持不变。
    若后续有下采样操作（如PixelUnshuffle等），则会在InvBlock外部进行，当前结构中每个InvBlock仅对通道和空间特征做耦合变换。
    """
    def __init__(
        self, 
        channel_in_ho=3, 
        channel_in_hi=3, 
        subnet_constructor=None, 
        subnet_constructor_v2=None, 
        block_num=[], 
        down_num=2, 
        groups=None
    ): 
        """
        初始化InvNN。
        参数:
            channel_in_ho (int): 高阶分支输入通道数，默认3。
            channel_in_hi (int): 低阶分支输入通道数，默认3。
            subnet_constructor (callable): 构建G、H子网络的函数。
            subnet_constructor_v2 (callable): 构建F子网络的函数。
            block_num (list): 每个down采样阶段包含的InvBlock数量。
            down_num (int): down采样阶段的数量，默认2。
            groups (int): 分组卷积的组数。 
        """
        super(InvNN, self).__init__()
        operations = []  # 存储所有的InvBlock

        current_channel_ho = channel_in_ho  # 当前高阶分支通道数
        current_channel_hi = channel_in_hi  # 当前低阶分支通道数

        # 构建每个down采样阶段的InvBlock 
        # 输入x:   [N, current_channel_ho, H, W]
        # 输入x_h: [N, current_channel_hi, H, W]
        for i in range(down_num): # 2
            for j in range(block_num[i]): # [6,6]
                # 创建一个InvBlock并添加到operations 
                # 每个InvBlock输入输出的NCHW维度与上一层保持一致
                b = InvBlock(
                    subnet_constructor, 
                    subnet_constructor_v2, 
                    current_channel_ho, 
                    current_channel_hi, 
                    groups=groups
                )
                operations.append(b) 

        # 将所有InvBlock封装为ModuleList，便于参数管理
        self.operations = nn.ModuleList(operations)

    def forward(self, x, x_h, rev=False, cal_jacobian=False):
        """
        前向或反向传播。
        参数:
            x (Tensor): 高阶分支输入，形状[N, channel_in_ho, H, W]。
            x_h (Tensor): 低阶分支输入，形状[N, channel_in_hi, H, W]。
            rev (bool): 是否反向传播（逆变换），默认False。
            cal_jacobian (bool): 是否计算雅可比行列式，默认False。

        返回:
            若cal_jacobian为True，返回(x, x_h, jacobian)；
            否则返回(x, x_h)。

        维度说明：
            - 正向传播时，x和x_h的NCHW维度在每个InvBlock中保持不变。
            - 若有下采样或通道变换，需在InvBlock外部实现。
        """
        jacobian = 0  # 初始化雅可比行列式

        if not rev:
            # 正向传播：依次通过每个InvBlock
            # x, x_h: [N, C, H, W] -> [N, C, H, W]（每层维度不变）
            for op in self.operations:
                x, x_h = op.forward(x, x_h, rev)
                if cal_jacobian:
                    jacobian += op.jacobian(x, rev)
        else:
            # 反向传播：逆序通过每个InvBlock
            # x, x_h: [N, C, H, W] <- [N, C, H, W]（每层维度不变）
            for op in reversed(self.operations):
                x, x_h = op.forward(x, x_h, rev)
                if cal_jacobian:
                    jacobian += op.jacobian(x, rev)

        if cal_jacobian:
            # 返回输出及累计的雅可比行列式
            # 输出x, x_h的NCHW维度与输入一致
            return x, x_h, jacobian
        else:
            # 仅返回输出
            # 输出x, x_h的NCHW维度与输入一致
            return x, x_h



# 维度不变
class InvBlock(nn.Module):
    """
    可逆神经网络中的基本块（Invertible Block）。
    该模块实现了基于耦合结构的可逆变换，支持前向和反向传播，并可计算对数行列式（雅可比行列式）。
    """
    def __init__(self, subnet_constructor, subnet_constructor_v2, channel_num_ho, channel_num_hi, groups, clamp=1.):
        """
        初始化InvBlock。
        参数:
            subnet_constructor: 构建子网络（如卷积子网络）的函数，用于G和H。
            subnet_constructor_v2: 构建子网络的函数，用于F。
            channel_num_ho: 第一部分通道数（高阶分支）。
            channel_num_hi: 第二部分通道数（低阶分支）。
            groups: 分组卷积的组数，若为1则使用分组参数，否则不使用。
            clamp: 缩放因子，用于控制s的范围，防止数值不稳定。
        """
        super(InvBlock, self).__init__()
        self.split_len1 = channel_num_ho  # 第一分支通道数
        self.split_len2 = channel_num_hi  # 第二分支通道数
        self.clamp = clamp                # s的缩放因子

        # F: 低阶分支到高阶分支的子网络 
        self.F = subnet_constructor_v2(self.split_len2, self.split_len1, groups=groups)
        self.NF = NAFBlock(self.split_len2)  # F后的NAFBlock

        # G、H: 高阶分支到低阶分支的子网络
        # groups==1时，子网络支持分组卷积，否则不带groups参数 
        if groups == 1: 
            self.G = subnet_constructor(self.split_len1, self.split_len2, groups=groups)
            self.NG = NAFBlock(self.split_len1)
            self.H = subnet_constructor(self.split_len1, self.split_len2, groups=groups)
            self.NH = NAFBlock(self.split_len1)
        else:
            self.G = subnet_constructor(self.split_len1, self.split_len2)
            self.NG = NAFBlock(self.split_len1)
            self.H = subnet_constructor(self.split_len1, self.split_len2)
            self.NH = NAFBlock(self.split_len1)

    def forward(self, x1, x2, rev=False):
        """
        前向或反向传播。

        参数:
            x1: 第一分支输入（高阶分支），Tensor，形状[N, split_len1, H, W]
            x2: 第二分支输入（低阶分支），为list或tensor，形状[N, split_len2, H, W] 或 list[Tensor[N, split_len2, H, W]]
            rev: 是否反向传播（逆变换）。

        返回:
            y1, y2: 变换后的两部分输出。
                y1: Tensor[N, split_len1, H, W]
                y2: list[Tensor[N, split_len2, H, W]] 或 Tensor[N, split_len2, H, W]
        """
        # 维度说明:
        # x1: [N, split_len1, H, W]
        # x2: [N, split_len2, H, W] 或 list[Tensor[N, split_len2, H, W]]
        
        # 确保x2是列表格式
        if not isinstance(x2, list):
            x2 = [x2]
            
        if not rev:
            # 正向: y1 = x1 + NF(F(x2))
            # F: [N, split_len2, H, W] -> [N, split_len1, H, W]
            # NF: [N, split_len1, H, W] -> [N, split_len1, H, W]
            # x1: [N, split_len1, H, W]
            # y1: [N, split_len1, H, W]
            y1 = x1 + self.NF(self.F(x2[0]))  # 使用第一个元素作为F的输入
            # s: 由y1经过H和NH后，sigmoid归一化并缩放到[-clamp, clamp]
            # H: [N, split_len1, H, W] -> [N, split_len2, H, W]
            # NH: [N, split_len2, H, W] -> [N, split_len2, H, W]
            # s: [N, split_len2, H, W]
            self.s = self.clamp * (torch.sigmoid(self.NH(self.H(y1))) * 2 - 1)
            # y2: 对x2的每个元素做仿射变换（缩放+平移）
            # G: [N, split_len1, H, W] -> [N, split_len2, H, W]
            # NG: [N, split_len2, H, W] -> [N, split_len2, H, W]
            # x2i: [N, split_len2, H, W]
            # y2: list[Tensor[N, split_len2, H, W]]
            y2 = [x2i.mul(torch.exp(self.s)) + self.NG(self.G(y1)) for x2i in x2]
        else:
            # 反向: 先还原s 
            # x1: [N, split_len1, H, W]
            # H: [N, split_len1, H, W] -> [N, split_len2, H, W]
            # NH: [N, split_len2, H, W] -> [N, split_len2, H, W]
            # s: [N, split_len2, H, W]
            self.s = self.clamp * (torch.sigmoid(self.NH(self.H(x1))) * 2 - 1)
            # 逆仿射变换还原x2
            # G: [N, split_len1, H, W] -> [N, split_len2, H, W]
            # NG: [N, split_len2, H, W] -> [N, split_len2, H, W]
            # x2i: [N, split_len2, H, W]
            # y2: list[Tensor[N, split_len2, H, W]]
            y2 = [(x2i - self.NG(self.G(x1))).div(torch.exp(self.s)) for x2i in x2]
            # 逆向还原x1
            # F: [N, split_len2, H, W] -> [N, split_len1, H, W]
            # NF: [N, split_len1, H, W] -> [N, split_len1, H, W]
            # y1: [N, split_len1, H, W]
            y1 = x1 - self.NF(self.F(y2[0]))  # 使用第一个元素作为F的输入

        # 输出y1: [N, split_len1, H, W]
        # 输出y2: list[Tensor[N, split_len2, H, W]]
        return y1, y2  # 返回两部分（可拼接）



    def jacobian(self, x, rev=False):
        """
        计算当前变换的对数雅可比行列式（log-determinant of Jacobian）。

        参数:
            x: 输入张量（用于归一化），形状[N, ...]
            rev: 是否为逆变换。

        返回:
            jac: 对数雅可比行列式的均值（每个样本）。
        """
        # self.s: [N, split_len2, H, W]
        if not rev:
            jac = torch.sum(self.s)
        else:
            jac = -torch.sum(self.s)

        return jac / x.shape[0]  # 按batch归一化








# (N, C, H, W) -> (N, C, H, W)
class NAFBlock(nn.Module):
    """
    NAFBlock（Nonlinear Activation Free Block）模块实现。
    该模块首次提出于 NAFNet，用于图像复原等任务，特点是去除了传统的激活函数，采用门控和注意力机制实现非线性。
    结构上类似于 Transformer 的 FFN，但全部为卷积操作，且包含简化通道注意力和门控机制。
    """
    def __init__(self, c, DW_Expand=2, FFN_Expand=2, drop_out_rate=0.):
        """
        初始化 NAFBlock。
        参数:
            c (int): 输入特征通道数。
            DW_Expand (int): 深度可分离卷积通道扩展倍数，默认2。 
            FFN_Expand (int): FFN部分通道扩展倍数，默认2。 
            drop_out_rate (float): dropout概率，默认0（不使用dropout）。 
        """
        super().__init__()
        dw_channel = c * DW_Expand  # 深度可分离卷积的扩展通道数 

        # 1x1逐点卷积，升维，通道数： c -> dw_channel 
        self.conv1 = nn.Conv2d(
            in_channels=c, out_channels=dw_channel, kernel_size=1, padding=0, stride=1, groups=1, bias=True
        ) 
        # 3x3深度卷积（每个通道独立卷积） ,通道数： dw_channel -> dw_channel 
        self.conv2 = nn.Conv2d(
            in_channels=dw_channel, out_channels=dw_channel, kernel_size=3, padding=1, stride=1, groups=dw_channel, bias=True
        )
        
        # 1x1卷积，降维，通道数： dw_channel // 2 -> c
        self.conv3 = nn.Conv2d(
            in_channels=dw_channel // 2, out_channels=c, kernel_size=1, padding=0, stride=1, groups=1, bias=True
        )
        
        # 简化通道注意力（SCA）：全局平均池化+1x1卷积 
        self.sca = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),  # (N, C, H, W) -> (N, C, 1, 1) 
            # 通道数： dw_channel // 2 -> out_channels=dw_channel // 2 
            nn.Conv2d(
                in_channels=dw_channel // 2, out_channels=dw_channel // 2, kernel_size=1, padding=0, stride=1, groups=1, bias=True
            ),
        )
        # 这个SCA（简化通道注意力）只用全局平均池化+1x1卷积实现通道缩放，
        # 没有SE注意力里的非线性（如ReLU）和Sigmoid激活，结构更简单、计算更快，但表达能力略弱。
        # SE通常是AvgPool→FC→ReLU→FC→Sigmoid，这里是AvgPool→Conv1x1，直接线性变换。

        # SimpleGate门控机制
        self.sg = SimpleGate() 

        # FFN部分 
        ffn_channel = FFN_Expand * c  # FFN扩展通道数 
        # 1*1卷积，通道数： c -> ffn_channel 
        self.conv4 = nn.Conv2d(
            in_channels=c, out_channels=ffn_channel, kernel_size=1, padding=0, stride=1, groups=1, bias=True
        )
        # 1*1卷积，通道数： ffn_channel // 2 -> c  
        self.conv5 = nn.Conv2d(
            in_channels=ffn_channel // 2, out_channels=c, kernel_size=1, padding=0, stride=1, groups=1, bias=True
        )

        # 两个归一化层
        self.norm1 = LayerNorm2d(c)
        self.norm2 = LayerNorm2d(c)

        # Dropout层（可选）
        self.dropout1 = nn.Dropout(drop_out_rate) if drop_out_rate > 0. else nn.Identity()
        self.dropout2 = nn.Dropout(drop_out_rate) if drop_out_rate > 0. else nn.Identity()

        # 可学习缩放参数
        self.beta = nn.Parameter(torch.zeros((1, c, 1, 1)), requires_grad=True)
        self.gamma = nn.Parameter(torch.zeros((1, c, 1, 1)), requires_grad=True)

    def forward(self, inp):
        """
        前向传播。

        参数:
            inp (Tensor): 输入特征，形状为 (N, C, H, W)
        返回:
            Tensor: 输出特征，形状同输入
        """
        x = inp  # 保留输入，(N, C, H, W)

        # 第一阶段：归一化 
        x = self.norm1(x)  # (N, C, H, W) -> (N, C, H, W) 

        # 第一阶段：卷积与门控
        x = self.conv1(x)  # 1x1卷积升维，(N, C, H, W) -> (N, dw_channel, H, W)
        x = self.conv2(x)  # 3x3分组卷积，(N, dw_channel, H, W) -> (N, dw_channel, H, W)
        x = self.sg(x)     # SimpleGate门控，通道减半，(N, dw_channel, H, W) -> (N, dw_channel//2, H, W)
        x_sca = self.sca(x)  # SCA注意力，(N, dw_channel//2, H, W) -> (N, dw_channel//2, 1, 1)
        x = x * x_sca  # 广播相乘，(N, dw_channel//2, H, W)
        x = self.conv3(x)  # 1x1卷积降维，(N, dw_channel//2, H, W) -> (N, C, H, W)

        x = self.dropout1(x)  # Dropout（可选），(N, C, H, W)

        # 残差连接 + 可学习缩放
        y = inp + x * self.beta  # (N, C, H, W)

        # 第二阶段：FFN
        x = self.norm2(y)        # (N, C, H, W)
        x = self.conv4(x)        # 1x1卷积升维，(N, C, H, W) -> (N, ffn_channel, H, W)
        x = self.sg(x)           # SimpleGate门控，通道减半，(N, ffn_channel, H, W) -> (N, ffn_channel//2, H, W)
        x = self.conv5(x)        # 1x1卷积降维，(N, ffn_channel//2, H, W) -> (N, C, H, W)

        x = self.dropout2(x)     # Dropout（可选），(N, C, H, W)

        # 残差连接 + 可学习缩放
        return y + x * self.gamma  # (N, C, H, W)




# 首次提出于NAFNet,可用于替代GELU激活函数
class SimpleGate(nn.Module):
    """
    SimpleGate 模块实现。
    该模块将输入张量 x 在通道维度（dim=1）上平均分成两部分，然后对这两部分逐元素相乘。
    这种门控机制常用于轻量级注意力或特征交互中，能够引入非线性和特征选择能力。
    输入:
        x: 形状为 (N, C, H, W) 的张量，其中 C 必须为偶数（以便可以均分为两部分）
    输出:
        形状为 (N, C//2, H, W) 的张量，为 x 在通道维度均分后两部分的逐元素乘积
    """
    def forward(self, x):
        # 在通道维度将输入 x 平均分成两部分
        x1, x2 = x.chunk(2, dim=1)
        # 对分割后的两部分进行逐元素相乘
        return x1 * x2


class LayerNorm2d(nn.Module):
    """
    LayerNorm2d 实现：对每个样本的每个通道（C）在空间维度 (H, W) 上做归一化。
    本质上就是 ：InstanceNorm2d，可自定义缩放(weight)和偏置(bias)参数。
    """

    def __init__(self, channels, eps=1e-6):
        """
        初始化 LayerNorm2d 层。

        参数:
            channels (int): 输入特征的通道数。
            eps (float): 防止除零的小常数，提升数值稳定性。
        """
        super(LayerNorm2d, self).__init__()
        # weight: 缩放参数，初始为1，形状为 (channels,)
        self.register_parameter('weight', nn.Parameter(torch.ones(channels)))
        # bias: 偏置参数，初始为0，形状为 (channels,)
        self.register_parameter('bias', nn.Parameter(torch.zeros(channels)))
        # eps: 数值稳定性参数
        self.eps = eps

    def forward(self, x):
        """
        前向传播。
        参数:
            x (Tensor): 输入张量，形状为 (N, C, H, W)
        返回:
            归一化并仿射变换后的张量，形状同输入
        """
        # 调用自定义的 LayerNormFunction 实现归一化和仿射变换
        return LayerNormFunction.apply(x, self.weight, self.bias, self.eps)


class LayerNormFunction(torch.autograd.Function):
    """
    自定义的 LayerNorm 实现，继承自 torch.autograd.Function。
    实现了前向和反向传播，支持自动求导。
    自定义的：每个通道单独归一化（对每个 [H, W]），本质上类似于实例归一化 
    标准的：每个样本整体归一化（对 [C, H, W] 所有元素）。
    """

    @staticmethod
    def forward(ctx, x, weight, bias, eps):
        """
        前向传播函数。
        参数:
            ctx: 上下文对象，用于在前向和反向之间传递信息
            x: 输入张量，形状为 (N, C, H, W)
            weight: 缩放参数，形状为 (C,)
            bias: 偏置参数，形状为 (C,)
            eps: 数值稳定性参数，防止除零 
        返回:
            归一化并仿射变换后的张量
        """
        ctx.eps = eps  # 保存 eps 以便反向传播使用
        N, C, H, W = x.size()  # 获取输入张量的形状

        # 计算每个通道的均值 (在 dim=1 上求均值，保持维度)
        mu = x.mean(1, keepdim=True)
        # 计算每个通道的方差
        var = (x - mu).pow(2).mean(1, keepdim=True)
        # 标准化
        y = (x - mu) / (var + eps).sqrt()
        # 保存中间变量以便反向传播
        ctx.save_for_backward(y, var, weight)
        # 仿射变换（缩放和偏置）
        y = weight.view(1, C, 1, 1) * y + bias.view(1, C, 1, 1)
        return y

    @staticmethod
    def backward(ctx, grad_output):
        """
        反向传播函数。

        参数:
            ctx: 上下文对象，包含前向传播保存的变量
            grad_output: 损失对输出的梯度，形状为 (N, C, H, W)

        返回:
            对输入 x、weight、bias、eps 的梯度（eps 无需梯度，返回 None）
        """
        eps = ctx.eps  # 取出 eps

        N, C, H, W = grad_output.size()  # 获取梯度张量的形状
        # 取出前向传播保存的变量
        y, var, weight = ctx.saved_variables

        # 计算 grad_output 对 weight 的缩放
        g = grad_output * weight.view(1, C, 1, 1)
        # 计算 g 在通道维度上的均值
        mean_g = g.mean(dim=1, keepdim=True)
        # 计算 g*y 在通道维度上的均值
        mean_gy = (g * y).mean(dim=1, keepdim=True)
        # 计算输入 x 的梯度
        gx = 1. / torch.sqrt(var + eps) * (g - y * mean_gy - mean_g)

        # 计算 weight 的梯度: grad_output * y 在空间和 batch 上求和，再在通道上累加
        grad_weight = (grad_output * y).sum(dim=3).sum(dim=2).sum(dim=0)
        # 计算 bias 的梯度: grad_output 在空间和 batch 上求和，再在通道上累加
        grad_bias = grad_output.sum(dim=3).sum(dim=2).sum(dim=0)

        # 返回各参数的梯度，eps 不需要梯度，返回 None
        return gx, grad_weight, grad_bias, None
    
    
# 归一化层理解
"""
对于输入数据 x，形状为 (8, 3, H, W)，即 batch_size=8，channels=3，高=H，宽=W。

1. 批量归一化（BatchNorm2d）:
   - 统计维度: (N, H, W)，即对每个通道 c，统计所有 batch、空间位置的均值和方差。
   - 归一化方式: 对每个通道 c，使用所有样本和空间位置的均值/方差进行归一化。
   - 代码示例:
        bn = torch.nn.BatchNorm2d(3)
        out = bn(x)  # x.shape: (8, 3, H, W)


2. 层归一化（LayerNorm）:
   - 统计维度: (C, H, W)，即对每个样本 n，统计其所有通道和空间位置的均值和方差。
   - 归一化方式: 对每个样本整体归一化。
   - 代码示例:
        # LayerNorm 需要指定归一化的 shape
        ln = torch.nn.LayerNorm([3, H, W])
        out = ln(x)  # x.shape: (8, 3, H, W)

3. 实例归一化（InstanceNorm2d）:
   - 统计维度: (H, W)，即对每个样本 n、每个通道 c，统计其空间位置的均值和方差。
   - 归一化方式: 对每个样本的每个通道独立归一化。
   - 代码示例:
        inn = torch.nn.InstanceNorm2d(3)
        out = inn(x)  # x.shape: (8, 3, H, W)

# 总结：
# - BatchNorm2d: 对每个通道，跨 batch 和空间归一化
# - LayerNorm: 对每个样本，跨通道和空间归一化 
# - InstanceNorm2d: 对每个样本的每个通道，跨空间归一化
"""
