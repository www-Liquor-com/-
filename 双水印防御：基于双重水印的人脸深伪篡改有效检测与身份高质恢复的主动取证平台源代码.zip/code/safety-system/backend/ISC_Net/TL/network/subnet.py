import torch
import torch.nn as nn
import torch.nn.functional as F
from basicsr.archs.arch_util import flow_warp, ResidualBlockNoBN
from ..utils.model_init import initialize_weights_xavier,initialize_weights

class DenseBlock(nn.Module):
    """
    DenseBlock 模块实现。
    该模块由5个卷积层组成，采用稠密连接（Dense Connection）结构，每一层的输入都是前面所有层的输出的拼接。
    这种结构有助于特征复用和梯度流动，提升网络表达能力。
    主要用于特征提取和增强，常见于图像复原、超分辨等任务。
    """
    def __init__(self, channel_in, channel_out, init='xavier', gc=32, bias=True):
        """
        初始化 DenseBlock。

        参数:
            channel_in (int): 输入特征通道数。
            channel_out (int): 输出特征通道数。
            init (str): 权重初始化方式，'xavier' 或其他。
            gc (int): growth channel，每层输出的特征通道数（增长率），默认32。
            bias (bool): 卷积是否使用偏置，默认True。
        """
        super(DenseBlock, self).__init__()
        # 第一层卷积，输入为原始输入
        self.conv1 = nn.Conv2d(channel_in, gc, 3, 1, 1, bias=bias)
        # 第二层卷积，输入为原始输入和conv1输出的拼接
        self.conv2 = nn.Conv2d(channel_in + gc, gc, 3, 1, 1, bias=bias)
        # 第三层卷积，输入为原始输入、conv1、conv2输出的拼接
        self.conv3 = nn.Conv2d(channel_in + 2 * gc, gc, 3, 1, 1, bias=bias)
        # 第四层卷积，输入为原始输入、conv1、conv2、conv3输出的拼接
        self.conv4 = nn.Conv2d(channel_in + 3 * gc, gc, 3, 1, 1, bias=bias)
        # 第五层卷积，输入为原始输入、conv1、conv2、conv3、conv4输出的拼接，输出为目标通道数
        self.conv5 = nn.Conv2d(channel_in + 4 * gc, channel_out, 3, 1, 1, bias=bias)
        # 激活函数，LeakyReLU
        self.lrelu = nn.LeakyReLU(negative_slope=0.2, inplace=True)
        self.H = None  # 预留属性，未使用

        # 权重初始化
        if init == 'xavier':
            # 对前4个卷积层使用xavier初始化，增益0.1
            initialize_weights_xavier([self.conv1, self.conv2, self.conv3, self.conv4], 0.1)
        else:
            # 其他初始化方式
            initialize_weights([self.conv1, self.conv2, self.conv3, self.conv4], 0.1)
        # 最后一层单独初始化，增益为0
        initialize_weights(self.conv5, 0)

    def forward(self, x):
        """
        前向传播。

        参数:
            x (Tensor 或 list): 输入特征，形状为[N, channel_in, H, W]。
                                若为list，则取第一个元素。

        返回:
            x5 (Tensor): 输出特征，形状为[N, channel_out, H, W]。
        """
        # 若输入为list，取第一个元素
        if isinstance(x, list):
            x = x[0]
        # 第一层卷积+激活
        x1 = self.lrelu(self.conv1(x))
        # 第二层，输入拼接x和x1
        x2 = self.lrelu(self.conv2(torch.cat((x, x1), 1)))
        # 第三层，输入拼接x, x1, x2
        x3 = self.lrelu(self.conv3(torch.cat((x, x1, x2), 1)))
        # 第四层，输入拼接x, x1, x2, x3
        x4 = self.lrelu(self.conv4(torch.cat((x, x1, x2, x3), 1)))
        # 第五层，输入拼接x, x1, x2, x3, x4，不加激活
        x5 = self.conv5(torch.cat((x, x1, x2, x3, x4), 1))

        return x5

class DenseBlock_v2(nn.Module):
    def __init__(self, channel_in, channel_out, groups, init='xavier', gc=32, bias=True):
        super(DenseBlock_v2, self).__init__()
        self.conv1 = nn.Conv2d(channel_in, gc, 3, 1, 1, bias=bias)
        self.conv2 = nn.Conv2d(channel_in + gc, gc, 3, 1, 1, bias=bias)
        self.conv3 = nn.Conv2d(channel_in + 2 * gc, gc, 3, 1, 1, bias=bias)
        self.conv4 = nn.Conv2d(channel_in + 3 * gc, gc, 3, 1, 1, bias=bias)
        self.conv5 = nn.Conv2d(channel_in + 4 * gc, channel_out, 3, 1, 1, bias=bias)
        self.conv_final = nn.Conv2d(channel_out*groups, channel_out, 3, 1, 1, bias=bias)
        self.lrelu = nn.LeakyReLU(negative_slope=0.2, inplace=True)

        if init == 'xavier':
            initialize_weights_xavier([self.conv1, self.conv2, self.conv3, self.conv4, self.conv5], 0.1)
        else:
            initialize_weights([self.conv1, self.conv2, self.conv3, self.conv4, self.conv5], 0.1)
        initialize_weights(self.conv_final, 0)

    def forward(self, x):
        res = []
        for xi in x:
            x1 = self.lrelu(self.conv1(xi))
            x2 = self.lrelu(self.conv2(torch.cat((xi, x1), 1)))
            x3 = self.lrelu(self.conv3(torch.cat((xi, x1, x2), 1)))
            x4 = self.lrelu(self.conv4(torch.cat((xi, x1, x2, x3), 1)))
            x5 = self.lrelu(self.conv5(torch.cat((xi, x1, x2, x3, x4), 1)))
            res.append(x5)
        res = torch.cat(res, dim=1)
        res = self.conv_final(res)

        return res

def subnet(net_structure, init='xavier'):
    def constructor(channel_in, channel_out, groups=None):
        if net_structure == 'DBNet':
            if init == 'xavier':
                return DenseBlock(channel_in, channel_out, init)
            elif init == 'xavier_v2':
                return DenseBlock_v2(channel_in, channel_out, groups, 'xavier')
            else:
                return DenseBlock(channel_in, channel_out)
        else:
            return None

    return constructor
