import torch.nn as nn
from .Encoder_U import DW_Encoder
from .Decoder_U import DW_Decoder
from .Inv_arch import InvNN
from .common import DWT,IWT
from .pbpe import PredictiveModuleMIMO_prompt, PredictiveModuleMIMO, PredictiveModuleBit
import torch
dwt=DWT()
iwt=IWT()



class Tamper_Loc(nn.Module):
    """
    主模型类。
    该类整合了可逆神经网络 (InvNN)、预测模块 (PM) 和比特水印编解码模块，
    用于在图像中隐藏和提取信息。
    输入输出张量均为[B, C, H, W]，其中C=12。
    """
    def __init__(self, opt, subnet_constructor=None, subnet_constructor_v2=None, down_num=2):
        """
        初始化 Tamper_Loc 模型。

        参数:
            opt (dict): 包含所有配置选项的字典。
            subnet_constructor (function): 用于构建可逆网络中子网络的构造函数。
            subnet_constructor_v2 (function): 用于构建可逆网络中第二个子网络的构造函数（可选）。
            down_num (int): 下采样的次数。
        """
        super(Tamper_Loc, self).__init__() 
        # 从配置中获取模型和网络参数 
        self.model = opt['model']  # 模型名称 
        self.mode = opt['mode']    # 运行模式，如 'image' 或 'bit' 
        opt_net = opt['network_G'] # 生成器网络G的配置 
        self.num_image = opt['num_image'] # 处理的图像数量 ,num_image = 1 
        self.gop = opt['gop'] # 图像组 (Group of Pictures) 的大小 ，gop = 1 

        # 计算输入和输出通道数
        self.channel_in = opt_net['in_nc'] * self.gop #12*1
        self.channel_out = opt_net['out_nc'] * self.gop #12*1
        # 可逆网络 (IRN) 的高频和低频部分的通道数
        self.channel_in_hi = opt_net['in_nc'] * self.gop #12*1
        self.channel_in_ho = opt_net['in_nc'] * self.gop #12*1
        # 要隐藏的信息长度（比特数）
        self.message_len = opt['message_length'] #64

        # 获取网络块的数量配置
        self.block_num = opt_net['block_num'] # 可逆块的数量, [6,6]
        self.block_num_rbm = opt_net['block_num_rbm'] # 预测模块中残差块的数量,8
        self.block_num_trans = opt_net['block_num_trans'] # 预测模块中Transformer块的数量 4
        self.nf = self.channel_in_hi # 特征图数量，12

        # 初始化比特水印编码器和解码器 
        self.bitencoder = DW_Encoder(self.message_len, attention="se")  
        self.bitdecoder = DW_Decoder(self.message_len, attention="se")  
        
        # 初始化可逆神经网络 (Invertible Reversible Network) 
        self.irn = InvNN(self.channel_in_ho, self.channel_in_hi, subnet_constructor, subnet_constructor_v2, self.block_num, down_num, groups=self.num_image)

        # 根据配置选择是否使用带 prompt 的预测模块 
        if opt['prompt']:  
            # 使用带 prompt 的预测模块  （12，12*1，3, 8, 4）
            self.pm = PredictiveModuleMIMO_prompt(self.channel_in_ho, self.nf * self.num_image, opt['prompt_len'], block_num_rbm=self.block_num_rbm, block_num_trans=self.block_num_trans)
        else:
            # 使用标准的预测模块 
            self.pm = PredictiveModuleMIMO(self.channel_in_ho, self.nf * self.num_image, opt['prompt_len'], block_num_rbm=self.block_num_rbm, block_num_trans=self.block_num_trans) 
            # 初始化一个用于比特流预测的模块（在非prompt模式下）
            self.BitPM = PredictiveModuleBit(3, 4, block_num_rbm=4, block_num_trans=2) 


    def forward(self, x, x_h=None, message=None, rev=False, hs=[], direction='f'):
        """
        模型的前向传播函数。

        参数:
            x (Tensor): 主输入张量（原始载体图像），形状为 [B, C, H, W]，如 [1, 12, 512, 512]。
            x_h (Tensor, optional): 辅助输入张量（水印图像或要嵌入的图像/特征），形状同 x，默认为 None。
            message (Tensor, optional): 要隐藏的比特信息，形状为 [B, message_len]，如 [1, 64]。默认为 None。
            rev (bool, optional): 是否执行逆向操作。False为正向（隐写/编码），True为逆向（提取/解码）。默认为 False。
            hs (list, optional): 隐藏状态（未使用）。默认为 []。
            direction (str, optional): 方向（未使用）。默认为 'f'。

        返回:
            - 正向 (rev=False, mode="image"): 
                out_y (Tensor): 融合后图像，[B, C, H, W]，如 [1, 3, 512, 512] 
                out_y_h0 (Tensor): 融合后图像2，[B, C, H, W]，如 [1, 3, 512, 512] 
                encoded_image (Tensor): 含密图像，[B, C, H, W] 
            - 正向 (rev=False, mode="bit"):
                out_y (Tensor): 变换后图像，[B, C, H, W] 
                encoded_image (Tensor): 含密图像，[B, C, H, W] 
            - 逆向 (rev=True, mode="image"):
                out_x (Tensor): 恢复的原始图像，[B, C, H, W] 
                out_x_h (Tensor): 恢复的水印图像，[B, C, H, W] 
                out_z (Tensor): 预测的融合后图像2，用于内部可逆网络的输入，[B, C, H, W] 
                recmessage (Tensor): 解码出的比特信息，[B, message_len] 
            - 逆向 (rev=True, mode="bit"):
                recmessage (Tensor): 解码出的比特信息，[B, message_len] 
        """
        # 正向传播（隐写/编码过程）
        if not rev:
            if self.mode == "image":
                # 通过可逆网络进行正向计算
                # x: [B, C, H, W]，x_h: [B, C, H, W]
                # out_y, out_y_h: [B, C, H, W]
                out_y, out_y_h = self.irn(x, x_h, rev)
                # 对融合特征应用逆小波变换 (IWT)，还原空间域图像
                # out_y: [B, C, H, W]
                out_y = iwt(out_y) 
                out_y_h0 = iwt(out_y_h[0])  
                
                # 将比特信息 message 编码到 out_y 中，生成含密图像  
                # encoded_image: [B, C, H, W]  
                # encoded_image = self.bitencoder(out_y, message)  
                # return out_y, out_y_h0, encoded_image  
                return out_y, out_y_h0

            elif self.mode == "bit":
                # 在 'bit' 模式下，直接对输入图像进行 IWT 和比特编码
                # x: [B, C, H, W]
                out_y = iwt(x)
                # encoded_image: [B, C, H, W]
                encoded_image = self.bitencoder(out_y, message)
                return out_y, encoded_image

        # 逆向传播（提取/解码过程）
        else:
            if self.mode == "image":
                # 从含密图像 x [B, C, H, W] 中解码出隐藏的比特信息 
                # recmessage: [B, message_len]
                # recmessage = self.bitdecoder(x) 

                # 对含密图像 x 应用离散小波变换 (DWT)，得到频域特征 
                # x: [B, C, H, W] -> [B, C, H, W]
                x = dwt(x) 
                # 使用预测模块 pm 从 x（即融合特征）预测水印图像的特征 
                # out_z: [B, 1, C, H, W] 
                out_z = self.pm(x).unsqueeze(1)  
                # 调整预测出的特征形状以匹配 IRN 的输入要求 
                # out_z_new: list，每个元素 [B, C, H, W]，长度为 num_image 
                out_z_new = out_z.view(-1, self.num_image, self.channel_in, x.shape[-2], x.shape[-1])
                out_z_new = [out_z_new[:, i] for i in range(self.num_image)]
                # 通过可逆网络进行逆向计算，从融合特征和预测特征恢复出原始图像和水印图像
                # out_x, out_x_h: [B, C, H, W] 
                out_x, out_x_h = self.irn(x, out_z_new, rev)
                
                # return iwt(out_x), iwt(out_x_h[0]), iwt(out_z_new[0]), recmessage
                return iwt(out_x), iwt(out_x_h[0]), iwt(out_z_new[0])

            elif self.mode == "bit":
                # 在 'bit' 模式下，只进行比特信息解码
                # recmessage: [B, message_len]
                recmessage = self.bitdecoder(x)
                return recmessage
