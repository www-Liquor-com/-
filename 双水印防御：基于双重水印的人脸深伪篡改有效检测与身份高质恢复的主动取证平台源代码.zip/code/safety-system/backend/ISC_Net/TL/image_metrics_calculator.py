import os
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
import cv2
from skimage.metrics import structural_similarity as ssim
from skimage.metrics import peak_signal_noise_ratio as psnr
import lpips
import warnings
warnings.filterwarnings('ignore')

class ImageMetricsCalculator:
    def __init__(self, device='cuda' if torch.cuda.is_available() else 'cpu'):
        """
        初始化图像质量指标计算器
        
        Args:
            device: 计算设备 ('cuda' 或 'cpu')
        """
        self.device = device
        # 初始化LPIPS模型
        self.lpips_model = lpips.LPIPS(net='alex').to(device)
        
    def load_image(self, image_path):
        """
        加载图像并转换为numpy数组
        
        Args:
            image_path: 图像文件路径
            
        Returns:
            numpy.ndarray: 图像数组 (H, W, C)
        """
        if not os.path.exists(image_path):
            raise FileNotFoundError(f"图像文件不存在: {image_path}")
            
        # 使用PIL加载图像
        img = Image.open(image_path).convert('RGB')
        img_array = np.array(img)
        return img_array
    
    def resize_image(self, img, target_size):
        """
        将图像调整到目标大小
        
        Args:
            img: 输入图像 (numpy.ndarray)
            target_size: 目标大小 (height, width)
            
        Returns:
            numpy.ndarray: 调整大小后的图像
        """
        height, width = target_size
        # 使用cv2进行双线性插值调整大小
        resized_img = cv2.resize(img, (width, height), interpolation=cv2.INTER_LINEAR)
        return resized_img
    
    def calculate_psnr(self, img1, img2):
        """
        计算PSNR (Peak Signal-to-Noise Ratio)
        
        Args:
            img1: 参考图像 (numpy.ndarray)
            img2: 待评估图像 (numpy.ndarray)
            
        Returns:
            float: PSNR值
        """
        return psnr(img1, img2, data_range=255)
    
    def calculate_ssim(self, img1, img2):
        """
        计算SSIM (Structural Similarity Index)
        
        Args:
            img1: 参考图像 (numpy.ndarray)
            img2: 待评估图像 (numpy.ndarray)
            
        Returns:
            float: SSIM值
        """
        return ssim(img1, img2, data_range=255, channel_axis=2)
    
    def calculate_lpips(self, img1, img2):
        """
        计算LPIPS (Learned Perceptual Image Patch Similarity)
        
        Args:
            img1: 参考图像 (numpy.ndarray)
            img2: 待评估图像 (numpy.ndarray)
            
        Returns:
            float: LPIPS值
        """
        # 转换为torch张量并归一化到[-1, 1]
        img1_tensor = torch.from_numpy(img1).float().permute(2, 0, 1).unsqueeze(0) / 127.5 - 1
        img2_tensor = torch.from_numpy(img2).float().permute(2, 0, 1).unsqueeze(0) / 127.5 - 1
        
        # 移动到指定设备
        img1_tensor = img1_tensor.to(self.device)
        img2_tensor = img2_tensor.to(self.device)
        
        # 计算LPIPS
        with torch.no_grad():
            lpips_value = self.lpips_model(img1_tensor, img2_tensor).item()
        
        return lpips_value
    
    def calculate_all_metrics(self, img1_path, img2_path):
        """
        计算两个图像的所有质量指标
        
        Args:
            img1_path: 参考图像路径
            img2_path: 待评估图像路径
            
        Returns:
            dict: 包含所有指标的字典
        """
        print(f"正在加载图像...")
        print(f"参考图像: {img1_path}")
        print(f"待评估图像: {img2_path}")
        
        # 加载图像
        img1 = self.load_image(img1_path)
        img2 = self.load_image(img2_path)
        
        print(f"参考图像大小: {img1.shape}")
        print(f"待评估图像大小: {img2.shape}")
        
        # 如果图像大小不同，将img2调整到img1的大小
        if img1.shape[:2] != img2.shape[:2]:
            print(f"图像大小不同，正在将待评估图像调整到参考图像大小...")
            img2 = self.resize_image(img2, img1.shape[:2])
            print(f"调整后待评估图像大小: {img2.shape}")
        
        # 计算各项指标
        print("正在计算PSNR...")
        psnr_value = self.calculate_psnr(img1, img2)
        
        print("正在计算SSIM...")
        ssim_value = self.calculate_ssim(img1, img2)
        
        print("正在计算LPIPS...")
        lpips_value = self.calculate_lpips(img1, img2)
        
        # 返回结果
        results = {
            'PSNR': psnr_value,
            'SSIM': ssim_value,
            'LPIPS': lpips_value
        }
        
        return results

def main():
    """
    主函数：计算指定两个图像的质量指标
    """
    # 图像路径
    # img1_path = r"E:\DataSets\IdFMark\images\test_256\00002.png"
    # img2_path = "temp_results/3_图像-比特水印图片_0.png"
    img1_path = "temp_results/blue_image_512x512.png"  
    img2_path = "temp_results/5_提取的水印图片_0.png"  
    
    # 创建计算器实例
    calculator = ImageMetricsCalculator()
    
    try:
        # 计算所有指标
        results = calculator.calculate_all_metrics(img1_path, img2_path)
        
        # 打印结果
        print("\n" + "="*50)
        print("图像质量评估结果")
        print("="*50)
        print(f"PSNR: {results['PSNR']:.4f} dB")
        print(f"SSIM: {results['SSIM']:.4f}")
        print(f"LPIPS: {results['LPIPS']:.4f}")
        print("="*50)
        
        # 指标说明
        print("\n指标说明:")
        print("- PSNR (Peak Signal-to-Noise Ratio): 峰值信噪比，值越高表示图像质量越好")
        print("- SSIM (Structural Similarity Index): 结构相似性指数，值越接近1表示图像越相似")
        print("- LPIPS (Learned Perceptual Image Patch Similarity): 学习感知图像块相似性，值越低表示图像越相似")
        
    except Exception as e:
        print(f"计算过程中出现错误: {str(e)}")

if __name__ == "__main__":
    main() 

