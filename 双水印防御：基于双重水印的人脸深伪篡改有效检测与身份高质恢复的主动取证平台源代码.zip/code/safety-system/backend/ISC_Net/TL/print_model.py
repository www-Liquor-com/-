import torch

ckpt = torch.load('checkpoints/degrade.pth', map_location='cpu')
if 'state_dict' in ckpt:
    state_dict = ckpt['state_dict']
else:
    state_dict = ckpt

print('所有参数名:')
for k in state_dict.keys():
    print(k)

print('\n模型包含的主要部分:')
modules = set(k.split('.')[0] for k in state_dict.keys())
for m in modules:
    print(m) 
    


