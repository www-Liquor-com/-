import os
import glob
import torch
import random
import pickle
from PIL import Image
from torch.utils import data
from torchvision import transforms as T
from torch.utils.data import Dataset
from torchvision import transforms


class ImgFeaDataset(Dataset):
    """
    用于加载图像和对应特征向量的数据集类
    
    参数:
        img_path (str): 图像文件所在目录
        fea_path (str): 特征向量文件路径（.pkl文件）
    """
    def __init__(self, img_path, fea_path):
        super(ImgFeaDataset, self).__init__()
        self.img_path = img_path 
        
        # 获取图像文件列表
        self.img_list = [f for f in os.listdir(img_path) if f.endswith(('.png', '.jpg', '.jpeg'))]
        
        # 确保特征文件路径是.pkl文件
        if not fea_path.endswith('.pkl'):
            fea_path = os.path.join(fea_path, 'train_256_features.pkl')
        
        # 加载特征字典
        try:
            with open(fea_path, 'rb') as f:
                self.features_dict = pickle.load(f)
        except Exception as e:
            print(f"Error loading feature file {fea_path}: {str(e)}")
            raise
        
        # 定义图像预处理转换
        self.transform = transforms.Compose([
            transforms.ToTensor(),
        ])

    def __getitem__(self, index):
        """
        获取数据集中的一个样本
        
        参数:
            index (int): 样本索引
            
        返回:
            tuple: (图像张量, 特征向量张量)
        """
        # 获取图像文件名
        img_name = self.img_list[index]
        
        # 加载图像
        img = Image.open(os.path.join(self.img_path, img_name)).convert("RGB")
        img = self.transform(img)
        
        # 从特征字典中获取特征
        if img_name in self.features_dict:
            feature = torch.from_numpy(self.features_dict[img_name]).float()
            # 确保特征维度正确
            if len(feature.shape) > 1:
                feature = feature.squeeze()  # 从 [1, 512] 变成 [512]
        else:
            # 如果特征不存在，返回全零向量
            print(f"！！！警告：图像 {img_name} 的特征在字典中未找到，将使用零向量代替")
            feature = torch.zeros(512)  # 使用正确的特征维度 [512]
        
        return img, feature 

    def __len__(self):
        """
        返回数据集的大小
        
        返回:
            int: 数据集中的样本数量
        """
        return len(self.img_list) 




class data_prefetcher():
    """
    数据预取器类
    用于在GPU上异步预加载和预处理数据，提高训练效率
    实现了数据预加载、标准化和GPU传输的流水线操作
    """
    def __init__(self, loader):
        """
        初始化数据预取器
        Args:
            loader: 数据加载器对象
        """
        self.loader = loader
        self.dataiter = iter(loader)
        # 创建CUDA流用于异步操作
        self.stream = torch.cuda.Stream()
        # # ImageNet数据集的RGB通道均值，用于标准化 
        # self.mean = torch.tensor([0.485, 0.456, 0.406]).cuda().view(1,3,1,1) 
        # # ImageNet数据集的RGB通道标准差，用于标准化 
        # self.std = torch.tensor([0.229, 0.224, 0.225]).cuda().view(1,3,1,1) 
        self.num_images = len(loader)
        self.preload()

    def preload(self):
        """
        预加载下一批数据
        在CUDA流中异步执行数据加载和预处理
        """
        try:
            # 尝试获取下一批数据
            self.src_image, self.src_feature = next(self.dataiter)
        except StopIteration:
            # 如果到达数据末尾，重新开始
            self.dataiter = iter(self.loader)
            self.src_image, self.src_feature = next(self.dataiter)
            
        # 在CUDA流中异步执行数据预处理
        with torch.cuda.stream(self.stream):
            # 将图像数据转移到GPU并进行标准化
            self.src_image = self.src_image.cuda(non_blocking=True)
            # self.src_image = self.src_image.sub_(self.mean).div_(self.std) 
            # 将特征数据转移到GPU 
            self.src_feature = self.src_feature.cuda(non_blocking=True)

    def next(self):
        """
        获取下一批预处理好的数据
        Returns:
            tuple: (src_image, src_feature) 预处理后的图像和特征
        """
        # 等待当前CUDA流完成
        torch.cuda.current_stream().wait_stream(self.stream)
        src_image = self.src_image
        src_feature = self.src_feature
        # 预加载下一批数据
        self.preload()
        return src_image, src_feature
    
    def __len__(self):
        """
        返回数据集中的图像总数
        Returns:
            int: 图像总数
        """
        return self.num_images




def GetLoader(dataset_path, 
             fea_path, 
             batch_size=16, 
             dataloader_workers=8):  
    """
    构建并返回数据加载器
    Args:
        dataset_roots: 图像数据集根目录
        fea_path: 特征向量文件路径
        batch_size: 批次大小，默认为16
        dataloader_workers: 数据加载的工作进程数，默认为8
    Returns:
        data_prefetcher: 数据预取器对象
    """
    num_workers = dataloader_workers
    data_root = dataset_path
    
    # 创建数据集对象
    content_dataset = ImgFeaDataset( 
                            data_root, 
                            fea_path)
    
    # 创建数据加载器 
    content_data_loader = data.DataLoader( 
                            dataset=content_dataset,
                            batch_size=batch_size,
                            drop_last=True,
                            shuffle=True,
                            num_workers=num_workers,
                            pin_memory=True) 
    
    # 创建数据预取器 
    prefetcher = data_prefetcher(content_data_loader) 
    return prefetcher 

def denorm(x): 
    """
    将标准化后的图像数据转换回[0,1]范围 
    Args: 
        x: 标准化后的图像数据，范围在[-1,1] 
    Returns: 
        tensor: 转换后的图像数据，范围在[0,1] 
    """ 
    out = (x + 1) / 2 
    return out.clamp_(0, 1) 






