import os
import torch
import sys
import time

class BaseModel(torch.nn.Module):
    """
    模型的基础类
    提供了模型的基本功能实现，包括初始化、保存、加载等
    所有具体的模型类都应该继承这个基类
    """
    def initialize(self, opt):
        """
        初始化模型的基本参数
        Args:
            opt: 配置参数对象，包含训练相关的各种设置
        """
        self.opt = opt
        self.gpu_ids = opt.gpu_ids  # GPU设备ID列表
        self.isTrain = opt.isTrain  # 是否为训练模式
        self.Tensor = torch.cuda.FloatTensor if self.gpu_ids else torch.Tensor  # 根据是否有GPU选择张量类型

        # 创建包含当前时间的保存路径 
        if getattr(self.opt, 'save_dir', None): 
            self.save_dir = self.opt.save_dir
        else:
            current_time = time.strftime("%Y%m%d_%H%M%S")
            save_name = f'{opt.name}_{current_time}'
            self.save_dir = os.path.join(opt.checkpoints_dir, save_name)  # 模型保存路径带时间戳
            # 确保目录存在 
            if not os.path.exists(self.save_dir):
                os.makedirs(self.save_dir) 
        print(f'BaseModel的保存路径为：{self.save_dir}')

    def set_input(self, input):
        """
        设置模型的输入数据
        Args:
            input: 输入数据
        """
        self.input = input

    def forward(self):
        """
        前向传播函数
        需要在子类中实现具体的计算逻辑
        """
        pass

    # 在测试阶段使用，不进行反向传播
    def test(self):
        """
        测试模式下的前向传播
        不进行反向传播
        """
        pass

    def get_image_paths(self):
        """
        获取图像路径 
        需要在子类中实现 
        """
        pass

    def optimize_parameters(self):
        """
        优化模型参数 
        需要在子类中实现具体的优化逻辑 
        """
        pass

    def get_current_visuals(self):
        """
        获取当前的可视化结果
        Returns:
            当前输入数据
        """
        return self.input

    def get_current_errors(self):
        """
        获取当前的误差信息
        Returns:
            空字典，需要在子类中实现具体的误差计算
        """
        return {}

    def save(self, label):
        """
        保存模型
        Args:
            label: 保存标签
        """
        pass
    
    # 辅助保存函数，可被子类使用 
    def save_network(self, network, network_label, epoch_label, step_label, gpu_ids=None):
        """
        保存网络模型参数
        Args:
            network: 要保存的网络模型 
            network_label: 网络标签（如'G'表示生成器）
            epoch_label: 训练轮次标签
            gpu_ids: GPU设备ID列表 
        """
        save_filename = '{}_{}_net_{}.pth'.format(epoch_label, step_label, network_label) 
        save_path = os.path.join(self.save_dir, save_filename)
        torch.save(network.cpu().state_dict(), save_path)
        if torch.cuda.is_available():
            network.cuda()

    # 辅助保存优化器状态的函数，可被子类使用 
    def save_optim(self, network, network_label, epoch_label, gpu_ids=None):
        """
        保存优化器状态
        Args:
            network: 优化器对象
            network_label: 网络标签
            epoch_label: 训练轮次标签
            gpu_ids: GPU设备ID列表
        """
        save_filename = '{}_optim_{}.pth'.format(epoch_label, network_label)
        save_path = os.path.join(self.save_dir, save_filename)
        torch.save(network.state_dict(), save_path)


    # 辅助加载函数，可被子类使用
    def load_network(self, network, save_path): 
        """
        加载网络模型参数
        Args:
            network: 要加载参数的目标网络
            save_path: 保存路径
        """
        if not os.path.isfile(save_path):
            print('%s 不存在' % save_path)
            raise('预训练模型不存在')
        else:
            #network.load_state_dict(torch.load(save_path))
            try:
                # 尝试直接加载模型参数
                network.load_state_dict(torch.load(save_path))
                print("从 %s 加载模型参数成功" % (save_path))
            except:   
                # 如果直接加载失败，尝试处理参数不匹配的情况
                pretrained_dict = torch.load(save_path)                
                model_dict = network.state_dict()
                try:
                    # 只加载预训练模型中存在的层
                    pretrained_dict = {k: v for k, v in pretrained_dict.items() if k in model_dict}                    
                    network.load_state_dict(pretrained_dict)
                    if self.opt.verbose:
                        print('预训练网络包含多余的层；仅加载需要使用的层')
                except:
                    # 处理预训练模型层数较少的情况
                    print('预训练网络包含的层较少；以下层未初始化:')
                    for k, v in pretrained_dict.items():                      
                        if v.size() == model_dict[k].size():
                            model_dict[k] = v

                    if sys.version_info >= (3,0):
                        not_initialized = set()
                    else:
                        from sets import Set
                        not_initialized = Set()                    

                    # 记录未初始化的层
                    for k, v in model_dict.items():
                        if k not in pretrained_dict or v.size() != pretrained_dict[k].size():
                            not_initialized.add(k.split('.')[0])
                    
                    print(sorted(not_initialized)) 
                    network.load_state_dict(model_dict)

    # 辅助加载优化器状态的函数，可被子类使用 
    def load_optim(self, network, network_label, epoch_label, save_dir=''):        
        """
        加载优化器状态
        Args:
            network: 优化器对象
            network_label: 网络标签
            epoch_label: 训练轮次标签
            save_dir: 保存目录，默认为空
        """
        save_filename = '%s_optim_%s.pth' % (epoch_label, network_label)
        if not save_dir:
            save_dir = self.save_dir
        save_path = os.path.join(save_dir, save_filename)        
        if not os.path.isfile(save_path):
            print('文件 %s 尚不存在！' % save_path)
            if network_label == 'G':
                raise('生成器必须存在！')
        else:
            #network.load_state_dict(torch.load(save_path))
            try:
                # 尝试加载优化器状态
                network.load_state_dict(torch.load(save_path, map_location=torch.device("cpu")))
            except:   
                # 处理参数不匹配的情况
                pretrained_dict = torch.load(save_path, map_location=torch.device("cpu"))                
                model_dict = network.state_dict()
                try:
                    # 只加载预训练优化器中存在的参数
                    pretrained_dict = {k: v for k, v in pretrained_dict.items() if k in model_dict}                    
                    network.load_state_dict(pretrained_dict)
                    if self.opt.verbose:
                        print('预训练网络 %s 包含多余的层；仅加载需要使用的层' % network_label)
                except:
                    # 处理预训练优化器参数较少的情况
                    print('预训练网络 %s 包含的层较少；以下层未初始化:' % network_label)
                    for k, v in pretrained_dict.items():                      
                        if v.size() == model_dict[k].size():
                            model_dict[k] = v

                    if sys.version_info >= (3,0):
                        not_initialized = set()
                    else:
                        from sets import Set
                        not_initialized = Set()                    

                    # 记录未初始化的参数
                    for k, v in model_dict.items():
                        if k not in pretrained_dict or v.size() != pretrained_dict[k].size():
                            not_initialized.add(k.split('.')[0])
                    
                    print(sorted(not_initialized))
                    network.load_state_dict(model_dict)                  

    def update_learning_rate():
        """
        更新学习率
        需要在子类中实现具体的学习率更新策略
        """
        pass
