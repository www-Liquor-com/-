import os
import math
import numpy as np
import PIL

def mkdirs(paths):
    if isinstance(paths, list) and not isinstance(paths, str):
        for path in paths:
            mkdir(path)
    else:
        mkdir(paths)


def mkdir(path):
    if not os.path.exists(path):
        os.makedirs(path)
        

def postprocess(x):
    """[0,1] to uint8."""
    
    x = np.clip(255 * x, 0, 255)
    x = np.asarray(x, dtype=np.uint8)
    return x

def tile(X, rows, cols):
    """Tile images for display."""
    tiling = np.zeros((rows * X.shape[1], cols * X.shape[2], X.shape[3]), dtype = X.dtype)
    for i in range(rows):
        for j in range(cols):
            idx = i * cols + j
            if idx < X.shape[0]:
                img = X[idx,...]
                tiling[
                        i*X.shape[1]:(i+1)*X.shape[1],
                        j*X.shape[2]:(j+1)*X.shape[2],
                        :] = img
    return tiling





def plot_batch(X, out_path):
    """Save batch of images tiled in 3 rows."""
    n_channels = X.shape[3]
    if n_channels > 3:
        X = X[:,:,:,np.random.choice(n_channels, size = 3)]
    
    X = postprocess(X)
    
    # 计算每行的图像数量 
    images_per_row = X.shape[0] // 3
    
    # 创建三行布局
    rows = 3
    cols = images_per_row
    
    # 使用tile函数创建图像网格
    canvas = tile(X, rows, cols)
    canvas = np.squeeze(canvas)
    
    # 保存图像
    PIL.Image.fromarray(canvas).save(out_path) 