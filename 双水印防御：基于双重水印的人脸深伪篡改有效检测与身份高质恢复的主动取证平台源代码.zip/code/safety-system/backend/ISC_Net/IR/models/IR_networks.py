import torch
import torch.nn as nn


class InstanceNorm(nn.Module):
    """
    实例归一化层
    对每个样本的每个通道分别进行归一化，保持每个样本的特征独立性
    主要用于风格迁移任务，可以更好地保持图像的风格特征
    """
    def __init__(self, epsilon=1e-8):
        """
        初始化实例归一化层
        Args:
            epsilon: 数值稳定性参数，防止除零错误
        @notice: 避免原地操作，防止梯度计算错误
        """
        super(InstanceNorm, self).__init__()
        self.epsilon = epsilon

    def forward(self, x):
        """
        前向传播函数
        Args:
            x: 输入张量，形状为 [batch_size, channels, height, width]
        Returns:
            归一化后的张量，保持输入形状不变
        """
        # 计算每个通道的均值
        x = x - torch.mean(x, (2, 3), True)
        # 计算每个通道的方差
        tmp = torch.mul(x, x) # or x ** 2
        # 计算标准差并添加epsilon防止除零
        tmp = torch.rsqrt(torch.mean(tmp, (2, 3), True) + self.epsilon)
        # 应用归一化
        return x * tmp



class ApplyStyle(nn.Module):
    """
    风格应用模块
    将潜在向量转换为风格参数，并应用到特征图上
    """
    def __init__(self, latent_size, channels):
        """
        初始化风格应用模块
        Args:
            latent_size: 潜在向量的维度
            channels: 特征图的通道数
        """
        super(ApplyStyle, self).__init__()
        # 线性层将潜在向量转换为风格参数
        self.linear = nn.Linear(latent_size, channels * 2)

    def forward(self, x, latent):
        """
        前向传播函数
        Args:
            x: 输入特征图，形状为 [batch_size, channels, height, width]
            latent: 潜在向量，形状为 [batch_size, latent_size]
        Returns:
            应用风格后的特征图，保持输入形状不变
        """
        # 将潜在向量转换为风格参数
        style = self.linear(latent)  # style => [batch_size, n_channels*2]
        # 重塑风格参数以便于广播
        shape = [-1, 2, x.size(1), 1, 1]
        style = style.view(shape)    # [batch_size, 2, n_channels, ...]
        # 应用风格变换：x * (style[:, 0] + 1.) + style[:, 1]
        # 这里使用了一个缩放因子1，可以根据需要调整
        x = x * (style[:, 0] * 1 + 1.) + style[:, 1] * 1
        return x


class ResnetBlock_Adain(nn.Module):
    """
    带有AdaIN（自适应实例归一化）的残差块
    结合了残差连接和风格注入，用于特征转换
    """
    def __init__(self, dim, latent_size, padding_type, activation=nn.ReLU(True)):
        """
        初始化残差块
        Args:
            dim: 特征维度（通道数）
            latent_size: 潜在向量的维度
            padding_type: 填充类型，可选 'reflect', 'replicate', 'zero'
            activation: 激活函数，默认为ReLU
        """
        super(ResnetBlock_Adain, self).__init__()

        # 第一个卷积层
        p = 0
        conv1 = []
        # 根据填充类型设置填充层
        if padding_type == 'reflect':
            conv1 += [nn.ReflectionPad2d(1)]
        elif padding_type == 'replicate':
            conv1 += [nn.ReplicationPad2d(1)]
        elif padding_type == 'zero':
            p = 1
        else:
            raise NotImplementedError('padding [%s] is not implemented' % padding_type)
        # 添加卷积层和实例归一化
        conv1 += [nn.Conv2d(dim, dim, kernel_size=3, padding = p), InstanceNorm()]
        self.conv1 = nn.Sequential(*conv1)
        # 添加风格注入层
        self.style1 = ApplyStyle(latent_size, dim)
        self.act1 = activation

        # 第二个卷积层
        p = 0
        conv2 = []
        # 根据填充类型设置填充层
        if padding_type == 'reflect':
            conv2 += [nn.ReflectionPad2d(1)]
        elif padding_type == 'replicate':
            conv2 += [nn.ReplicationPad2d(1)]
        elif padding_type == 'zero':
            p = 1
        else:
            raise NotImplementedError('padding [%s] is not implemented' % padding_type)
        # 添加卷积层和实例归一化
        conv2 += [nn.Conv2d(dim, dim, kernel_size=3, padding=p), InstanceNorm()]
        self.conv2 = nn.Sequential(*conv2)
        # 添加风格注入层
        self.style2 = ApplyStyle(latent_size, dim)

    def forward(self, x, dlatents_in_slice):
        """
        前向传播函数
        Args:
            x: 输入特征图
            dlatents_in_slice: 潜在向量，用于风格注入
        Returns:
            经过残差块处理后的特征图
        """
        # 第一个卷积层
        y = self.conv1(x)
        # 注入风格
        y = self.style1(y, dlatents_in_slice)
        # 激活函数
        y = self.act1(y)
        # 第二个卷积层
        y = self.conv2(y)
        # 注入风格
        y = self.style2(y, dlatents_in_slice)
        # 残差连接
        out = x + y
        return out



class IR_Model(nn.Module):
    """
    身份恢复网络，使用AdaIN（Adaptive Instance Normalization）进行身份特征注入
    主要功能：将原始人脸的身份特征注入到伪造图像中
    """
    def __init__(self, input_nc, output_nc, latent_size, n_blocks=9, deep=False,
                 norm_layer=nn.BatchNorm2d,
                 padding_type='reflect'):
        """
        参数说明：
        input_nc: 输入通道数（RGB图像为3）
        output_nc: 输出通道数（RGB图像为3）
        latent_size: 身份特征向量的维度
        n_blocks: 瓶颈层中ResnetBlock_Adain块的数量
        deep: 是否使用更深的网络结构
        norm_layer: 归一化层的类型
        padding_type: 填充类型
        """
        assert (n_blocks >= 0)
        super(IR_Model, self).__init__()
        activation = nn.ReLU(True)
        self.deep = deep

        # 第一层：初始特征提取
        # 使用7x7卷积核进行初步特征提取，保持空间分辨率
        self.first_layer = nn.Sequential(
            nn.ReflectionPad2d(3),  # 反射填充，保持边缘连续性
            nn.Conv2d(input_nc, 64, kernel_size=7, padding=0),
            norm_layer(64), 
            activation
        )

        # 下采样路径：逐步降低特征图分辨率，增加通道数
        # 每次下采样分辨率减半，通道数翻倍
        self.down1 = nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=3, stride=2, padding=1),
            norm_layer(128), 
            activation
        )
        self.down2 = nn.Sequential(
            nn.Conv2d(128, 256, kernel_size=3, stride=2, padding=1),
            norm_layer(256), 
            activation
        )
        self.down3 = nn.Sequential(
            nn.Conv2d(256, 512, kernel_size=3, stride=2, padding=1),
            norm_layer(512), 
            activation
        )
        
        # 可选的额外下采样层（当deep=True时使用）
        if self.deep:
            self.down4 = nn.Sequential(
                nn.Conv2d(512, 512, kernel_size=3, stride=2, padding=1),
                norm_layer(512), 
                activation
            )

        # 瓶颈层：包含多个ResnetBlock_Adain块
        # 在这里进行身份特征注入
        BN = []
        for i in range(n_blocks):
            BN += [
                ResnetBlock_Adain(512, latent_size=latent_size, 
                                padding_type=padding_type, 
                                activation=activation)
            ]
        self.BottleNeck = nn.Sequential(*BN)

        # 上采样路径：逐步恢复特征图分辨率，减少通道数
        # 使用双线性插值进行上采样，保持图像质量
        if self.deep:
            self.up4 = nn.Sequential(
                nn.Upsample(scale_factor=2, mode='bilinear'),
                nn.Conv2d(512, 512, kernel_size=3, stride=1, padding=1),
                nn.BatchNorm2d(512), 
                activation
            )
        self.up3 = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='bilinear'),
            nn.Conv2d(512, 256, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(256), 
            activation
        )
        self.up2 = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='bilinear'),
            nn.Conv2d(256, 128, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(128), 
            activation
        )
        self.up1 = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='bilinear'),
            nn.Conv2d(128, 64, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(64), 
            activation
        )

        # 最后一层：生成最终图像
        # 使用7x7卷积核和Tanh激活函数生成RGB图像
        self.last_layer = nn.Sequential(
            nn.ReflectionPad2d(3),
            nn.Conv2d(64, output_nc, kernel_size=7, padding=0),
            nn.Tanh()
        )


    def forward(self, input, dlatents):
        """
        前向传播过程
        参数：
        input: 输入图像 (3x224x224)
        dlatents: 身份特征向量
        返回：
        生成的换脸图像
        """
        x = input  # 输入图像: 3x224x224

        # 编码路径：逐步提取特征 
        skip1 = self.first_layer(x)  # 64通道
        skip2 = self.down1(skip1)    # 128通道
        skip3 = self.down2(skip2)    # 256通道
        
        # 根据网络深度选择下采样路径
        if self.deep:
            skip4 = self.down3(skip3)  # 512通道
            x = self.down4(skip4)      # 512通道
        else:
            x = self.down3(skip3)      # 512通道

        # 瓶颈层：注入身份特征
        for i in range(len(self.BottleNeck)):
            x = self.BottleNeck[i](x, dlatents)

        # 解码路径：逐步恢复图像分辨率 
        if self.deep:
            x = self.up4(x)  # 512通道
        x = self.up3(x)      # 256通道
        x = self.up2(x)      # 128通道
        x = self.up1(x)      # 64通道
        
        # 生成最终图像
        x = self.last_layer(x)
        x = (x + 1) / 2      # 将Tanh输出范围[-1,1]转换到[0,1] 

        return x







class Discriminator(nn.Module):
    """
    判别器网络
    用于区分真实图像和生成图像
    使用多尺度特征提取和可选的sigmoid激活
    """
    def __init__(self, input_nc, norm_layer=nn.BatchNorm2d, use_sigmoid=False):
        """
        初始化判别器
        Args:
            input_nc: 输入通道数（RGB图像为3）
            norm_layer: 归一化层类型，默认为BatchNorm2d
            use_sigmoid: 是否在输出层使用sigmoid激活
        """
        super(Discriminator, self).__init__()

        # 设置卷积核大小和填充
        kw = 4
        padw = 1

        # 下采样路径1：64通道
        self.down1 = nn.Sequential(
            nn.Conv2d(input_nc, 64, kernel_size=kw, stride=2, padding=padw), 
            nn.LeakyReLU(0.2, True)
        )
        # 下采样路径2：128通道
        self.down2 = nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=kw, stride=2, padding=padw),
            norm_layer(128), 
            nn.LeakyReLU(0.2, True)
        )
        # 下采样路径3：256通道
        self.down3 = nn.Sequential(
            nn.Conv2d(128, 256, kernel_size=kw, stride=2, padding=padw),
            norm_layer(256), 
            nn.LeakyReLU(0.2, True)
        )
        # 下采样路径4：512通道
        self.down4 = nn.Sequential(
            nn.Conv2d(256, 512, kernel_size=kw, stride=2, padding=padw),
            norm_layer(512), 
            nn.LeakyReLU(0.2, True)
        )
        # 最终卷积层：保持512通道
        self.conv1 = nn.Sequential(
            nn.Conv2d(512, 512, kernel_size=kw, stride=1, padding=padw),
            norm_layer(512),
            nn.LeakyReLU(0.2, True)
        )

        # 输出层：根据use_sigmoid决定是否使用sigmoid激活
        if use_sigmoid:
            self.conv2 = nn.Sequential(
                nn.Conv2d(512, 1, kernel_size=kw, stride=1, padding=padw), 
                nn.Sigmoid()
            )
        else:
            self.conv2 = nn.Sequential(
                nn.Conv2d(512, 1, kernel_size=kw, stride=1, padding=padw)
            )

    def forward(self, input):
        """
        前向传播函数
        Args:
            input: 输入图像
        Returns:
            list: 包含所有中间层特征的列表，用于特征匹配损失计算
        """
        out = []
        # 提取并保存每一层的特征
        x = self.down1(input)
        out.append(x)
        x = self.down2(x)
        out.append(x)
        x = self.down3(x)
        out.append(x)
        x = self.down4(x)
        out.append(x)
        x = self.conv1(x)
        out.append(x)
        x = self.conv2(x)
        out.append(x)
        
        return out