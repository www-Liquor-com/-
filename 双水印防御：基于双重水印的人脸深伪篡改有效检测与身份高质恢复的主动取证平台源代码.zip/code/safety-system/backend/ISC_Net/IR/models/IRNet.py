import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import os
from torch.autograd import Variable
from .base_model import BaseModel
# from . import networks
from .IR_networks import IR_Model, Discriminator 
from .Random_Noise import Random_Noise
import lpips  # 添加LPIPS导入

class PSNR(nn.Module):
    def __init__(self):
        super(PSNR, self).__init__()
        self.mse = nn.MSELoss()
        
    def forward(self, img1, img2):
        mse = self.mse(img1, img2)
        if mse == 0:
            return float('inf')
        max_pixel = 1.0
        psnr = 20 * torch.log10(max_pixel / torch.sqrt(mse))
        return psnr

class SSIM(nn.Module):
    def __init__(self, window_size=11, size_average=True):
        super(SSIM, self).__init__()
        self.window_size = window_size
        self.size_average = size_average
        self.channel = 3
        self.window = self._create_window(window_size, self.channel)

    def _gaussian(self, window_size, sigma):
        gauss = torch.Tensor([np.exp(-(x - window_size//2)**2/float(sigma**2)) for x in range(window_size)])
        return gauss/gauss.sum()

    def _create_window(self, window_size, channel):
        _1D_window = self._gaussian(window_size, 1.5).unsqueeze(1)
        _2D_window = _1D_window.mm(_1D_window.t()).float().unsqueeze(0).unsqueeze(0)
        window = _2D_window.expand(channel, 1, window_size, window_size).contiguous()
        return window

    def forward(self, img1, img2):
        (_, channel, _, _) = img1.size()
        window = self.window.to(img1.device)

        mu1 = F.conv2d(img1, window, padding=self.window_size//2, groups=channel)
        mu2 = F.conv2d(img2, window, padding=self.window_size//2, groups=channel)

        mu1_sq = mu1.pow(2)
        mu2_sq = mu2.pow(2)
        mu1_mu2 = mu1*mu2

        sigma1_sq = F.conv2d(img1*img1, window, padding=self.window_size//2, groups=channel) - mu1_sq
        sigma2_sq = F.conv2d(img2*img2, window, padding=self.window_size//2, groups=channel) - mu2_sq
        sigma12 = F.conv2d(img1*img2, window, padding=self.window_size//2, groups=channel) - mu1_mu2

        C1 = 0.01**2
        C2 = 0.03**2

        ssim_map = ((2*mu1_mu2 + C1)*(2*sigma12 + C2))/((mu1_sq + mu2_sq + C1)*(sigma1_sq + sigma2_sq + C2))

        if self.size_average:
            return ssim_map.mean()
        else:
            return ssim_map.mean(1).mean(1).mean(1)


class SpecificNorm(nn.Module):
    """
    特定归一化层，用于图像预处理 ，输入图像要求[0,1]
    将图像按照ImageNet的均值和标准差进行标准化
    """
    def __init__(self, epsilon=1e-8):
        """
        初始化特定归一化层
        @notice: 避免原地操作，防止梯度计算错误
        """
        super(SpecificNorm, self).__init__()
        # ImageNet数据集的RGB通道均值
        self.mean = np.array([0.485, 0.456, 0.406])
        self.mean = torch.from_numpy(self.mean).float().cuda()
        self.mean = self.mean.view([1, 3, 1, 1])

        # ImageNet数据集的RGB通道标准差
        self.std = np.array([0.229, 0.224, 0.225])
        self.std = torch.from_numpy(self.std).float().cuda()
        self.std = self.std.view([1, 3, 1, 1])

    def forward(self, x):
        """
        前向传播函数
        对输入图像进行标准化处理
        """
        mean = self.mean.expand([1, 3, x.shape[2], x.shape[3]])
        std = self.std.expand([1, 3, x.shape[2], x.shape[3]])

        x = (x - mean) / std
        return x


class IRNet(BaseModel):
    """
    身份恢复模型的主类
    包含 Random_Noise、 netG、 
        netArc （仅训练模式）
    """

    def init_loss_filter(self):
        """
        初始化损失过滤器
        用于控制不同损失函数的启用状态
        """
        # flags元组中的8个参数分别控制不同损失函数的启用状态：
        # 1. True: 生成器对抗损失 (G_GAN) - 控制生成器与判别器之间的对抗训练
        # 2. use_gan_feat_loss: GAN特征匹配损失 (G_GAN_Feat) - 保持生成图像和真实图像在特征空间的一致性
        # 3. use_lpips_loss: LPIPS感知损失 (G_LPIPS) - 保持原始图像和恢复图像在感知特征上的一致性 
        # 4. True: 身份保持损失 (G_ID) - 确保恢复图像保持原始图像的身份特征 
        # 5. True: 重建损失 (G_Rec) - 确保恢复图像与原始图像在像素级别的相似性 
        # 6. True: 判别器梯度惩罚 (D_GP) - 用于稳定GAN训练
        # 7. True: 判别器真实图像损失 (D_real) - 判别器对真实图像的判别损失
        # 8. True: 判别器生成图像损失 (D_fake) - 判别器对生成图像的判别损失
        flags = (False, False, True, True, True, False, False, False)   

        def loss_filter(g_gan, g_gan_feat, g_lpips, g_id, g_rec, g_mask, d_real, d_fake):
            """
            损失过滤器函数
            根据flags的配置决定是否使用对应的损失函数
            Args:
                g_gan: 生成器对抗损失
                g_gan_feat: GAN特征匹配损失
                g_lpips: LPIPS感知损失
                g_id: 身份保持损失
                g_rec: 重建损失
                g_mask: 掩码损失（当前未使用）
                d_real: 判别器真实图像损失
                d_fake: 判别器生成图像损失
            Returns:
                根据flags过滤后的损失函数列表 
            """
            return [l for (l, f) in zip((g_gan, g_gan_feat, g_lpips, g_id, g_rec, g_mask, d_real, d_fake), flags) if f]

        return loss_filter

    def initialize(self, opt):
        """
        初始化模型
        设置网络结构、损失函数和优化器
        Args:
            opt: 配置参数对象，包含以下关键参数：
                # - resize_or_crop: 图像调整方式
                - isTrain: 是否为训练模式
                - Arc_path: 身份识别网络路径
                # - gan_mode: GAN模式
                - lr: 学习率
                - beta1: Adam优化器的beta1参数
                - noise_layers: 噪声层
        """
        # 调用基类的初始化方法
        BaseModel.initialize(self, opt) 
        
        # # 设置CUDA优化 
        # if opt.resize_or_crop != 'none' or not opt.isTrain: 
        #     torch.backends.cudnn.benchmark = True 
        self.isTrain = opt.isTrain 

        # 设置设备 
        device = torch.device("cuda:0") 


        # 初始化生成器网络
        # input_nc: 输入通道数（RGB图像为3）
        # output_nc: 输出通道数（RGB图像为3）
        # latent_size: 潜在空间维度（512）
        # n_blocks: 残差块数量（9）
        # deep: 是否使用深层网络（False）
        self.netG = IR_Model(input_nc=3, output_nc=3, latent_size=512, n_blocks=9, deep=False)
        self.netG.to(device)
        print("IRNet的生成器：netG创建成功") 

        # 创建并冻结随机前向噪声池 
        noise_layers_str = str(opt.noise_layers)  # 保存原始的字符串表示 
        self.noise_pool = Random_Noise(opt.noise_layers) 
        # 冻结噪声池中的所有参数，防止在训练过程中更新 
        for param in self.noise_pool.parameters():
            param.requires_grad = False
        print("IRNet的噪声池：", noise_layers_str, "创建成功")
        print("噪声池参数已冻结，不会在训练中更新")

        # # 如果不是训练模式，只加载生成器并返回
        # if not self.isTrain: 
        #     pretrained_path = '' if not self.isTrain else opt.load_pretrain 
        #     self.load_network(self.netG, pretrained_path) 
        #     return 

        # # 初始化判别器网络 
        # # 根据GAN模式决定是否使用sigmoid激活 
        # if opt.gan_mode == 'original':
        #     use_sigmoid = True 
        # else: 
        #     use_sigmoid = False 
            
        # # 创建两个判别器，一个用于原始分辨率，一个用于下采样后的图像
        # self.netD1 = Discriminator(input_nc=3, use_sigmoid=use_sigmoid)
        # self.netD2 = Discriminator(input_nc=3, use_sigmoid=use_sigmoid)
        # self.netD1.to(device) 
        # self.netD2.to(device) 


        # 初始化特定归一化层和下采样层 
        self.spNorm = SpecificNorm()  # 图像预处理的归一化层,用于arcface 
        # self.downsample = nn.AvgPool2d(3, stride=2, padding=[1, 1], count_include_pad=False)  # 用于图像下采样的平均池化层 

        # 加载预训练模型（如果需要继续训练，或者不训练仅测试）
        if opt.continue_train or not self.isTrain: 
            pretrained_path = opt.pretrained_path 
            self.load_network(self.netG, pretrained_path) 
            # self.load_network(self.netD1, 'D1', opt.which_epoch, pretrained_path) 
            # self.load_network(self.netD2, 'D2', opt.which_epoch, pretrained_path) 

        # 初始化身份识别网络，用于计算身份损失 
        # 加载预训练的身份识别模型 
        netArc_checkpoint = opt.Arc_path
        netArc_checkpoint = torch.load(netArc_checkpoint, map_location=torch.device("cpu"),weights_only=False)
        self.netArc = netArc_checkpoint
        self.netArc = self.netArc.to(device) 
        self.netArc.eval()  # 设置为评估模式 
        
        
        # 定义损失函数
        # 初始化损失过滤器，控制不同损失函数的启用状态
        self.loss_filter = self.init_loss_filter() 

        # 定义各种损失函数
        self.criterionLPIPS = lpips.LPIPS(net='alex').to(device) # 初始化LPIPS损失 
        self.criterionRec = nn.L1Loss()   # 重建损失 
        # self.criterionGAN = networks.GANLoss(opt.gan_mode, tensor=self.Tensor, opt=self.opt)  # GAN损失 
        # self.criterionFeat = nn.L1Loss()  # 特征匹配损失  

        # 定义损失名称，用于记录和显示
        self.loss_names = self.loss_filter('G_GAN', 'G_GAN_Feat', 'G_LPIPS', 'G_ID', 'G_Rec', 'D_GP',
                                            'D_real', 'D_fake') 

        # 初始化优化器 
        # 生成器优化器 
        params = list(self.netG.parameters())
        
        # 仅在训练模式下确定优化器 
        if self.isTrain:
            self.optimizer_G = torch.optim.Adam(params, lr=opt.lr, betas=(opt.beta1, 0.999))

        # 评估指标：PSNR、SSIM
        self.psnr = PSNR()
        self.ssim = SSIM()

        # # 判别器优化器（包含两个判别器的参数）
        # params = list(self.netD1.parameters()) + list(self.netD2.parameters())
        # self.optimizer_D = torch.optim.Adam(params, lr=opt.lr, betas=(opt.beta1, 0.999))


    # def _gradinet_penalty_D(self, netD, img_att, img_recover):
    #     """
    #     计算判别器的梯度惩罚
    #     用于稳定GAN训练
    #     """ 
    #     # 插值采样
    #     bs = img_recover.shape[0]
    #     alpha = torch.rand(bs, 1, 1, 1).expand_as(img_recover).cuda()
    #     interpolated = Variable(alpha * img_att + (1 - alpha) * img_recover, requires_grad=True)
    #     pred_interpolated = netD.forward(interpolated)
    #     pred_interpolated = pred_interpolated[-1]

    #     # 计算梯度
    #     grad = torch.autograd.grad(outputs=pred_interpolated,
    #                                inputs=interpolated,
    #                                grad_outputs=torch.ones(pred_interpolated.size()).cuda(),
    #                                retain_graph=True,
    #                                create_graph=True,
    #                                only_inputs=True)[0] 

    #     # 惩罚梯度
    #     grad = grad.view(grad.size(0), -1)
    #     grad_l2norm = torch.sqrt(torch.sum(grad ** 2, dim=1))
    #     loss_d_gp = torch.mean((grad_l2norm - 1) ** 2)

    #     return loss_d_gp

    def cosin_metric(self, x1, x2):
        """
        计算余弦相似度
        用于身份特征的相似度度量
        """
        return torch.sum(x1 * x2, dim=1) / (torch.norm(x1, dim=1) * torch.norm(x2, dim=1))

    def forward(self, img_att, latent_id, for_G=False):
        """ 
        前向传播函数 
        生成结果图像 
        """
        # 生成身份恢复图像 
        img_noise = self.noise_pool(img_att) 
        img_recover = self.netG(img_noise, latent_id)  # 输入图像要求[0,1] 
        
        
        # 返回恢复图像 
        return img_noise, img_recover 
    
    def loss_metrics(self, img_att, latent_id, img_recover):
        # print("img_att shape:", img_att.shape)
        # print("latent_id shape:", latent_id.shape)
        # print("img_recover shape:", img_recover.shape)
        loss_D_fake, loss_D_real, loss_D_GP = 0, 0, 0 
        loss_G_GAN, loss_G_GAN_Feat, loss_G_LPIPS, loss_G_ID, loss_G_Rec = 0,0,0,0,0 
        # img_recover_downsample = self.downsample(img_recover)
        # img_att_downsample = self.downsample(img_att)

        # 判别器对假图像的损失
        # fea1_fake = self.netD1.forward(img_recover.detach())
        # fea2_fake = self.netD2.forward(img_recover_downsample.detach())
        # pred_fake = [fea1_fake, fea2_fake]
        # loss_D_fake = self.criterionGAN(pred_fake, False, for_discriminator=True)

        # # 判别器对真图像的损失
        # fea1_real = self.netD1.forward(img_att)
        # fea2_real = self.netD2.forward(img_att_downsample)
        # pred_real = [fea1_real, fea2_real]
        # fea_real = [fea1_real, fea2_real]
        # loss_D_real = self.criterionGAN(pred_real, True, for_discriminator=True)

        # # 生成器对抗损失
        # fea1_fake = self.netD1.forward(img_recover)
        # fea2_fake = self.netD2.forward(img_recover_downsample)
        # pred_fake = [fea1_fake, fea2_fake]
        # fea_fake = [fea1_fake, fea2_fake]
        # loss_G_GAN = self.criterionGAN(pred_fake, True, for_discriminator=False)

        # # GAN特征匹配损失
        # n_layers_D = 4
        # num_D = 2
        # if not self.opt.no_ganFeat_loss:
        #     feat_weights = 4.0 / (n_layers_D + 1)
        #     D_weights = 1.0 / num_D
        #     for i in range(num_D):
        #         for j in range(0, len(fea_fake[i]) - 1):
        #             loss_G_GAN_Feat += D_weights * feat_weights * \
        #                                self.criterionFeat(fea_fake[i][j],
        #                                                   fea_real[i][j].detach()) 

        # 重建损失 
        loss_G_Rec = self.criterionRec(img_recover, img_att)  
        # 计算LPIPS损失 
        loss_G_LPIPS = self.criterionLPIPS(img_recover, img_att).mean()  
        # 身份保持损失 
        img_recover_down = F.interpolate(img_recover, size=(112,112)) 
        img_recover_down = self.spNorm(img_recover_down) 
        latent_recover = self.netArc(img_recover_down)
        cos_metric = (self.cosin_metric(latent_recover, latent_id)).mean() # 评估指标 余弦相似度
        loss_G_ID = 1 - cos_metric 

        # 计算PSNR、SSIM、余弦相似度 
        psnr = self.psnr(img_recover, img_att) 
        ssim = self.ssim(img_recover, img_att) 
        metrics = [psnr, ssim, cos_metric] 
        # print('---------------shape--------------------')
        # print(loss_G_Rec.shape) 
        # print(loss_G_LPIPS.shape) 
        # print(loss_G_ID.shape)
        # print(psnr.shape) 
        # print(ssim.shape) 
        # print(cos_metric.shape) 
        # print('--------------------------------')
        

        return [self.loss_filter(loss_G_GAN, loss_G_GAN_Feat, loss_G_LPIPS, loss_G_ID, loss_G_Rec, loss_D_GP, loss_D_real, loss_D_fake), metrics]

    def save(self, which_epoch, which_step):
        """
        保存模型参数
        """
        self.save_network(self.netG, 'G', which_epoch, which_step, self.gpu_ids)
        # self.save_network(self.netD1, 'D1', which_epoch, self.gpu_ids) 
        # self.save_network(self.netD2, 'D2', which_epoch, self.gpu_ids) 

    def update_fixed_params(self):
        """
        更新固定参数
        在固定全局生成器一定迭代次数后开始微调
        """
        params = list(self.netG.parameters())
        if self.gen_features:
            params += list(self.netE.parameters())
        self.optimizer_G = torch.optim.Adam(params, lr=self.opt.lr, betas=(self.opt.beta1, 0.999))
        if self.opt.verbose:
            print('------------ 现在开始微调全局生成器 -----------')


    def update_learning_rate(self):
        """
        更新学习率
        实现学习率的衰减
        """
        lrd = self.opt.lr / self.opt.niter_decay
        lr = self.old_lr - lrd
        for param_group in self.optimizer_D.param_groups:
            param_group['lr'] = lr
        for param_group in self.optimizer_G.param_groups:
            param_group['lr'] = lr
        if self.opt.verbose:
            print('更新学习率: %f -> %f' % (self.old_lr, lr))
        self.old_lr = lr 


