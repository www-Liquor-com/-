from . import *
from .noise_layers import *
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np 
from torchvision import transforms

# import random 

# 前向噪声池（梯度分离）
# !!! 保证输入范围是[0,1]，输出是[0,1] !!!
class Random_Noise(nn.Module):
    """随机噪声模块
    
    用于对水印图像添加随机噪声，实现梯度分离，防止梯度流向编码器。
    """ 

    def __init__(self, noise_layers):
        """
        初始化随机噪声模块
        参数:
            noise_layers: 噪声层名称列表，包含所有可能的噪声层 
        """ 
        super(Random_Noise, self).__init__()
        print('噪声层：')
        print(noise_layers)
        # 将噪声层名称转换为实际的噪声层对象
        for i in range(len(noise_layers)):
            noise_layers[i] = eval(noise_layers[i])
        # 构建噪声层序列
        self.noise_layers = nn.Sequential(*noise_layers) 
        

    def forward(self, input_img):
        """
        前向传播函数
        
        参数:
            input_data: 包含水印图像、原始图像、掩码图像的元组 (watermarked_image, original_image, mask)
        返回:
            添加噪声后的水印图像
        """ 
        # 分离梯度，防止反向传播 
        input_img_detached = input_img.clone().detach()
        
        # 初始化噪声图像张量 
        noisy_image = torch.zeros_like(input_img_detached)

        # 对批次中的每张图像添加随机噪声  
        batch_size = input_img_detached.shape[0]
        for batch_idx in range(batch_size):
            # 随机选择一个噪声层 
            selected_noise_layer = np.random.choice(self.noise_layers, 1)[0] 
            
            # 准备单张图像的输入数据  
            single_image_input = [ 
                input_img_detached[batch_idx].clone().unsqueeze(0)
            ] 
            
            # 应用选中的噪声层 
            noisy_image[batch_idx] = selected_noise_layer(single_image_input) 

        # 计算噪声差异并限制范围  
        noise_gap = noisy_image.clamp(-1, 1) - input_img_detached 

        # 返回添加噪声后的水印图像 
        return input_img + noise_gap  
    
    
    