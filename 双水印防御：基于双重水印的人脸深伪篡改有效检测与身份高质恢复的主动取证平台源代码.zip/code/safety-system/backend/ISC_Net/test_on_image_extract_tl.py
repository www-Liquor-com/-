import torch 
from .TL.options import options  as option # 配置选项

from .TL.network.model import Tamper_Loc
import math
from .TL.network.subnet import subnet 
import numpy as np
import random
from .TL.utils.load_image import load_image 
import cv2
from PIL import Image
from .TL.network.common import DWT  # 导入DWT
from .TL.utils.preprocess import preprocess_bit,preprocess_img
from .TL.utils.save_tensor import save_tensor
from .TL.utils.create_model import define_G
import time,hashlib

def get_tamper_mask(original_tensor, watermark_tensor, threshold=0.2):  
    """
    生成篡改掩码张量
    Args:
        original_tensor: torch.Tensor, 原始水印图像张量 [B, C, H, W]
        watermark_tensor: torch.Tensor, 提取的水印图像张量 [B, C, H, W]
        threshold: float, 阈值，默认为0.2
    Returns:
        mask_tensor: torch.Tensor, 掩码张量 [B, 1, H, W]，0表示差距小，1表示差距大
        residual_tensor: torch.Tensor, 三通道残差张量 [B, C, H, W]
    """
    # 计算残差图像张量：原始图片张量减去水印图像张量的绝对值
    residual = torch.abs(original_tensor - watermark_tensor)  # [B, C, H, W]
    
    # 分别计算各个通道上的残差掩码（是否大于阈值）
    channel_masks = (residual > threshold).float()  # [B, C, H, W]
    
    # 将各通道掩码加起来，如果大于0则说明至少有一个通道超过阈值
    mask = (torch.sum(channel_masks, dim=1, keepdim=True) > 0).float()  # [B, 1, H, W]
    
    return mask, residual



def calculate_error_rate(bit_input, msg_binary_list):
    # 计算误码率
    error_rates = []
    for i in range(len(bit_input)):
        original_bits = bit_input[i]
        extracted_bits = msg_binary_list[i]
        
        # 计算不同位的数量
        error_count = 0
        for j in range(len(original_bits)):
            if original_bits[j] != extracted_bits[j]:
                error_count += 1

        # 计算误码率 
        error_rate = error_count / len(original_bits) 
        error_rates.append(error_rate) 
    
    
    print("误码率列表:", error_rates) 
    print("平均误码率:", sum(error_rates) / len(error_rates)) 




def extract_wm(image_input, template=None, save_folder=None): 
    # 清理GPU内存
    if torch.cuda.is_available(): 
        torch.cuda.empty_cache() 
        
    # 加载配置选项 
    opt = option.parse("ISC_Net/TL/options/test_tl.yml", is_train=True) 
    # 分布式训练设置 
    opt['dist'] = False 
    rank = -1 
    print('Disabled distributed training.') 

    # 如果存在恢复状态，则加载 
    if opt['path'].get('resume_state', None): 
        device_id = torch.cuda.current_device() 
        resume_state = torch.load(opt['path']['resume_state'], 
                                    map_location=lambda storage, loc: storage.cuda(device_id)) 
        option.check_resume(opt, resume_state['iter']) 
    else:  
        resume_state = None  

    # 转换为NoneDict，对缺失的键返回None   
    opt = option.dict_to_nonedict(opt)   
    

    torch.backends.cudnn.benchmark = True  
    print(f"开始加载模型")  
    model = define_G(opt) 
    print(f"模型已创建: {model is not None}") 

    # 1. 选择 device
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = model.to(device)  # 2. 模型放到 device

    # 设置推理模式
    model.eval()

    # 加载模型权重
    checkpoint_path = opt['path'].get('pretrain_model_G', 'checkpoints/degrade.pth') 
    if torch.cuda.is_available():
        print("cuda可用")
        checkpoint = torch.load(checkpoint_path, map_location='cuda')
    else:
        print("cuda不可用")
        checkpoint = torch.load(checkpoint_path, map_location='cpu')
    if 'params' in checkpoint:
        print("加载params")
        model.load_state_dict(checkpoint['params'], strict=opt['path'].get('strict_load', True))
    else:
        model.load_state_dict(checkpoint, strict=opt['path'].get('strict_load', True))
    print(f"模型权重已从 {checkpoint_path} 加载")
    
    
    y_tensor, template_tensor = preprocess_img(image_input, template,size=256) 
    y_tensor = y_tensor.to(device) 
    template_tensor = template_tensor.to(device) 
    

    # 使用当前时间戳和图像内容生成唯一ID
    timestamp = str(int(time.time() * 1000))  # 毫秒级时间戳
    image_hash = hashlib.md5(y_tensor.cpu().numpy().tobytes()).hexdigest()[:8]  # 图像内容的MD5哈希前8位
    unique_id = f"{timestamp}_{image_hash}" 
    
    # 提取水印
    with torch.no_grad():
        img_raw, img_wm, predict_y_h = model(x=y_tensor, rev=True) 
        # save_tensor(img_raw,name=f"4_提取的原始图片_{unique_id}")   
        # save_tensor(img_wm,name=f"5_提取的水印图片_{unique_id}")  
        # save_tensor(predict_y_h,name=f"6_预测的网络第二输入_{unique_id}")  


    mask,res = get_tamper_mask(template_tensor, img_wm)  
    
    if not save_folder:
        save_folder = "temp_results"
    save_path = f"{save_folder}/{unique_id}_mask_image.png" 
    
    save_tensor(mask,save_path=save_path)  
    # save_tensor(res,name=f"8_篡改残差图像_{unique_id}")  
    
    return save_path




if __name__ == "__main__":
    # 使用PIL加载图像以避免中文路径问题
    # pil_img = Image.open(r"temp_results\1_图像水印图片_1750503873108_205f1045_0.png")
    # pil_img = Image.open(r"temp_results\3_图像-比特水印图片_1750503873108_205f1045_0.png")
    # pil_img = Image.open(r"E:\train_program\Tamper_Localization\temp_results\1_图像水印图片_1750571065050_7af67873_0.png")
    # pil_img = Image.open(r"E:\train_program\Tamper_Localization\temp_results\3_图像-比特水印图片_1750571065050_7af67873_0.png")
    pil_img = Image.open(r"E:\train_program\IdFMark_IR_project\temp_results\image_5\2_编码图像.png")  
    # 转换为OpenCV格式 (PIL是RGB，OpenCV是BGR)  
    img_array = np.array(pil_img) 
    img_array = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR) 
    image_input = [img_array] 
    # image_input_h = [cv2.imread(r"E:\DataSets\IdFMark\images\test_256\00133.png")] 
    image_input_h = None  

    extract_wm(image_input, image_input_h)  



