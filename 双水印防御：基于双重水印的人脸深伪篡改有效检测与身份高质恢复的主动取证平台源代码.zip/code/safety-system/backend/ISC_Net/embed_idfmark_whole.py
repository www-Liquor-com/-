import os
import torch
import numpy as np
from PIL import Image
from torchvision import transforms
from torch.utils.data import Dataset, DataLoader
import lpips
from skimage.metrics import peak_signal_noise_ratio, structural_similarity
from .IdFMark.network.IdFMark import Network
from .IR.models.IRNet  import IRNet 
import torch.nn.functional as F
from .utils.img_fea_loader import ImgFeaDataset
import pickle 
import sys
from .insightface_func.face_detect_crop_single import Face_detect_crop
from .Noise import *
import cv2
import argparse
import concurrent.futures
import time,hashlib
def set_seed(seed=42):
    """
    固定全局随机种子，确保实验可重复性
    """
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    os.environ['PYTHONHASHSEED'] = str(seed)

# 设置随机种子，保证实验结果可复现
set_seed(42) 


# # 添加项目根目录到 Python 路径
# project_root = os.path.dirname(os.path.abspath(__file__))
# sys.path.append(project_root)

os.environ["TORCH_HOME"] = "E:/torch_cache"  # 设置PyTorch模型缓存路径

def save_image(tensor, path):
    """保存图像"""
    # 输入图像[-1,1]
    image = tensor.squeeze(0).permute(1, 2, 0).cpu().numpy()
    image = ((image + 1) / 2 * 255).astype(np.uint8)
    Image.fromarray(image).save(path)


def save_residual_image(original, encoded, path):
    """保存增强后的残差图像"""
    # 计算残差
    residual = encoded - original
    
    # 转换为numpy数组并保存
    residual_np = residual.squeeze(0).permute(1, 2, 0).cpu().numpy()
    residual_np = ((residual_np + 1) / 2 * 255).astype(np.uint8)
    residual_np = (residual_np) * 5 # 放大5倍  
    Image.fromarray(residual_np).save(path) 


import lpips  # pip install lpips


lpips_model = lpips.LPIPS().eval()
if torch.cuda.is_available():
    lpips_model = lpips_model.cuda()

def evaluate_quality(original, encoded):
    """评估图像质量，返回 PSNR, SSIM, LPIPS"""
    batch_size = original.size(0)
    psnrs = []
    ssims = []
    lpips_scores = []

    for i in range(batch_size):
        # 单个图像 (C, H, W) -> (H, W, C)
        orig_img = original[i].detach().cpu()
        enc_img = encoded[i].detach().cpu()

        orig_np = orig_img.permute(1, 2, 0).numpy()
        enc_np = enc_img.permute(1, 2, 0).numpy()

        # 裁剪数值，确保在 [-1, 1]
        orig_np = np.clip(orig_np, -1, 1)
        enc_np = np.clip(enc_np, -1, 1)

        # PSNR
        psnr = peak_signal_noise_ratio(orig_np, enc_np, data_range=2.0)
        psnrs.append(psnr)

        # SSIM
        if orig_np.ndim == 3 and orig_np.shape[2] == 1:
            ssim = structural_similarity(orig_np.squeeze(), enc_np.squeeze(), data_range=2.0)
        else:
            ssim = structural_similarity(orig_np, enc_np, channel_axis=2, data_range=2.0)
        ssims.append(ssim)

        # LPIPS 需要输入 shape: (1, 3, H, W)，float32，范围 [-1, 1]
        orig_lpips = orig_img.unsqueeze(0)
        enc_lpips = enc_img.unsqueeze(0)
        if torch.cuda.is_available():
            orig_lpips = orig_lpips.cuda()
            enc_lpips = enc_lpips.cuda()
        lpips_score = lpips_model(orig_lpips, enc_lpips).item()
        lpips_scores.append(lpips_score)

    return np.mean(psnrs), np.mean(ssims), np.mean(lpips_scores)


def cosine_similarity(message1, message2):
    """计算两个消息之间的余弦相似度"""
    # 确保两个消息都是二维张量 [batch_size, message_length]
    if len(message1.shape) == 1:
        message1 = message1.unsqueeze(0)
    if len(message2.shape) == 1:
        message2 = message2.unsqueeze(0)
    
    # 使用与训练时相同的余弦相似度计算方式
    similarity = torch.nn.functional.cosine_similarity(message1, message2, dim=1)
    return similarity


def str2bool(v):
    if isinstance(v, bool):
        return v
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')



def embed_idfmark(img_list, save_folder=None): 
    # 设置设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    result_dir = "temp_results/" 
    # 模型参数
    message_length = 512
    batch_size = 2  # 减小批量大小从8到4
    lr = 0.0001
    beta1 = 0.5
    attention_encoder = 'se' 
    attention_decoder = 'se' 
    weight = [1, 10, 10, 10, 0.1] 
    
    # 加载预训练模型 :水印模块 
    print('正在初始化水印模块...')
    idfmark_model = Network(
        message_length=message_length,
        noise_layers=[],
        device=device,
        batch_size=batch_size,
        lr=lr,
        beta1=beta1,
        attention_encoder=attention_encoder,
        attention_decoder=attention_decoder,
        weight=weight 
    ) 
    idfmark_model_path = "ISC_Net/IdFMark/checkpoint/EC_1.pth" 
    try: 
        idfmark_model.load_model_ed(idfmark_model_path)   
        idfmark_model.encoder_decoder.eval() 
    except RuntimeError as e: 
        print("错误：加载模型权重失败。请检查模型架构是否与预训练权重匹配。")  
        print("错误详情:", str(e))  
        return  
    print('水印模块初始化完成...') 




    # 加载人脸分割模型 
    print("正在初始化人脸检测器...") 
    facecrop_model = Face_detect_crop(name='antelope', root='ISC_Net/insightface_func/models')  
    facecrop_model.prepare(ctx_id=0, det_thresh=0.1, det_size=(256,256))  
    print("人脸检测器初始化完成")  
    
    # 加载人脸特征提取器 
    arcface_path = 'ISC_Net/arcface_model/arcface_checkpoint.tar' 
    netArc = torch.load(arcface_path, map_location=device, weights_only=False)
    print("人脸特征提取器初始化完成")  

    with torch.no_grad():
        
        for id, img in enumerate(img_list): 
            face_crop_list, mat_list = facecrop_model.get(img, crop_size=112)  
            
            # 预处理img
            img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            pil_img = Image.fromarray(img_rgb)  
            # 定义图像变换：调整大小, 转换为张量 
            transform = transforms.Compose([ 
                transforms.Resize((256, 256)), 
                transforms.ToTensor(), 
                transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])  # 归一化到[-1, 1]  
            ])  
            # 应用变换
            img_tensor = transform(pil_img)
            img_tensor = img_tensor.unsqueeze(0)  # [1, 3, 512, 512]

            # 获取特征 
            face_crop_i = Image.fromarray(cv2.cvtColor(face_crop_list[0], cv2.COLOR_BGR2RGB))  
            transformer_Arcface = transforms.Compose([  
                transforms.ToTensor(),
                transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
            ])  
            face_crop_i = transformer_Arcface(face_crop_i) 
            face_crop_i = face_crop_i.view(-1, face_crop_i.shape[0], face_crop_i.shape[1], face_crop_i.shape[2])
            face_crop_i = face_crop_i.cuda() 
            # 使用arcface模型提取人脸特征 
            # img_id_downsample = F.interpolate(face_crop_i, size=(112,112)) 
            img_id_downsample = face_crop_i 
            latend_id = netArc(img_id_downsample) 
            feature = F.normalize(latend_id, p=2, dim=1) 
            feature = feature.unsqueeze(0)  # [1, 3, 512, 512]
           
            img_tensor = img_tensor.to(device)
            feature = feature.to(device)
            
            # 测试从原始图像提取水印 
            original_decoded = idfmark_model.encoder_decoder.module.decoder(img_tensor)  
            original_decoded = idfmark_model.encoder_decoder.module.output_norm(original_decoded)  
            original_similarities = cosine_similarity(feature, original_decoded)  
            print(f" 未编码图像 - 余弦相似度: {original_similarities.mean().item():.4f}")  
            
            # 1. 先编码 
            encoded_images = idfmark_model.encoder_decoder.module.encoder(img_tensor, feature)  
            
            # 使用当前时间戳和图像内容生成唯一ID
            timestamp = str(int(time.time() * 1000))  # 毫秒级时间戳
            image_hash = hashlib.md5(encoded_images.cpu().numpy().tobytes()).hexdigest()[:8]  # 图像内容的MD5哈希前8位
            unique_id = f"{timestamp}_{image_hash}" 
            if not save_folder:
                save_folder="temp_results"
            save_path = f"{save_folder}/{unique_id}_fea_wm_image.png" 
            
            # 2. 保存原始图像，编码图像和残差图像 
            # # 保存原始图像 
            # save_image(img_tensor, os.path.join(img_result_dir, "1_原始图像.png")) 
            # 保存编码图像
            save_image(encoded_images,save_path) 
            # # 保存增强后的残差图像
            # save_residual_image(img_tensor, encoded_images, os.path.join(img_result_dir, "3_残差图像.png")) 
            
            # 2. 解码提取水印 
            decoded_feature = idfmark_model.encoder_decoder.module.decoder(encoded_images)
            decoded_feature = idfmark_model.encoder_decoder.module.output_norm(decoded_feature)
            
            # 计算解码后的特征与原始特征的相似度
            decoded_similarities = cosine_similarity(feature, decoded_feature)
            print(f"编码后解码 - 余弦相似度: {decoded_similarities.mean().item():.4f}")
            
            return save_path 
            




if __name__ == "__main__":
    # 读取指定路径的图像文件 
    # img_path = r"E:\train_program\IdFMark_IR_project\temp_results\test3.png" 
    img_path = r"E:\train_program\IdFMark_IR_project\temp_results\test5.png" 
    img = cv2.imread(img_path) 
    
    if img is None: 
        print(f"错误：无法读取图像文件 {img_path}") 
    else: 
        img_list = [img] 
        embed_idfmark(img_list)  
 
