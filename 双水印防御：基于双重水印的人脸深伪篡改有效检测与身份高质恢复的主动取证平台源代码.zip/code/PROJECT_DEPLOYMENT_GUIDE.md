# Safety System 项目部署指南

## 🎯 项目拆分完成

### 1. 云端项目 (safety-system-web)
**部署位置**: 腾讯云服务器  
**功能**: 用户界面 + 业务逻辑  
**包含内容**:
- ✅ 完整的Vue.js前端应用
- ✅ FastAPI后端服务（无AI模型）
- ✅ 用户管理和认证系统
- ✅ 文件上传下载服务
- ✅ 数据库和数据存储
- ✅ Nginx配置和部署脚本

### 2. 本地GPU项目 (safety-system-models)
**部署位置**: 本地GPU机器  
**功能**: AI模型推理服务  
**包含内容**:
- ✅ 所有AI模型文件和权重
- ✅ 深度学习推理代码
- ✅ Flask API服务器
- ✅ 内网穿透配置
- ✅ 性能监控和日志系统

## 🚀 部署流程

### 第一步：部署本地GPU模型服务

1. **进入本地GPU项目目录**
   ```bash
   cd ../safety-system-models
   ```

2. **安装依赖**
   ```bash
   # 创建虚拟环境
   python -m venv venv
   
   # 激活虚拟环境 (Windows)
   venv\Scripts\activate
   # 或 (Linux/Mac)
   source venv/bin/activate
   
   # 安装依赖
   pip install -r requirements.txt
   ```

3. **配置环境**
   ```bash
   # 编辑配置文件
   nano .env
   
   # 确保模型路径正确
   MODEL_BASE_PATH=./model
   ```

4. **启动模型服务**
   ```bash
   # 检查环境
   python start_model_server.py --check-only
   
   # 启动服务
   python start_model_server.py --port 5001
   ```

5. **配置内网穿透**
   ```bash
   # 使用FRP或ngrok将本地5001端口映射到公网
   # 详见 safety-system-models/README.md
   ```

### 第二步：部署云端Web服务

1. **上传项目到腾讯云**
   ```bash
   # 将safety-system-web目录上传到服务器
   scp -r ../safety-system-web root@your-server-ip:/opt/
   ```

2. **运行自动部署脚本**
   ```bash
   # 登录服务器
   ssh root@your-server-ip
   
   # 进入项目目录
   cd /opt/safety-system-web
   
   # 运行部署脚本
   chmod +x deploy/deploy.sh
   ./deploy/deploy.sh
   ```

3. **配置模型服务器地址**
   ```bash
   # 编辑环境配置
   nano backend/.env
   
   # 修改为你的本地服务器地址
   MODEL_SERVER_URL=http://your-home-ip:5001
   # 或内网穿透地址
   MODEL_SERVER_URL=https://abc123.ngrok.io
   ```

4. **重启服务**
   ```bash
   systemctl restart safety-system-web
   ```

## 🔧 关键配置点

### 1. 网络连接配置

**本地服务器需要**:
- 固定的公网IP或内网穿透
- 开放5001端口
- 稳定的网络连接

**云服务器需要**:
- 正确的MODEL_SERVER_URL配置
- 开放80/443端口
- 防火墙允许访问本地服务器

### 2. 安全配置

**API密钥验证**:
```env
# 在两个项目的.env文件中设置相同的密钥
API_KEY=your-secret-api-key-12345
```

**HTTPS配置**:
- 云端服务配置SSL证书
- 本地服务使用HTTPS（可选）

### 3. 性能优化

**本地GPU服务**:
- 根据GPU显存调整批处理大小
- 启用混合精度训练
- 配置合适的超时时间

**云端服务**:
- 配置请求超时和重试机制
- 启用结果缓存
- 优化文件传输

## 📋 验证部署

### 1. 检查本地模型服务

```bash
# 健康检查
curl http://localhost:5001/health

# 测试水印嵌入
curl -X POST -F "image=@test.jpg" http://localhost:5001/api/watermark/embed
```

### 2. 检查云端服务

```bash
# 访问前端页面
curl http://your-server-ip

# 检查API服务
curl http://your-server-ip/api/health
```

### 3. 端到端测试

1. 打开浏览器访问云端地址
2. 注册/登录用户账号
3. 上传图片进行水印嵌入
4. 验证所有功能模块正常工作

## 🔍 故障排除

### 常见问题及解决方案

1. **模型服务连接失败**
   - 检查本地服务是否正常运行
   - 验证内网穿透配置
   - 确认防火墙设置

2. **前端页面无法访问**
   - 检查Nginx配置和状态
   - 验证前端构建是否成功
   - 查看服务器日志

3. **API请求超时**
   - 调整超时配置
   - 检查网络延迟
   - 优化模型推理速度

### 日志查看

**云端服务日志**:
```bash
# API服务日志
journalctl -u safety-system-web -f

# Nginx日志
tail -f /var/log/nginx/access.log
tail -f /var/log/nginx/error.log
```

**本地模型服务日志**:
```bash
# 模型服务日志
tail -f logs/model_server.log

# GPU使用情况
nvidia-smi
```

## 📊 监控和维护

### 性能监控

**云端监控**:
- 服务器CPU、内存使用率
- API响应时间
- 用户访问量

**本地监控**:
- GPU使用率和温度
- 模型推理时间
- 网络连接状态

### 定期维护

1. **更新依赖包**
2. **清理临时文件**
3. **备份重要数据**
4. **检查安全补丁**

## 🎉 部署完成检查清单

- [ ] 本地GPU模型服务正常运行
- [ ] 内网穿透配置成功
- [ ] 云端前端页面可以访问
- [ ] 云端API服务正常运行
- [ ] 模型服务连接测试通过
- [ ] 所有功能模块测试正常
- [ ] 日志和监控配置完成
- [ ] 安全配置检查完成

## 📞 技术支持

如果在部署过程中遇到问题：

1. **查看详细文档**:
   - `safety-system-web/README.md`
   - `safety-system-models/README.md`

2. **检查日志文件**:
   - 云端: `/var/log/nginx/` 和 `journalctl`
   - 本地: `logs/model_server.log`

3. **验证网络连接**:
   - 测试本地服务可访问性
   - 检查防火墙和端口配置

---

